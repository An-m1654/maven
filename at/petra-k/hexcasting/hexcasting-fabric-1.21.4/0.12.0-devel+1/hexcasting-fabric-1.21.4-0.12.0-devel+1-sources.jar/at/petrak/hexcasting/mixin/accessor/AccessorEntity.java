package at.petrak.hexcasting.mixin.accessor;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1297.class)
public interface AccessorEntity {
    @Invoker("markHurt")
    void hex$markHurt();
}
