package at.petrak.hexcasting.fabric.cc.adimpl;

import at.petrak.hexcasting.api.addldata.ADHexHolder;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.item.HexHolderItem;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import org.jetbrains.annotations.Nullable;
import org.ladysnake.cca.api.v3.component.Component;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

public abstract class CCHexHolder implements ADHexHolder, Component {
    final class_1799 stack;
    public CCHexHolder(class_1799 stack) {
        this.stack = stack;
    }

    public static class ItemBased extends CCHexHolder {
        private final HexHolderItem hexHolder;

        public ItemBased(class_1799 owner) {
            super(owner);
            var item = owner.method_7909();
            if (!(item instanceof HexHolderItem hexHolderItem)) {
                throw new IllegalStateException("item is not a pigment: " + owner);
            }
            this.hexHolder = hexHolderItem;
        }


        @Override
        public boolean canDrawMediaFromInventory() {
            return this.hexHolder.canDrawMediaFromInventory(this.stack);
        }

        @Override
        public boolean hasHex() {
            return this.hexHolder.hasHex(this.stack);
        }

        @Override
        public @Nullable List<Iota> getHex(class_3218 level) {
            return this.hexHolder.getHex(this.stack, level);
        }

        @Override
        public void writeHex(List<Iota> patterns, @Nullable FrozenPigment pigment, long media) {
            this.hexHolder.writeHex(this.stack, patterns, pigment, media);
        }

        @Override
        public void clearHex() {
            this.hexHolder.clearHex(this.stack);
        }

        @Override
        public @Nullable FrozenPigment getPigment() {
            return this.hexHolder.getPigment(this.stack);
        }

        @Override
        public void readFromNbt(class_2487 tag, class_7225.class_7874 registryLookup) {

        }

        @Override
        public void writeToNbt(class_2487 tag, class_7225.class_7874 registryLookup) {

        }
    }
}
