package at.petrak.hexcasting.xplat.overrides;

import at.petrak.hexcasting.api.item.VariantItem;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1800;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;

// suck it fabric trying to be "safe"
public record VariantPredicate() implements class_1800 {
    public static final MapCodec<VariantPredicate> MAP_CODEC = MapCodec.unit(VariantPredicate::new);
    @Override
    public float method_65644(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity,
                     int seed) {
        if (stack.method_7909() instanceof VariantItem variantItem) {
            return variantItem.getVariant(stack);
        }
        return 0;
    }

    @Override
    public MapCodec<? extends class_1800> method_65643() {
        return MAP_CODEC;
    }
}