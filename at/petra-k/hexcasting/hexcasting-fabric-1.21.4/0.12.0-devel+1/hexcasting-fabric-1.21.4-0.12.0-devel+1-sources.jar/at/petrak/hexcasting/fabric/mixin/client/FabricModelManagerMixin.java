package at.petrak.hexcasting.fabric.mixin.client;

import at.petrak.hexcasting.client.RegisterClientStuff;
import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.fabric.api.client.model.loading.v1.FabricBakedModelManager;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1092;
import net.minecraft.class_3695;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.HashMap;
import java.util.Map;

// https://github.com/VazkiiMods/Botania/blob/986dff2e8cd9f40f7e4d6ed7b30c98944bdb3b87/Fabric/src/main/java/vazkii/botania/fabric/mixin/client/ModelManagerFabricMixin.java#L34
@Mixin(class_1092.class)
public class FabricModelManagerMixin {
    @Shadow
    private Map<class_1091, class_1087> bakedBlockStateModels;

//    @Inject(at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/client/resources/model/ModelBakery$BakingResult;blockStateModels()Ljava/util/Map;", shift = At.Shift.AFTER),
//            method = "apply(Lnet/minecraft/client/resources/model/ModelManager$ReloadState;Lnet/minecraft/util/profiling/ProfilerFiller;)V"
//    )
    @Inject(at = @At(value = "TAIL"), method = "apply(Lnet/minecraft/client/resources/model/ModelManager$ReloadState;Lnet/minecraft/util/profiling/ProfilerFiller;)V")
    private void onModelBake(class_1092.class_7779 reloadState, class_3695 profiler, CallbackInfo ci) {
//        Map<ModelResourceLocation, BakedModel> newRegistry = new HashMap<>(this.bakedBlockStateModels);
        RegisterClientStuff.onModelBake(loc -> ((FabricBakedModelManager) this).getModel(loc));
    }
}
