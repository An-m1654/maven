package at.petrak.hexcasting.fabric.datagen;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.block.circle.BlockCircleComponent;
import at.petrak.hexcasting.client.IotaStorageColorizerTintSource;
import at.petrak.hexcasting.common.blocks.BlockQuenchedAllay;
import at.petrak.hexcasting.common.blocks.akashic.BlockAkashicBookshelf;
import at.petrak.hexcasting.common.blocks.circles.directrix.BlockBooleanDirectrix;
import at.petrak.hexcasting.common.items.pigment.ItemPridePigment;
import at.petrak.hexcasting.common.lib.HexBlocks;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.xplat.overrides.*;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Streams;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_10405;
import net.minecraft.class_10410;
import net.minecraft.class_10448;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4917;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4935;
import net.minecraft.class_4936;
import net.minecraft.class_4941;
import net.minecraft.class_4942;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.minecraft.client.data.models.blockstates.*;
import net.minecraft.client.data.models.model.*;
import org.jetbrains.annotations.NotNull;
import vazkii.patchouli.common.util.ItemStackUtil;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Stream;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexModels extends FabricModelProvider {
    private static final String[] PHIAL_SIZES = {"small", "medium", "large", "larger", "largest"};
    private static final Integer[] PACKAGED_SPELL_HANDHELD_VARIANTS = {5};

    public HexModels(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
//        buildFourVariantGaslight(getPath(HexBlocks.QUENCHED_ALLAY), "block/quenched_allay", (name, path) ->
//            cubeAll(path.getPath(), path));
        buildFourVariantGaslight(blockStateModelGenerator.field_55238, HexBlocks.QUENCHED_ALLAY, "block/quenched_allay", path ->
            class_4943.field_22972.method_25852(path, class_4944.method_25875(path), blockStateModelGenerator.field_22831)
        );
//        buildFourVariantGaslight(getPath(HexBlocks.QUENCHED_ALLAY_TILES), "block/deco/quenched_allay_tiles", (name, path) ->
//            cubeAll(path.getPath(), path));
        buildFourVariantGaslight(blockStateModelGenerator.field_55238, HexBlocks.QUENCHED_ALLAY_TILES, "block/deco/quenched_allay_tiles", path ->
            class_4943.field_22972.method_25852(path, class_4944.method_25875(path), blockStateModelGenerator.field_22831)
        );
//        buildFourVariantGaslight(getPath(HexBlocks.QUENCHED_ALLAY_BRICKS), "block/deco/quenched_allay_bricks", (name, path) ->
//            cubeAll(path.getPath(), path));
        buildFourVariantGaslight(blockStateModelGenerator.field_55238, HexBlocks.QUENCHED_ALLAY_BRICKS, "block/deco/quenched_allay_bricks", path ->
            class_4943.field_22972.method_25852(path, class_4944.method_25875(path), blockStateModelGenerator.field_22831)
        );
//        buildFourVariantGaslight(getPath(HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL), "block/deco/quenched_allay_bricks_small", (name, path) ->
//            cubeAll(path.getPath(), path));
        buildFourVariantGaslight(blockStateModelGenerator.field_55238, HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL, "block/deco/quenched_allay_bricks_small", path ->
            class_4943.field_22972.method_25852(path, class_4944.method_25875(path), blockStateModelGenerator.field_22831)
        );

//-------------------------------- ACTUAL START OF THE BLOCK STATES FILE IN THE ORIGINAL SOURCE CODE -------------------------------------------
        blockStateModelGenerator.field_22830.accept(
            class_4925.method_25769(HexBlocks.SLATE)
                .method_25775(
                    class_4926.method_25785(
                        BlockCircleComponent.ENERGIZED,
                        class_2741.field_12481,
                        class_2741.field_12555
                    )
                    .method_25805((energized, facing, attachFace) -> {
                        int rotationX = 0;
                        int rotationY = 0;
                        switch (attachFace) {
                            case field_12473 -> rotationX = 180;
                            case field_12471 -> {
                                rotationX = 90;
                                rotationY = facing.method_10153().method_10161() * 90;
                            }
                        }
                        class_4935 returnValue = class_4935.method_25824()
                            .method_25828(class_4936.field_22887, modLoc("block/slate"))
                            .method_25828(class_4936.field_22888, true);
                        if (rotationX != 0) {
                            returnValue
                            .method_25828(class_4936.field_22885, class_4936.class_4937.values()[rotationX/90]);
                        }
                        if (rotationY != 0) {
                            returnValue
                            .method_25828(class_4936.field_22886, class_4936.class_4937.values()[rotationY/90]);
                        }
                        return returnValue;
                    })
                )
        );

        impetus(blockStateModelGenerator, HexBlocks.IMPETUS_EMPTY, "impetus/empty", "empty", false);
        impetus(blockStateModelGenerator, HexBlocks.IMPETUS_RIGHTCLICK, "impetus/rightclick", "rightclick", true);
        impetus(blockStateModelGenerator, HexBlocks.IMPETUS_LOOK, "impetus/look", "look", true);
        impetus(blockStateModelGenerator, HexBlocks.IMPETUS_REDSTONE, "impetus/redstone", "redstone", true);
        doAllTheDirectrices(blockStateModelGenerator);

        var innerTextureSlot = class_4945.method_27043("inner");
        var outerTextureSlot = class_4945.method_27043("outer");
        var akashicRecordModelTextureMapping = new class_4944()
            .method_25868(innerTextureSlot, modLoc("block/akashic_ligature"))
            .method_25868(outerTextureSlot, modLoc("block/akashic_record"))
            .method_25868(class_4945.field_23012, modLoc("block/akashic_ligature"));
        blockStateModelGenerator.field_22831.accept(
            modLoc("block/akashic_record"),
            () -> {
                Map<class_4945, class_2960> map = Streams.concat(ImmutableSet.of(innerTextureSlot, outerTextureSlot, class_4945.field_23012).stream(), akashicRecordModelTextureMapping.method_25861()).collect(ImmutableMap.toImmutableMap(Function.identity(), akashicRecordModelTextureMapping::method_25867));
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("parent", class_2960.method_60656("block/block").toString());

                jsonObject.addProperty("render_type", "minecraft:translucent");

                if (!map.isEmpty()) {
                    JsonObject jsonObject2 = new JsonObject();
                    map.forEach((textureSlot, resourceLocationx) -> jsonObject2.addProperty(textureSlot.method_25912(), resourceLocationx.toString()));
                    jsonObject.add("textures", jsonObject2);
                }

                JsonArray elements = new JsonArray();

                JsonObject outerTexture = new JsonObject();
                JsonObject outerTextureFace = new JsonObject();
                for (String item : List.of("down", "east", "north", "south", "up", "west")) {
                    JsonObject itemObject = new JsonObject();
                    itemObject.addProperty("cullface", item);
                    itemObject.addProperty("texture", "#outer");
                    outerTextureFace.add(item, itemObject);
                }
                outerTexture.add("faces", outerTextureFace);

                JsonArray outerTextureFrom = new JsonArray();
                outerTextureFrom.add(0);
                outerTextureFrom.add(0);
                outerTextureFrom.add(0);
                outerTexture.add("from", outerTextureFrom);

                JsonArray outerTextureTo = new JsonArray();
                outerTextureTo.add(16);
                outerTextureTo.add(16);
                outerTextureTo.add(16);
                outerTexture.add("to", outerTextureTo);

                elements.add(outerTexture);

                JsonObject innerTexture = new JsonObject();
                JsonObject innerTextureFace = new JsonObject();
                for (String item : List.of("down", "east", "north", "south", "up", "west")) {
                    JsonObject itemObject = new JsonObject();
                    itemObject.addProperty("rotation", 180);
                    itemObject.addProperty("texture", "#inner");
                    innerTextureFace.add(item, itemObject);
                }
                innerTexture.add("faces", innerTextureFace);

                JsonArray innerTextureFrom = new JsonArray();
                innerTextureFrom.add(15.75);
                innerTextureFrom.add(15.75);
                innerTextureFrom.add(15.75);
                innerTexture.add("from", innerTextureFrom);

                JsonArray innerTextureTo = new JsonArray();
                innerTextureTo.add(0.25);
                innerTextureTo.add(0.25);
                innerTextureTo.add(0.25);
                innerTexture.add("to", innerTextureTo);

                elements.add(innerTexture);
                jsonObject.add("elements", elements);
                return jsonObject;
            }
        );

        blockStateModelGenerator.field_22830.accept(
            new dummyVariantGenerator(HexBlocks.AKASHIC_RECORD, modLoc("block/akashic_record"))
        );

        new class_4942(Optional.of(modLoc("block/akashic_record")), Optional.empty())
            .method_25852(class_4941.method_25840(HexBlocks.AKASHIC_RECORD.method_8389()), new class_4944(), blockStateModelGenerator.field_22831);

        class_4943.field_22972.method_25846(HexBlocks.AKASHIC_LIGATURE, class_4944.method_25864(HexBlocks.AKASHIC_LIGATURE), blockStateModelGenerator.field_22831);

        blockStateModelGenerator.field_22830.accept(
            new dummyVariantGenerator(HexBlocks.AKASHIC_LIGATURE, modLoc("block/akashic_ligature"))
        );

        new class_4942(Optional.of(modLoc("block/akashic_ligature")), Optional.empty())
            .method_25852(class_4941.method_25840(HexBlocks.AKASHIC_LIGATURE.method_8389()), new class_4944(), blockStateModelGenerator.field_22831);

        var topBottomTextureSlot = class_4945.method_27043("top_bottom");
        var akashicBookshelfModelTextureMapping = new class_4944()
            .method_25868(class_4945.field_23016, modLoc("block/akashic_bookshelf"))
            .method_25868(class_4945.field_23018, modLoc("block/akashic_bookshelf_horiz"))
            .method_25868(topBottomTextureSlot, modLoc("block/akashic_bookshelf_vert"))
            .method_25868(class_4945.field_23012, modLoc("block/akashic_bookshelf_vert"));
        blockStateModelGenerator.field_22831.accept(
            modLoc("block/akashic_bookshelf"),
            () -> {
                Map<class_4945, class_2960> map = Streams.concat(ImmutableSet.of(class_4945.field_23016, class_4945.field_23018, topBottomTextureSlot, class_4945.field_23012).stream(), akashicBookshelfModelTextureMapping.method_25861()).collect(ImmutableMap.toImmutableMap(Function.identity(), akashicBookshelfModelTextureMapping::method_25867));
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("render_type", "minecraft:cutout");

                if (!map.isEmpty()) {
                    JsonObject jsonObject2 = new JsonObject();
                    map.forEach((textureSlot, resourceLocationx) -> jsonObject2.addProperty(textureSlot.method_25912(), resourceLocationx.toString()));
                    jsonObject.add("textures", jsonObject2);
                }

                JsonArray elements = new JsonArray();

                JsonObject baseTexture = new JsonObject();
                JsonObject baseTextureFace = new JsonObject();
                Map.of("down", "#top_bottom", "east", "#side", "north", "#front", "south", "#side", "up", "#top_bottom", "west", "#side").forEach((key, value) -> {
                    JsonObject itemObject = new JsonObject();
                    itemObject.addProperty("cullface", key);
                    itemObject.addProperty("texture", value);
                    baseTextureFace.add(key, itemObject);
                });
                baseTexture.add("faces", baseTextureFace);

                JsonArray baseTextureFrom = new JsonArray();
                baseTextureFrom.add(0);
                baseTextureFrom.add(0);
                baseTextureFrom.add(0);
                baseTexture.add("from", baseTextureFrom);

                JsonArray baseTextureTo = new JsonArray();
                baseTextureTo.add(16);
                baseTextureTo.add(16);
                baseTextureTo.add(16);
                baseTexture.add("to", baseTextureTo);

                elements.add(baseTexture);

                JsonObject overlayTexture = new JsonObject();
                JsonObject overlayTextureFace = new JsonObject();
                JsonObject overlayObject = new JsonObject();
                overlayObject.addProperty("cullface", "north");
                overlayObject.addProperty("texture", "#overlay");
                overlayObject.addProperty("tintindex", 0);
                overlayTextureFace.add("north", overlayObject);
                overlayTexture.add("faces", overlayTextureFace);

                JsonArray overlayTextureFrom = new JsonArray();
                overlayTextureFrom.add(0);
                overlayTextureFrom.add(0);
                overlayTextureFrom.add(0);
                overlayTexture.add("from", overlayTextureFrom);

                JsonArray overlayTextureTo = new JsonArray();
                overlayTextureTo.add(16);
                overlayTextureTo.add(16);
                overlayTextureTo.add(16);
                overlayTexture.add("to", overlayTextureTo);

                elements.add(overlayTexture);
                jsonObject.add("elements", elements);
                return jsonObject;
            }
        );

        var overlayTextureSlot = class_4945.method_27043("overlay");
        for (int i = 1; i <= 4; i++) {
            new class_4942(Optional.of(modLoc("block/akashic_bookshelf")), Optional.empty(), overlayTextureSlot)
                .method_25852(modLoc("block/akashic_bookshelf_" + i), new class_4944().method_25868(overlayTextureSlot, modLoc("block/akashic_bookshelf_overlay_" + i)), blockStateModelGenerator.field_22831);
        }
        class_4943.field_22978.method_25852(
            modLoc("block/akashic_bookshelf_empty"),
            new class_4944()
                .method_25868(class_4945.field_23018, modLoc("block/akashic_bookshelf_horiz"))
                .method_25868(class_4945.field_23016, modLoc("block/akashic_bookshelf"))
                .method_25868(class_4945.field_23015, modLoc("block/akashic_bookshelf_vert")),
            blockStateModelGenerator.field_22831
        );

        blockStateModelGenerator.field_22830.accept(
            class_4925.method_25769(HexBlocks.AKASHIC_BOOKSHELF)
                .method_25775(
                    class_4926.method_25784(class_2741.field_12481, BlockAkashicBookshelf.HAS_BOOKS)
                        .method_25803((dir, hasBooks) -> {
                           List<class_4935> builders = new ArrayList<>();
                            if (hasBooks) {
                                for (int i = 1; i <= 4; i++) {
                                    var builder = class_4935.method_25824();
//                                    var model = models().withExistingParent("akashic_bookshelf_" + i,
//                                            modLoc("block/akashic_bookshelf"))
//                                        .texture("overlay", modLoc("block/akashic_bookshelf_overlay_" + i));
                                    var model = modLoc("block/akashic_bookshelf_" + i);
//                                    builder.modelFile(model)
//                                        .rotationY(dir.getOpposite().get2DDataValue() * 90)
//                                        .uvLock(true);
//                                    if (i < 4) {
//                                        builder = builder.nextModel();
//                                    }
                                    builder
                                        .method_25828(class_4936.field_22887, model)
                                        .method_25828(class_4936.field_22886, class_4936.class_4937.values()[((dir.method_10153().method_10161() * 90) / 90 + 4) % 4])
                                        .method_25828(class_4936.field_22888, true);
                                    builders.add(builder);
                                }
                            } else {
                                var builder = class_4935.method_25824();
                                var model = modLoc("block/akashic_bookshelf_empty");

                                if (dir == class_2350.field_11043) {
                                    new class_4942(Optional.of(model), Optional.empty())
                                        .method_48525(HexBlocks.AKASHIC_BOOKSHELF.method_8389(), new class_4944(), blockStateModelGenerator.field_22831);
                                }

                                builder
                                    .method_25828(class_4936.field_22887, model)
                                    .method_25828(class_4936.field_22886, class_4936.class_4937.values()[((dir.method_10153().method_10161() * 90) / 90 + 4) % 4])
                                    .method_25828(class_4936.field_22888, true);
                                builders.add(builder);
                            }
                            return builders;
                        })
                )
        );


        blockAndItem(blockStateModelGenerator, HexBlocks.SLATE_BLOCK, class_4943.field_22972.method_25846(HexBlocks.SLATE_BLOCK, class_4944.method_25875(modLoc("block/slate_block")), blockStateModelGenerator.field_22831));
        blockAndItem(blockStateModelGenerator, HexBlocks.SLATE_TILES, class_4943.field_22972.method_25846(HexBlocks.SLATE_TILES, class_4944.method_25875(modLoc("block/deco/slate_tiles")), blockStateModelGenerator.field_22831));
        blockAndItem(blockStateModelGenerator, HexBlocks.SLATE_BRICKS, class_4943.field_22972.method_25846(HexBlocks.SLATE_BRICKS, class_4944.method_25875(modLoc("block/deco/slate_bricks")), blockStateModelGenerator.field_22831));
        blockAndItem(blockStateModelGenerator, HexBlocks.SLATE_BRICKS_SMALL, class_4943.field_22972.method_25846(HexBlocks.SLATE_BRICKS_SMALL, class_4944.method_25875(modLoc("block/deco/slate_bricks_small")), blockStateModelGenerator.field_22831));
        axisBlock(blockStateModelGenerator, HexBlocks.SLATE_PILLAR, modLoc("block/deco/slate_pillar"));
        blockAndItem(blockStateModelGenerator, HexBlocks.AMETHYST_DUST_BLOCK,
            new class_4942(Optional.of(modLoc("block/cube_half_mirrored")), Optional.empty(), class_4945.field_23010)
                .method_25846(
                    HexBlocks.AMETHYST_DUST_BLOCK,
                    class_4944.method_25875(modLoc("block/amethyst_dust_block")),
                    blockStateModelGenerator.field_22831
                )
            );
        blockAndItem(blockStateModelGenerator, HexBlocks.AMETHYST_TILES, class_4943.field_22972.method_25852(modLoc("block/deco/amethyst_tiles"), class_4944.method_25875(modLoc("block/deco/amethyst_tiles")), blockStateModelGenerator.field_22831));
        blockAndItem(blockStateModelGenerator, HexBlocks.AMETHYST_BRICKS, class_4943.field_22972.method_25852(modLoc("block/deco/amethyst_bricks"), class_4944.method_25875(modLoc("block/deco/amethyst_bricks")), blockStateModelGenerator.field_22831));
        blockAndItem(blockStateModelGenerator, HexBlocks.AMETHYST_BRICKS_SMALL, class_4943.field_22972.method_25852(modLoc("block/deco/amethyst_bricks_small"), class_4944.method_25875(modLoc("block/deco/amethyst_bricks_small")), blockStateModelGenerator.field_22831));
        directionalBlock(blockStateModelGenerator, HexBlocks.AMETHYST_PILLAR,
            class_4943.field_22977.method_25852(modLoc("block/deco/amethyst_pillar"),
                new class_4944()
                    .method_25868(class_4945.field_23018, modLoc("block/deco/amethyst_pillar_side"))
                    .method_25868(class_4945.field_23014, modLoc("block/deco/amethyst_pillar_bottom"))
                    .method_25868(class_4945.field_23015, modLoc("block/deco/amethyst_pillar_top")),
                blockStateModelGenerator.field_22831
            )
        );
        blockAndItem(blockStateModelGenerator, HexBlocks.SLATE_AMETHYST_TILES, class_4943.field_22972.method_25852(modLoc("block/deco/slate_amethyst_tiles"), class_4944.method_25875(modLoc("block/deco/slate_amethyst_tiles")), blockStateModelGenerator.field_22831));

        blockStateModelGenerator.field_22830.accept(
            new dummyArrayVariantGenerator(HexBlocks.SLATE_AMETHYST_BRICKS,
                new class_2960[]{
                    class_4943.field_22972.method_25852(HexAPI.modLoc("block/deco/slate_amethyst_bricks_0"), class_4944.method_25875(HexAPI.modLoc("block/deco/slate_amethyst_bricks_0")), blockStateModelGenerator.field_22831),
                    class_4943.field_22972.method_25852(HexAPI.modLoc("block/deco/slate_amethyst_bricks_1"), class_4944.method_25875(HexAPI.modLoc("block/deco/slate_amethyst_bricks_1")), blockStateModelGenerator.field_22831),
                    class_4943.field_22972.method_25852(HexAPI.modLoc("block/deco/slate_amethyst_bricks_2"), class_4944.method_25875(HexAPI.modLoc("block/deco/slate_amethyst_bricks_2")), blockStateModelGenerator.field_22831)
                },
                new Optional[]{}
            )
        );

        var SlateAmethystBricksItemLocation = new class_4942(
            Optional.of(modLoc("block/deco/slate_amethyst_bricks_0")),
            Optional.empty()
        )
            .method_48525(HexBlocks.SLATE_AMETHYST_BRICKS.method_8389(), new class_4944(), blockStateModelGenerator.field_22831);

        blockStateModelGenerator.field_55238.method_65460(
            HexBlocks.SLATE_AMETHYST_BRICKS.method_8389(),
            class_10410.method_65481(SlateAmethystBricksItemLocation)
        );

        blockStateModelGenerator.field_22830.accept(
            new dummyArrayVariantGenerator(HexBlocks.SLATE_AMETHYST_BRICKS_SMALL,
                new class_2960[]{
                    class_4943.field_22972.method_25852(HexAPI.modLoc("block/deco/slate_amethyst_bricks_small_0"), class_4944.method_25875(HexAPI.modLoc("block/deco/slate_amethyst_bricks_small_0")), blockStateModelGenerator.field_22831),
                    class_4943.field_22972.method_25852(HexAPI.modLoc("block/deco/slate_amethyst_bricks_small_1"), class_4944.method_25875(HexAPI.modLoc("block/deco/slate_amethyst_bricks_small_1")), blockStateModelGenerator.field_22831),
                    class_4943.field_22972.method_25852(HexAPI.modLoc("block/deco/slate_amethyst_bricks_small_2"), class_4944.method_25875(HexAPI.modLoc("block/deco/slate_amethyst_bricks_small_2")), blockStateModelGenerator.field_22831)
                },
                new Optional[]{}
            )
        );

        var SlateAmethystBricksSmallItemLocation = new class_4942(Optional.of(modLoc("block/deco/slate_amethyst_bricks_small_0")),
            Optional.empty()
        )
            .method_48525(HexBlocks.SLATE_AMETHYST_BRICKS_SMALL.method_8389(), new class_4944(), blockStateModelGenerator.field_22831);

        blockStateModelGenerator.field_55238.method_65460(
            HexBlocks.SLATE_AMETHYST_BRICKS_SMALL.method_8389(),
            class_10410.method_65481(SlateAmethystBricksSmallItemLocation)
        );

        axisBlock(blockStateModelGenerator, HexBlocks.SLATE_AMETHYST_PILLAR, modLoc("block/deco/slate_amethyst_pillar"));
        blockAndItem(blockStateModelGenerator, HexBlocks.SCROLL_PAPER, class_4943.field_22972.method_25846(HexBlocks.SCROLL_PAPER, class_4944.method_25875(modLoc("block/scroll_paper")), blockStateModelGenerator.field_22831));
        blockAndItem(blockStateModelGenerator, HexBlocks.ANCIENT_SCROLL_PAPER, class_4943.field_22972.method_25846(HexBlocks.ANCIENT_SCROLL_PAPER, class_4944.method_25875(modLoc("block/ancient_scroll_paper")), blockStateModelGenerator.field_22831));

        blockAndItem(blockStateModelGenerator, HexBlocks.SCROLL_PAPER_LANTERN, class_4943.field_22977.method_25852(modLoc("block/scroll_paper_lantern"),
            new class_4944()
                .method_25868(class_4945.field_23018, modLoc("block/scroll_paper_lantern_side"))
                .method_25868(class_4945.field_23014, modLoc("block/scroll_paper_lantern_bottom"))
                .method_25868(class_4945.field_23015, modLoc("block/scroll_paper_lantern_top")),
            blockStateModelGenerator.field_22831
        ));

        blockAndItem(blockStateModelGenerator, HexBlocks.ANCIENT_SCROLL_PAPER_LANTERN, class_4943.field_22977.method_25852(modLoc("block/ancient_scroll_paper_lantern"),
            new class_4944()
                .method_25868(class_4945.field_23018, modLoc("block/ancient_scroll_paper_lantern_side"))
                .method_25868(class_4945.field_23014, modLoc("block/ancient_scroll_paper_lantern_bottom"))
                .method_25868(class_4945.field_23015, modLoc("block/ancient_scroll_paper_lantern_top")),
            blockStateModelGenerator.field_22831
        ));

        axisBlock(blockStateModelGenerator, HexBlocks.EDIFIED_LOG, modLoc("block/edified_log"), modLoc("block/edified_log_top"));
        axisBlock(blockStateModelGenerator, HexBlocks.EDIFIED_LOG_AMETHYST, modLoc("block/deco/edified_log_amethyst"), modLoc("block/edified_log_top"));
        axisBlock(blockStateModelGenerator, HexBlocks.EDIFIED_LOG_AVENTURINE, modLoc("block/deco/edified_log_aventurine"), modLoc("block/edified_log_top"));
        axisBlock(blockStateModelGenerator, HexBlocks.EDIFIED_LOG_CITRINE, modLoc("block/deco/edified_log_citrine"), modLoc("block/edified_log_top"));
        axisBlock(blockStateModelGenerator, HexBlocks.EDIFIED_LOG_PURPLE, modLoc("block/deco/edified_log_purple"), modLoc("block/edified_log_top"));
        axisBlock(blockStateModelGenerator, HexBlocks.STRIPPED_EDIFIED_LOG, modLoc("block/stripped_edified_log"), modLoc("block/stripped_edified_log_top"));
        axisBlock(blockStateModelGenerator, HexBlocks.EDIFIED_WOOD, modLoc("block/edified_log"), modLoc("block/edified_log"));
        axisBlock(blockStateModelGenerator, HexBlocks.STRIPPED_EDIFIED_WOOD, modLoc("block/stripped_edified_log"),
            modLoc("block/stripped_edified_log"));

        blockAndItem(blockStateModelGenerator, HexBlocks.EDIFIED_PANEL, class_4943.field_22972.method_25852(modLoc("block/edified_panel"), class_4944.method_25875(modLoc("block/edified_panel")), blockStateModelGenerator.field_22831));
        blockAndItem(blockStateModelGenerator, HexBlocks.EDIFIED_TILE, class_4943.field_22972.method_25852(modLoc("block/edified_tile"), class_4944.method_25875(modLoc("block/edified_panel")), blockStateModelGenerator.field_22831));

        class_2960 leavesParent = class_2960.method_60656("block/leaves");
        blockStateModelGenerator.field_22831.accept(
            modLoc("block/amethyst_edified_leaves"),
            () -> {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("parent", leavesParent.toString());
                jsonObject.addProperty("render_type", "minecraft:cutout_mipped");

                JsonObject textures = new JsonObject();
                textures.addProperty("all", modLoc("block/amethyst_edified_leaves").toString());
                jsonObject.add("textures", textures);
                return jsonObject;
            }
        );
        blockAndItem(
            blockStateModelGenerator,
            HexBlocks.AMETHYST_EDIFIED_LEAVES,
            modLoc("block/amethyst_edified_leaves")
        );

        blockStateModelGenerator.field_22831.accept(
            modLoc("block/aventurine_edified_leaves"),
            () -> {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("parent", leavesParent.toString());
                jsonObject.addProperty("render_type", "minecraft:cutout_mipped");

                JsonObject textures = new JsonObject();
                textures.addProperty("all", modLoc("block/aventurine_edified_leaves").toString());
                jsonObject.add("textures", textures);
                return jsonObject;
            }
        );
        blockAndItem(
            blockStateModelGenerator,
            HexBlocks.AVENTURINE_EDIFIED_LEAVES,
            modLoc("block/aventurine_edified_leaves")
        );

        blockStateModelGenerator.field_22831.accept(
            modLoc("block/citrine_edified_leaves"),
            () -> {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("parent", leavesParent.toString());
                jsonObject.addProperty("render_type", "minecraft:cutout_mipped");

                JsonObject textures = new JsonObject();
                textures.addProperty("all", modLoc("block/citrine_edified_leaves").toString());
                jsonObject.add("textures", textures);
                return jsonObject;
            }
        );
        blockAndItem(
            blockStateModelGenerator,
            HexBlocks.CITRINE_EDIFIED_LEAVES,
            modLoc("block/citrine_edified_leaves")
        );

        for (String suffix : new String[]{"_bottom_left", "_bottom_left_open", "_bottom_right", "_bottom_right_open", "_top_left", "_top_left_open", "_top_right", "_top_right_open"}) {
            blockStateModelGenerator.field_22831.accept(
                class_4941.method_25842(HexBlocks.EDIFIED_DOOR).method_48331(suffix),
                () -> {
                    JsonObject jsonObject = new JsonObject();
                    jsonObject.addProperty("parent", class_2960.method_60656("block/door" + suffix).toString());
                    jsonObject.addProperty("render_type", "minecraft:cutout");

                    JsonObject textures = new JsonObject();
                    textures.addProperty("bottom", modLoc("block/edified_door_lower").toString());
                    textures.addProperty("top", modLoc("block" + "/edified_door_upper").toString());
                    jsonObject.add("textures", textures);
                    return jsonObject;
                }
            );
        }
        blockStateModelGenerator.field_22830.accept(
            class_4910.method_25609(HexBlocks.EDIFIED_DOOR, modLoc("block/edified_door_bottom_left"), modLoc("block/edified_door_bottom_left_open"), modLoc("block/edified_door_bottom_right"), modLoc("block/edified_door_bottom_right_open"), modLoc("block/edified_door_top_left"), modLoc("block/edified_door_top_left_open"), modLoc("block/edified_door_top_right"), modLoc("block/edified_door_top_right_open"))
        );

        var edifiedDoorItemModel = class_4943.field_22938.method_48525(HexBlocks.EDIFIED_DOOR.method_8389(), class_4944.method_25895(modLoc("item/edified_door")), blockStateModelGenerator.field_22831);

        blockStateModelGenerator.field_55238.method_65460(
            HexBlocks.EDIFIED_DOOR.method_8389(),
            class_10410.method_65481(edifiedDoorItemModel)
        );

        for (String suffix : new String[]{"_bottom", "_top", "_open"}) {
            blockStateModelGenerator.field_22831.accept(
                class_4941.method_25842(HexBlocks.EDIFIED_TRAPDOOR).method_48331(suffix),
                () -> {
                    JsonObject jsonObject = new JsonObject();
                    jsonObject.addProperty("parent", class_2960.method_60656("block/template_orientable_trapdoor" + suffix).toString());
                    jsonObject.addProperty("render_type", "minecraft:cutout");

                    JsonObject textures = new JsonObject();
                    textures.addProperty("texture", modLoc("block/edified_trapdoor").toString());
                    jsonObject.add("textures", textures);
                    return jsonObject;
                }
            );
        }
        blockStateModelGenerator.field_22830.accept(
            class_4910.method_25655(HexBlocks.EDIFIED_TRAPDOOR, modLoc("block/edified_trapdoor_top"), modLoc("block/edified_trapdoor_bottom"), modLoc("block/edified_trapdoor_open"))
        );

        var edifiedTrapdoorItemModel = new class_4942(Optional.of(modLoc("block/edified_trapdoor_bottom")), Optional.empty())
            .method_48525(HexBlocks.EDIFIED_TRAPDOOR.method_8389(), new class_4944(), blockStateModelGenerator.field_22831);

        blockStateModelGenerator.field_55238.method_65460(
            HexBlocks.EDIFIED_TRAPDOOR.method_8389(),
            class_10410.method_65481(edifiedTrapdoorItemModel)
        );

        class_2960 planks1 = modLoc("block/edified_planks");
        class_2960 planksModel = class_4943.field_22972.method_25852(modLoc("block/edified_planks"), class_4944.method_25875(planks1), blockStateModelGenerator.field_22831);
        blockStateModelGenerator.field_22830.accept(
            new dummyArrayVariantGenerator(HexBlocks.EDIFIED_PLANKS,
                new class_2960[]{
                    planksModel,
                    class_4943.field_22972.method_25852(modLoc("block/edified_planks_2"), class_4944.method_25875(modLoc("block/edified_planks_2")), blockStateModelGenerator.field_22831),
                    class_4943.field_22972.method_25852(modLoc("block/edified_planks_3"), class_4944.method_25875(modLoc("block/edified_planks_3")), blockStateModelGenerator.field_22831)
                },
                new Optional[]{Optional.of(3), Optional.of(3), Optional.empty()}
            )
        );
        new class_4942(Optional.of(planksModel), Optional.empty())
            .method_48525(HexBlocks.EDIFIED_PLANKS.method_8389(), new class_4944(), blockStateModelGenerator.field_22831);

        blockStateModelGenerator.field_22830.accept(
            class_4910.method_25646(
                HexBlocks.EDIFIED_STAIRS,
                class_4943.field_22913.method_25846(HexBlocks.EDIFIED_STAIRS, new class_4944().method_25868(class_4945.field_23014, planks1).method_25868(class_4945.field_23015, planks1).method_25868(class_4945.field_23018, planks1), blockStateModelGenerator.field_22831),
                class_4943.field_22912.method_25846(HexBlocks.EDIFIED_STAIRS, new class_4944().method_25868(class_4945.field_23014, planks1).method_25868(class_4945.field_23015, planks1).method_25868(class_4945.field_23018, planks1), blockStateModelGenerator.field_22831),
                class_4943.field_22914.method_25846(HexBlocks.EDIFIED_STAIRS, new class_4944().method_25868(class_4945.field_23014, planks1).method_25868(class_4945.field_23015, planks1).method_25868(class_4945.field_23018, planks1), blockStateModelGenerator.field_22831)
            )
        );

        new class_4942(Optional.of(class_4941.method_25842(HexBlocks.EDIFIED_STAIRS)), Optional.empty())
            .method_48525(HexBlocks.EDIFIED_STAIRS.method_8389(), new class_4944(), blockStateModelGenerator.field_22831);

        blockStateModelGenerator.field_22830.accept(
            class_4910.method_25661(
                HexBlocks.EDIFIED_FENCE,
                class_4943.field_22988.method_25846(HexBlocks.EDIFIED_FENCE, class_4944.method_25869(planks1), blockStateModelGenerator.field_22831),
                class_4943.field_22989.method_25846(HexBlocks.EDIFIED_FENCE, class_4944.method_25869(planks1), blockStateModelGenerator.field_22831)
            )
        );

        var edifiedFenceItemModel = class_4943.field_22990.method_25846(HexBlocks.EDIFIED_FENCE, class_4944.method_25869(planks1), blockStateModelGenerator.field_22831);

        blockStateModelGenerator.field_55238.method_65460(
            HexBlocks.EDIFIED_FENCE.method_8389(),
            class_10410.method_65481(edifiedFenceItemModel)
        );

        blockStateModelGenerator.field_22830.accept(
            class_4910.method_25626(
                HexBlocks.EDIFIED_FENCE_GATE,
                class_4943.field_22996.method_25846(HexBlocks.EDIFIED_FENCE_GATE, class_4944.method_25869(planks1), blockStateModelGenerator.field_22831),
                class_4943.field_22995.method_25846(HexBlocks.EDIFIED_FENCE_GATE, class_4944.method_25869(planks1), blockStateModelGenerator.field_22831),
                class_4943.field_22905.method_25846(HexBlocks.EDIFIED_FENCE_GATE, class_4944.method_25869(planks1), blockStateModelGenerator.field_22831),
                class_4943.field_22904.method_25846(HexBlocks.EDIFIED_FENCE_GATE, class_4944.method_25869(planks1), blockStateModelGenerator.field_22831),
                true
            )
        );
        new class_4942(Optional.of(class_4941.method_25842(HexBlocks.EDIFIED_FENCE_GATE)), Optional.empty())
            .method_48525(HexBlocks.EDIFIED_FENCE_GATE.method_8389(), new class_4944(), blockStateModelGenerator.field_22831);

        class_4944 slabMapping = new class_4944()
            .method_25868(class_4945.field_23014, planks1)
            .method_25868(class_4945.field_23015, planks1)
            .method_25868(class_4945.field_23018, planks1);
        blockStateModelGenerator.field_22830.accept(
            class_4910.method_25668(
                HexBlocks.EDIFIED_SLAB,
                class_4943.field_22909.method_25846(HexBlocks.EDIFIED_SLAB, slabMapping, blockStateModelGenerator.field_22831),
                class_4943.field_22910.method_25846(HexBlocks.EDIFIED_SLAB, slabMapping, blockStateModelGenerator.field_22831),
                planksModel
            )
        );

        new class_4942(Optional.of(class_4941.method_25842(HexBlocks.EDIFIED_SLAB)), Optional.empty())
            .method_48525(HexBlocks.EDIFIED_SLAB.method_8389(), new class_4944(), blockStateModelGenerator.field_22831);

        blockStateModelGenerator.field_22830.accept(
            class_4910.method_25654(
                HexBlocks.EDIFIED_BUTTON,
                class_4943.field_22981.method_25846(HexBlocks.EDIFIED_BUTTON, class_4944.method_25869(planks1), blockStateModelGenerator.field_22831),
                class_4943.field_22982.method_25846(HexBlocks.EDIFIED_BUTTON, class_4944.method_25869(planks1), blockStateModelGenerator.field_22831)
            )
        );

        blockStateModelGenerator.field_55238.method_65460(
            HexBlocks.EDIFIED_BUTTON.method_8389(),
            class_10410.method_65481(
                class_4943.field_22983.method_48525(HexBlocks.EDIFIED_BUTTON.method_8389(), class_4944.method_25869(planks1), blockStateModelGenerator.field_22831)
            )
        );

        blockStateModelGenerator.field_22830.accept(
            class_4910.method_25673(
                HexBlocks.EDIFIED_PRESSURE_PLATE,
                class_4943.field_22906.method_25846(HexBlocks.EDIFIED_PRESSURE_PLATE, class_4944.method_25869(planks1), blockStateModelGenerator.field_22831),
                class_4943.field_22907.method_25846(HexBlocks.EDIFIED_PRESSURE_PLATE, class_4944.method_25869(planks1), blockStateModelGenerator.field_22831)
            )
        );

        new class_4942(Optional.of(class_4941.method_25842(HexBlocks.EDIFIED_PRESSURE_PLATE)), Optional.empty())
            .method_48525(HexBlocks.EDIFIED_PRESSURE_PLATE.method_8389(), new class_4944(), blockStateModelGenerator.field_22831);

        directionalBlock(blockStateModelGenerator, HexBlocks.SCONCE, modLoc("block/amethyst_sconce"));

//        var conjuredModel = models().getBuilder("conjured").texture("particle", mcLoc("block/amethyst_block"))
//            .renderType("cutout");
        blockStateModelGenerator.field_22831.accept(
            modLoc("block/conjured"),
            () -> {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("render_type", "minecraft:cutout");

                JsonObject textures = new JsonObject();
                textures.addProperty("particle", class_2960.method_60656("block/amethyst_block").toString());
                jsonObject.add("textures", textures);
                return jsonObject;
            }
        );
        var conjuredModel = modLoc("block/conjured");
        blockStateModelGenerator.field_22830.accept(
            new dummyVariantGenerator(HexBlocks.CONJURED_BLOCK, conjuredModel)
        );
        blockStateModelGenerator.field_22830.accept(
            new dummyVariantGenerator(HexBlocks.CONJURED_LIGHT, conjuredModel)
        );

        blockStateModelGenerator.field_22830.accept(
            new dummyVariantGenerator(
                HexBlocks.QUENCHED_ALLAY,
                class_4943.field_22972.method_25852(
                    modLoc("block/quenched_allay"),
                    class_4944.method_25875(modLoc("block/quenched_allay_0")),
                    blockStateModelGenerator.field_22831))
        );
        blockStateModelGenerator.field_22830.accept(
            new dummyVariantGenerator(
                HexBlocks.QUENCHED_ALLAY_TILES,
                class_4943.field_22972.method_25852(
                    modLoc("block/quenched_allay_tiles"),
                    class_4944.method_25875(modLoc("lock/deco/quenched_allay_tiles_0")),
                    blockStateModelGenerator.field_22831))
        );
        blockStateModelGenerator.field_22830.accept(
            new dummyVariantGenerator(
                HexBlocks.QUENCHED_ALLAY_BRICKS,
                class_4943.field_22972.method_25852(
                    modLoc("block/quenched_allay_bricks"),
                    class_4944.method_25875(modLoc("block/deco/quenched_allay_bricks_0")),
                    blockStateModelGenerator.field_22831))
        );
        blockStateModelGenerator.field_22830.accept(
            new dummyVariantGenerator(
                HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL,
                class_4943.field_22972.method_25852(
                    modLoc("block/quenched_allay_bricks_small"),
                    class_4944.method_25875(modLoc("block/deco/quenched_allay_bricks_small_0")),
                    blockStateModelGenerator.field_22831))
        );
    }

    private void blockAndItem(class_4910 blockModelGenerator, class_2248 block, class_2960 model) {
//        simpleBlock(block, model);
        blockModelGenerator.field_22830.accept(
            new dummyVariantGenerator(block, model)
        );
//        simpleBlockItem(block, model);
        class_2960 blockItemLocation = new class_4942(Optional.of(model), Optional.empty())
            .method_48525(block.method_8389(), new class_4944(), blockModelGenerator.field_22831);
        blockModelGenerator.field_55238.method_65460(
            block.method_8389(),
            class_10410.method_65481(blockItemLocation)
        );
    }

    private void axisBlock(class_4910 blockModelGenerator, class_2248 block, class_2960 baseTexture) {
        axisBlock(blockModelGenerator, block, baseTexture.method_48331("_side"), baseTexture.method_48331("_end"));
    }

    private void axisBlock(class_4910 blockModelGenerator, class_2248 block, class_2960 vertical, class_2960 horizontal) {
        class_2960 model = class_4943.field_22974
            .method_25846(
                block,
                new class_4944()
                    .method_25868(class_4945.field_23018, vertical)
                    .method_25868(class_4945.field_23013, horizontal),
                blockModelGenerator.field_22831
            );
        class_2960 modelHorizontal = class_4943.field_22975
            .method_25846(
                block,
                new class_4944()
                    .method_25868(class_4945.field_23018, vertical)
                    .method_25868(class_4945.field_23013, horizontal),
                blockModelGenerator.field_22831
            );
        blockModelGenerator.field_22830.accept(
            class_4925.method_25769(block).method_25775(
                class_4926.method_25783(class_2741.field_12496)
                    .method_25793(class_2350.class_2351.field_11048, class_4935.method_25824()
                        .method_25828(class_4936.field_22887, modelHorizontal)
                        .method_25828(class_4936.field_22885, class_4936.class_4937.field_22891)
                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                    .method_25793(class_2350.class_2351.field_11052, class_4935.method_25824()
                        .method_25828(class_4936.field_22887, model))
                    .method_25793(class_2350.class_2351.field_11051, class_4935.method_25824()
                        .method_25828(class_4936.field_22887, modelHorizontal)
                        .method_25828(class_4936.field_22885, class_4936.class_4937.field_22891))
            )
        );
        class_2960 blockItemLocation = new class_4942(Optional.of(model), Optional.empty())
            .method_48525(block.method_8389(), new class_4944(), blockModelGenerator.field_22831);
        blockModelGenerator.field_55238.method_65460(
            block.method_8389(),
            class_10410.method_65481(blockItemLocation)
        );
    }

    private void directionalBlock(class_4910 blockModelGenerator, class_2248 block, class_2960 model) {
        blockModelGenerator.field_22830.accept(
            class_4925.method_25769(block).method_25775(
                class_4926.method_25783(class_2741.field_12525)
                    .method_25795(dir -> class_4935.method_25824()
                        .method_25828(class_4936.field_22887, model)
                        .method_25828(class_4936.field_22885, dir == class_2350.field_11033 ? class_4936.class_4937.field_22892 : dir.method_10166().method_10179() ? class_4936.class_4937.field_22891 : class_4936.class_4937.field_22890)
                        .method_25828(class_4936.field_22886, dir.method_10166().method_10178() ? class_4936.class_4937.field_22890 : class_4936.class_4937.values()[(((((int) dir.method_10144()) + 180) % 360) / 90 + 4) % 4])
                    )
            )
        );
        class_2960 blockItemLocation = new class_4942(Optional.of(model), Optional.empty())
            .method_48525(block.method_8389(), new class_4944(), blockModelGenerator.field_22831);
        blockModelGenerator.field_55238.method_65460(
            block.method_8389(),
            class_10410.method_65481(blockItemLocation)
        );
    }

    private class dummyVariantGenerator implements class_4917 {
        private final class_2248 block;
        private final class_2960 loc;

        public dummyVariantGenerator(class_2248 block, class_2960 modelLoc) {
            this.block = block;
            this.loc = modelLoc;
        }

        @Override
        public class_2248 method_25743() {
            return this.block;
        }

        @Override
        public JsonElement get() {
            JsonObject main = new JsonObject();
            JsonObject variants = new JsonObject();
            JsonObject empty = new JsonObject();
            empty.addProperty("model", this.loc.toString());
            variants.add("", empty);
            main.add("variants", variants);
            return main;
        }
    }

    private class dummyArrayVariantGenerator implements class_4917 {
        private final class_2248 block;
        private final class_2960[] locs;
        private final Optional<Integer>[] weights;

        public dummyArrayVariantGenerator(class_2248 block, class_2960[] modelLoc, Optional<Integer>[] weights) {
            this.block = block;
            this.locs = modelLoc;
            this.weights = weights;
        }

        @Override
        public class_2248 method_25743() {
            return this.block;
        }

        @Override
        public JsonElement get() {
            JsonObject main = new JsonObject();
            JsonObject variants = new JsonObject();
            JsonArray empty = new JsonArray();
            for (int i = 0; i < locs.length; i++) {
                class_2960 loc = locs[i];
                JsonObject modelObject = new JsonObject();
                modelObject.addProperty("model", loc.toString());
                if (i < weights.length && weights[i].isPresent()) {
                    modelObject.addProperty("weight", weights[i].get());
                }
                empty.add(modelObject);
            }
            variants.add("", empty);
            main.add("variants", variants);
            return main;
        }
    }

    private void arrowCircleBlock(class_4910 blockStateModelGenerator,
                                  class_2248 block, String name, class_2960 particle,
                                  String frontStub,
                                  String topStub,
                                  String leftStub,
                                  String rightStub,
                                  String backStub,
                                  boolean itemModelIsLit
    ) {
        blockStateModelGenerator.field_22830.accept(
            class_4925.method_25769(block)
                .method_25775(class_4926.method_25784(
                            BlockCircleComponent.ENERGIZED,
                            class_2741.field_12525
                        )
                        .method_25800((isLit, dir) -> {
                                var litness = isLit ? "lit" : "dim";

                                var front = "block/circle/" + frontStub + "_" + litness;
                                var top = "block/circle/" + topStub + "_" + litness;
                                var left = "block/circle/" + leftStub + "_" + litness;
                                var right = "block/circle/" + rightStub + "_" + litness;
                                var back = "block/circle/" + backStub + "_" + litness;

                                var bottom = "block/circle/botton";

                                var modelName = "block/circle/" + name + "/" + litness + "_" + dir.method_10151();
                                class_4944 textureMapping = new class_4944()
                                    .method_25868(class_4945.field_23023, modLoc(top))
                                    .method_25868(class_4945.field_23024, modLoc(bottom))
                                    .method_25868(class_4945.field_23019, modLoc(front))
                                    .method_25868(class_4945.field_23021, modLoc(left))
                                    .method_25868(class_4945.field_23020, modLoc(back))
                                    .method_25868(class_4945.field_23022, modLoc(right))
                                    .method_25868(class_4945.field_23012, particle);

                                var model = class_4943.field_23400.method_25852(modLoc(modelName), textureMapping, blockStateModelGenerator.field_22831);

                                if (isLit == itemModelIsLit && dir == class_2350.field_11034) {
                                    class_4942 template = new class_4942(Optional.of(model), Optional.empty());
                                    template.method_25852(modLoc("item/" + name), new class_4944(), blockStateModelGenerator.field_22831);
                                    blockStateModelGenerator.field_55238.method_65460(
                                        block.method_8389(),
                                        class_10410.method_65481(modLoc("item/" + name))
                                    );
                                }

                                class_4935 returnValue = class_4935.method_25824()
                                    .method_25828(class_4936.field_22887, model);
                                var rotationX = dir.method_10166() == class_2350.class_2351.field_11052
                                    ? dir.method_10171().method_10181() * -90
                                    : 0;
                                if (rotationX != 0) {
                                    returnValue
                                        .method_25828(class_4936.field_22885, class_4936.class_4937.values()[(rotationX/90+4)%4]);
                                }
                                var rotationY = dir.method_10166() != class_2350.class_2351.field_11052
                                    ? ((dir.method_10161() + 2) % 4) * 90
                                    : 0;
                                if (rotationY != 0) {
                                    returnValue
                                        .method_25828(class_4936.field_22886, class_4936.class_4937.values()[(rotationY/90+4)%4]);
                                }
                                return returnValue;
                            }
                        )
                )
        );
    }

    private void impetus(class_4910 blockStateModelGenerator, class_2248 block, String name, String stub, boolean itemModelIsLit) {
        arrowCircleBlock(blockStateModelGenerator,
            block, name, modLoc("block/slate_block"),
            "impetus/" + stub + "/front",
            "impetus/" + stub + "/top",
            "impetus/" + stub + "/left",
            "impetus/" + stub + "/right",
            "impetus/back",
            itemModelIsLit
        );
    }

    private void doAllTheDirectrices(class_4910 blockStateModelGenerator) {
        arrowCircleBlock(blockStateModelGenerator, HexBlocks.EMPTY_DIRECTRIX, "directrix/empty", modLoc("block/slate_block"),
            "directrix/empty/front", "directrix/empty/top", "directrix/empty/left",
            "directrix/empty/right", "directrix/empty/back", false);

        blockStateModelGenerator.field_22830.accept(
            class_4925.method_25769(HexBlocks.DIRECTRIX_REDSTONE)
                .method_25775(class_4926.method_25785(
                    BlockCircleComponent.ENERGIZED,
                    class_2741.field_12484,
                    class_2741.field_12525
                ).method_25805((isLit, isPowered, dir) -> {
                    var litness = isLit ? "lit" : "dim";
                    var poweredness = isPowered ? "powered" : "unpowered";

                    var top = "block/circle/directrix/redstone/top_" + poweredness;
                    var left = "block/circle/directrix/redstone/left_" + poweredness;
                    var right = "block/circle/directrix/redstone/right_" + poweredness;

                    String frontEnding, backEnding;
                    if (isLit) {
                        if (isPowered) {
                            frontEnding = "lit_powered";
                            backEnding = "dim_powered";
                        } else {
                            frontEnding = "dim_unpowered";
                            backEnding = "lit_unpowered";
                        }
                    } else {
                        frontEnding = "dim_" + poweredness;
                        backEnding = "dim_" + poweredness;
                    }

                    var front = "block/circle/directrix/redstone/front_" + frontEnding;
                    var back = "block/circle/directrix/redstone/back_" + backEnding;
                    // and always the same
                    var bottom = "block/circle/bottom";

                    var modelName = "block/circle/directrix/redstone/" + litness + "_" + poweredness + "_" + dir.method_10151();

                    class_4944 textureMapping = new class_4944()
                        .method_25868(class_4945.field_23023, modLoc(top))
                        .method_25868(class_4945.field_23024, modLoc(bottom))
                        .method_25868(class_4945.field_23019, modLoc(front))
                        .method_25868(class_4945.field_23021, modLoc(left))
                        .method_25868(class_4945.field_23020, modLoc(back))
                        .method_25868(class_4945.field_23022, modLoc(right))
                        .method_25868(class_4945.field_23012, modLoc("block/slate_block"));

                    var model = class_4943.field_23400.method_25852(modLoc(modelName), textureMapping, blockStateModelGenerator.field_22831);

                    if (isLit && !isPowered && dir == class_2350.field_11034) {
                        // getBuilder does not add the block/etc to the front if the path contains any slashes
                        // this is a problem because the block IDs have slashes in them
                        class_4942 template = new class_4942(Optional.of(model), Optional.empty());
                        template.method_25852(modLoc("item/directrix/redstone"), new class_4944(), blockStateModelGenerator.field_22831);
                        blockStateModelGenerator.field_55238.method_65460(
                            HexBlocks.DIRECTRIX_REDSTONE.method_8389(),
                            class_10410.method_65481((modLoc("item/directrix/redstone")))
                        );
                    }

                    class_4935 returnValue = class_4935.method_25824()
                        .method_25828(class_4936.field_22887, model);
                    var rotationX = dir.method_10166() == class_2350.class_2351.field_11052
                        ? dir.method_10171().method_10181() * -90
                        : 0;
                    if (rotationX != 0) {
                        returnValue
                            .method_25828(class_4936.field_22885, class_4936.class_4937.values()[(rotationX/90+4)%4]);
                    }
                    var rotationY = dir.method_10166() != class_2350.class_2351.field_11052
                        ? ((dir.method_10161() + 2) % 4) * 90
                        : 0;
                    if (rotationY != 0) {
                        returnValue
                            .method_25828(class_4936.field_22886, class_4936.class_4937.values()[(rotationY/90+4)%4]);
                    }
                    return returnValue;
                }))
        );
        blockStateModelGenerator.field_22830.accept(
            class_4925.method_25769(HexBlocks.DIRECTRIX_BOOLEAN)
                .method_25775(class_4926.method_25785(
                    BlockCircleComponent.ENERGIZED,
                    BlockBooleanDirectrix.STATE,
                    class_2741.field_12525
                ).method_25805((isLit, boolState, dir) -> {
                    var litness = isLit ? "lit" : "dim";
                    var boolStateString = boolState.toString().toLowerCase();

                    var top = "block/circle/directrix/boolean/top_" + boolStateString;
                    var left = "block/circle/directrix/boolean/left_" + boolStateString;
                    var right = "block/circle/directrix/boolean/right_" + boolStateString;

                    String frontEnding = null, backEnding = null;
                    switch (boolState) {
                        case NEITHER -> {
                            frontEnding = "not_false";
                            backEnding = "not_true";
                        }
                        case TRUE -> {
                            frontEnding = "not_false";
                            backEnding = litness + "_true";
                        }
                        case FALSE -> {
                            frontEnding = litness + "_false";
                            backEnding = "not_true";
                        }
                    }

                    var front = "block/circle/directrix/boolean/front_" + frontEnding;
                    var back = "block/circle/directrix/boolean/back_" + backEnding;
                    // and always the same
                    var bottom = "block/circle/bottom";

                    var modelName = "block/circle/directrix/boolean/" + litness + "_" + boolStateString + "_" + dir.method_10151();

                    class_4944 textureMapping = new class_4944()
                        .method_25868(class_4945.field_23023, modLoc(top))
                        .method_25868(class_4945.field_23024, modLoc(bottom))
                        .method_25868(class_4945.field_23019, modLoc(front))
                        .method_25868(class_4945.field_23021, modLoc(left))
                        .method_25868(class_4945.field_23020, modLoc(back))
                        .method_25868(class_4945.field_23022, modLoc(right))
                        .method_25868(class_4945.field_23012, modLoc("block/slate_block"));

                    var model = class_4943.field_23400.method_25852(modLoc(modelName), textureMapping, blockStateModelGenerator.field_22831);

                    if (isLit && boolState == BlockBooleanDirectrix.State.FALSE && dir == class_2350.field_11034) {
                        // getBuilder does not add the block/etc to the front if the path contains any slashes
                        // this is a problem because the block IDs have slashes in them
                        class_4942 template = new class_4942(Optional.of(model), Optional.empty());
                        template.method_25852(modLoc("item/directrix/boolean"), new class_4944(), blockStateModelGenerator.field_22831);
                        blockStateModelGenerator.field_55238.method_65460(
                            HexBlocks.DIRECTRIX_BOOLEAN.method_8389(),
                            class_10410.method_65481((modLoc("item/directrix/boolean")))
                        );
                    }

                    class_4935 returnValue = class_4935.method_25824()
                        .method_25828(class_4936.field_22887, model);
                    var rotationX = dir.method_10166() == class_2350.class_2351.field_11052
                        ? dir.method_10171().method_10181() * -90
                        : 0;
                    if (rotationX != 0) {
                        returnValue
                            .method_25828(class_4936.field_22885, class_4936.class_4937.values()[(rotationX/90+4)%4]);
                    }
                    var rotationY = dir.method_10166() != class_2350.class_2351.field_11052
                        ? ((dir.method_10161() + 2) % 4) * 90
                        : 0;
                    if (rotationY != 0) {
                        returnValue
                            .method_25828(class_4936.field_22886, class_4936.class_4937.values()[(rotationY/90+4)%4]);
                    }
                    return returnValue;
                }))
        );
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        simpleItem(itemModelGenerator, HexItems.AMETHYST_DUST);
        simpleItem(itemModelGenerator, HexItems.CHARGED_AMETHYST);
        simpleItem(itemModelGenerator, HexItems.SUBMARINE_SANDWICH);
        simpleItem(itemModelGenerator, HexItems.ABACUS);
        simpleItem(itemModelGenerator, HexItems.JEWELER_HAMMER);
        simpleItem(itemModelGenerator, HexItems.CREATIVE_UNLOCKER);
        simpleItem(itemModelGenerator, HexItems.LORE_FRAGMENT);

        simpleItem(itemModelGenerator, HexBlocks.CONJURED_BLOCK.method_8389(), class_2960.method_60656("item/amethyst_shard"));
        simpleItem(itemModelGenerator, HexBlocks.CONJURED_LIGHT.method_8389(), class_2960.method_60656("item/amethyst_shard"));

        buildScroll(itemModelGenerator, HexItems.SCROLL_SMOL, "small");
        buildScroll(itemModelGenerator, HexItems.SCROLL_MEDIUM, "medium");
        buildScroll(itemModelGenerator, HexItems.SCROLL_LARGE, "large");

        for (var age : new String[]{"pristine", "ancient"}) {
            for (var size : new String[]{"small", "medium", "large"}) {
                class_2960 loc = modLoc("item/" + "scroll_" + age + "_" + size);
                class_4943.field_22938.method_25852(loc, class_4944.method_25895(loc), itemModelGenerator.field_55246);
            }
        }

        buildScryingLens(itemModelGenerator);

        class_4943.field_22940.method_25852(modLoc("item/staff/old"), class_4944.method_25895(modLoc("item/staff/old")), itemModelGenerator.field_55246);

        buildStaff(itemModelGenerator, HexItems.STAFF_OAK, "oak");
        buildStaff(itemModelGenerator, HexItems.STAFF_BIRCH, "birch");
        buildStaff(itemModelGenerator, HexItems.STAFF_SPRUCE, "spruce");
        buildStaff(itemModelGenerator, HexItems.STAFF_JUNGLE, "jungle");
        buildStaff(itemModelGenerator, HexItems.STAFF_DARK_OAK, "dark_oak");
        buildStaff(itemModelGenerator, HexItems.STAFF_ACACIA, "acacia");
        buildStaff(itemModelGenerator, HexItems.STAFF_CRIMSON, "crimson");
        buildStaff(itemModelGenerator, HexItems.STAFF_WARPED, "warped");
        buildStaff(itemModelGenerator, HexItems.STAFF_MANGROVE, "mangrove");
        buildStaff(itemModelGenerator, HexItems.STAFF_CHERRY, "cherry");
        buildStaff(itemModelGenerator, HexItems.STAFF_BAMBOO, "bamboo");
        buildStaff(itemModelGenerator, HexItems.STAFF_EDIFIED, "edified");
        buildStaff(itemModelGenerator, HexItems.STAFF_MINDSPLICE, "mindsplice");

//        buildFourVariantGaslight("item/staff/quenched", "item/staff/quenched", (name, path) ->
//            singleTexture(path.getPath(), ResourceLocation.withDefaultNamespace("item/handheld_rod"),
//                "layer0", modLoc(path.getPath())));
        buildFourVariantGaslight(itemModelGenerator.field_55245, HexItems.STAFF_QUENCHED, "item/staff/quenched", path ->
            class_4943.field_22940.method_25852(path, class_4944.method_25895(path), itemModelGenerator.field_55246));
//        buildFourVariantGaslight(getPath(HexItems.QUENCHED_SHARD), "item/quenched_shard", (name, path) ->
//            singleTexture(path.getPath(), ResourceLocation.withDefaultNamespace("item/handheld"),
//                "layer0", modLoc(path.getPath())));
        buildFourVariantGaslight(itemModelGenerator.field_55245, HexItems.QUENCHED_SHARD, "item/quenched_shard", path ->
            class_4943.field_22939.method_25852(path, class_4944.method_25895(path), itemModelGenerator.field_55246));

        class_4943.field_22938.method_25852(modLoc("item/patchouli_book"), class_4944.method_25895(modLoc("item/patchouli_book")), itemModelGenerator.field_55246);

        buildThoughtKnot(itemModelGenerator);

        buildSealableIotaHolder(itemModelGenerator, HexItems.FOCUS, "focus", HexItems.FOCUS.numVariants());
        buildSealableIotaHolder(itemModelGenerator, HexItems.SPELLBOOK, "spellbook", HexItems.SPELLBOOK.numVariants());

        buildPackagedSpell(itemModelGenerator, HexItems.ANCIENT_CYPHER, "ancient_cypher", HexItems.ANCIENT_CYPHER.numVariants());
        buildPackagedSpell(itemModelGenerator, HexItems.CYPHER, "cypher", HexItems.CYPHER.numVariants());
        buildPackagedSpell(itemModelGenerator, HexItems.TRINKET, "trinket", HexItems.TRINKET.numVariants());
        buildPackagedSpell(itemModelGenerator, HexItems.ARTIFACT, "artifact", HexItems.ARTIFACT.numVariants());

        List<class_10448.class_10449> maxMediaOverrides = new ArrayList<>();
        int maxFill = 4;
        for (int size = 0; size < PHIAL_SIZES.length; size++) {
            List<class_10448.class_10449> mediaPredicateOverrides = new ArrayList<>();
            for (int fill = 0; fill <= maxFill; fill++) {
                String name = "phial_" + PHIAL_SIZES[size] + "_" + fill;
//                singleTexture(
//                    name,
//                    ResourceLocation.withDefaultNamespace("item/generated"),
//                    "layer0", modLoc("item/phial/" + name));
                class_4943.field_22938.method_25852(
                    modLoc("item/" + name),
                    class_4944.method_25895(modLoc("item/phial/" + name)),
                    itemModelGenerator.field_55246
                );

                float fillProp = (float) fill / maxFill;
//                getBuilder(getPath(HexItems.BATTERY)).override()
//                    .predicate(ItemMediaBattery.MEDIA_PREDICATE, fillProp)
//                    .predicate(ItemMediaBattery.MAX_MEDIA_PREDICATE, size)
//                    .model(new ModelFile.UncheckedModelFile(modLoc("item/" + name)))
//                    .end();
                mediaPredicateOverrides.add(
                    class_10410.method_65486(
                        class_10410.method_65481(modLoc("item/" + name)),
                        fillProp
                    )
                );
            }
            maxMediaOverrides.add(
                class_10410.method_65486(
                    class_10410.method_65492(
                        new MediaPredicate(),
                        mediaPredicateOverrides
                    ),
                    size
                )
            );
        }
        itemModelGenerator.field_55245.method_65460(
            HexItems.BATTERY,
            class_10410.method_65492(
                new MaxMediaPredicate(),
                maxMediaOverrides
            )
        );

        for (var dye : class_1767.values()) {
//            singleTexture(getPath(HexItems.DYE_PIGMENTS.get(dye)),
//                ResourceLocation.withDefaultNamespace("item/generated"),
//                "layer0", modLoc("item/colorizer/dye_" + dye.getName()));
            simpleItem(itemModelGenerator, HexItems.DYE_PIGMENTS.get(dye),  modLoc("item/colorizer/dye_" + dye.method_7792()));
        }
        for (var type : ItemPridePigment.Type.values()) {
//            singleTexture(getPath(HexItems.PRIDE_PIGMENTS.get(type)),
//                ResourceLocation.withDefaultNamespace("item/generated"),
//                "layer0", modLoc("item/colorizer/pride_" + type.getName()));
            simpleItem(itemModelGenerator, HexItems.PRIDE_PIGMENTS.get(type), modLoc("item/colorizer/pride_" + type.getName()));
        }
        simpleItem(itemModelGenerator, HexItems.UUID_PIGMENT, modLoc("item/colorizer/uuid"));
        simpleItem(itemModelGenerator, HexItems.DEFAULT_PIGMENT, modLoc("item/colorizer/default"));
        simpleItem(itemModelGenerator, HexItems.ANCIENT_PIGMENT, modLoc("item/colorizer/ancient"));

        class_4943.field_22938.method_25852(modLoc("item/slate_blank"), class_4944.method_25895(modLoc("item/slate_blank")), itemModelGenerator.field_55246);
        class_4943.field_22938.method_25852(modLoc("item/slate_written"), class_4944.method_25895(modLoc("item/slate_written")), itemModelGenerator.field_55246);
        itemModelGenerator.field_55245.method_65460(
            HexItems.SLATE,
            class_10410.method_65492(
                new ItemSlateWrittenPredicate(),
                List.of(
                    class_10410.method_65486(
                        class_10410.method_65481(modLoc("item/slate_blank")),
                        0f
                    ),
                    class_10410.method_65486(
                        class_10410.method_65481(modLoc("item/slate_written")),
                        1f
                    )
                )
            )
        );

    }

    private class_2960 simpleItem(class_4915 itemModelGenerator, class_1792 item) {
        class_2960 loc = itemModelGenerator.method_65434(item, class_4943.field_22938);
        itemModelGenerator.field_55245.method_65460(item, class_10410.method_65481(loc));
        return loc;
    }

    private class_2960 simpleItem(class_4915 itemModelGenerator, class_1792 item, class_2960 texture) {
        class_2960 loc = class_4943.field_22938.method_48525(item, class_4944.method_25895(texture), itemModelGenerator.field_55246);
        itemModelGenerator.field_55245.method_65460(item, class_10410.method_65481(loc));
        return loc;
    }


    private void buildThoughtKnot(class_4915 itemModelGenerator) {
        var unwritten = class_4944.method_25895(modLoc("item/thought_knot"));
        class_2960 thoughtKnotModelLocation = class_4943.field_22938.method_48525(HexItems.THOUGHT_KNOT, unwritten, itemModelGenerator.field_55246);
        var written = class_4944.method_48529(modLoc("item/thought_knot"), modLoc("item/thought_knot_overlay"));
        class_2960 thoughtKnotWrittenModelLocation = class_4943.field_42232.method_25852(modLoc("item/thought_knot_written"), written, itemModelGenerator.field_55246);
        itemModelGenerator.field_55245.method_65460(
            HexItems.THOUGHT_KNOT,
            class_10410.method_65490(
                new ThoughtKnotWrittenPredicate(),
                class_10410.method_65483(
                    thoughtKnotModelLocation,
                    class_10410.method_65480(0xff_ffffff),
                    new IotaStorageColorizerTintSource(new class_1799(HexItems.THOUGHT_KNOT))
                ),
                List.of(
                    class_10410.method_65486(
                        class_10410.method_65483(
                            thoughtKnotModelLocation,
                            class_10410.method_65480(0xff_ffffff),
                            new IotaStorageColorizerTintSource(new class_1799(HexItems.THOUGHT_KNOT))
                        ),
                        0
                    ),
                    class_10410.method_65486(
                        class_10410.method_65483(
                            thoughtKnotWrittenModelLocation,
                            class_10410.method_65480(0xff_ffffff),
                            new IotaStorageColorizerTintSource(new class_1799(HexItems.THOUGHT_KNOT))
                        ),
                        1
                    )
                )
            )
        );
    }

    private void buildSealableIotaHolder(class_4915 itemModelGenerators, class_1792 item, String stub, int numVariants) {
//        var name = getPath(item);
//        var builder = getBuilder(name);
        List<class_10448.class_10449> variantOverrides = new ArrayList<>();
        for (int i = 0; i < numVariants; i++) {
            List<class_10448.class_10449> overlayOverrides = new ArrayList<>();
//            var plain = i == 0 ? singleTexture(name, ResourceLocation.withDefaultNamespace("item/generated"),
//                "layer0", modLoc("item/cad/" + i + "_" + stub + "_empty"))
//                : withExistingParent(name + "_" + i, ResourceLocation.withDefaultNamespace("item/generated"))
//                .texture("layer0", modLoc("item/cad/" + i + "_" + stub + "_empty"));
            var plain = i == 0 ? class_4943.field_22938.method_48525(
                item,
                class_4944.method_25895(
                    modLoc("item/cad/" + i + "_" + stub + "_empty")
                ),
                itemModelGenerators.field_55246
            ) : class_4943.field_22938.method_25852(
                class_4941.method_25840(item).method_48331("_" + i),
                class_4944.method_25895(
                    modLoc("item/cad/" + i + "_" + stub + "_empty")
                ),
                itemModelGenerators.field_55246);
//            var unsealed = withExistingParent(name + "_" + i + "_filled", ResourceLocation.withDefaultNamespace("item/generated"))
//                .texture("layer0", modLoc("item/cad/" + i + "_" + stub + "_filled"))
//                .texture("layer1", modLoc("item/cad/" + i + "_" + stub + "_filled_overlay"));
            var unsealed = class_4943.field_42232.method_25852(
                class_4941.method_25840(item).method_48331("_" + i + "_filled"),
                class_4944.method_48529(
                    modLoc("item/cad/" + i + "_" + stub + "_filled"),
                    modLoc("item/cad/" + i + "_" + stub + "_filled_overlay")
                ),
                itemModelGenerators.field_55246);
//            var sealed = withExistingParent(name + "_" + i + "_sealed", ResourceLocation.withDefaultNamespace("item/generated"))
//                .texture("layer0", modLoc("item/cad/" + i + "_" + stub + "_sealed"))
//                .texture("layer1", modLoc("item/cad/" + i + "_" + stub + "_sealed_overlay"));
            var sealed = class_4943.field_42232.method_25852(
                class_4941.method_25840(item).method_48331("_" + i + "_sealed"),
                class_4944.method_48529(
                    modLoc("item/cad/" + i + "_" + stub + "_sealed"),
                    modLoc("item/cad/" + i + "_" + stub + "_sealed_overlay")
                ),
                itemModelGenerators.field_55246);
//            builder.override().predicate(ItemFocus.VARIANT_PRED, i).predicate(ItemFocus.OVERLAY_PRED, 0f)
//                .model(plain).end()
//                .override().predicate(ItemFocus.VARIANT_PRED, i).predicate(ItemFocus.OVERLAY_PRED, 1f)
//                .model(unsealed).end()
//                .override().predicate(ItemFocus.VARIANT_PRED, i).predicate(ItemFocus.OVERLAY_PRED, 2f)
//                .model(sealed).end();
            overlayOverrides.add(
                class_10410.method_65486(
                    class_10410.method_65483(
                        plain,
                        class_10410.method_65480(0xff_ffffff),
                        new IotaStorageColorizerTintSource(new class_1799(item))
                    ),
                    0f
                )
            );
            overlayOverrides.add(class_10410.method_65486(
                class_10410.method_65483(
                    unsealed,
                    class_10410.method_65480(0xff_ffffff),
                    new IotaStorageColorizerTintSource(new class_1799(item))
                ),
                1f
            ));
            overlayOverrides.add(class_10410.method_65486(
                class_10410.method_65483(
                    sealed,
                    class_10410.method_65480(0xff_ffffff),
                    new IotaStorageColorizerTintSource(new class_1799(item))
                ),
                2f
            ));
            variantOverrides.add(
                class_10410.method_65486(
                    class_10410.method_65492(
                        new OverlayPredicate(),
                        overlayOverrides
                    ),
                    i
                )
            );
        }
        itemModelGenerators.field_55245.method_65460(
            item,
            class_10410.method_65492(
                new VariantPredicate(),
                variantOverrides
            )
        );
    }

    private void buildScroll(class_4915 itemModelGenerator, class_1792 item, String size) {
        itemModelGenerator.field_55245.method_65460(
            item,
            class_10410.method_65492(
                new AncientPredicate(),
                List.of(
                    class_10410.method_65486(
                        class_10410.method_65481(
                            modLoc("item/scroll_pristine_" + size)
                        ),
                        0
                    ),
                    class_10410.method_65486(
                        class_10410.method_65481(
                            modLoc("item/scroll_ancient_" + size)
                        ),
                        1
                    )
                )
            )
        );
    }

    private void buildScryingLens(class_4915 itemModelGenerator) {
        itemModelGenerator.field_55246.accept(
            class_4941.method_25840(HexItems.SCRYING_LENS),
            () -> {
                JsonObject modelFile = new JsonObject();
                modelFile.addProperty("parent", class_2960.method_60656("item/" + "generated").toString());
                JsonObject displayObject = new JsonObject();
                JsonObject headObject = new JsonObject();

                JsonArray headTranslationArray = new JsonArray();
                headTranslationArray.add(-2.5f);
                headTranslationArray.add(0);
                headTranslationArray.add(-8);
                headObject.add("translation", headTranslationArray);

                JsonArray headScaleArray = new JsonArray();
                headScaleArray.add(0.4);
                headScaleArray.add(0.4);
                headScaleArray.add(0.4);
                headObject.add("scale", headScaleArray);

                displayObject.add("head", headObject);
                modelFile.add("display", displayObject);

                class_4944 textureMapping = class_4944.method_25871(HexItems.SCRYING_LENS);
                Map<class_4945, class_2960> map = Streams.concat(
                        Stream.of(class_4945.field_23006),
                        textureMapping.method_25861())
                    .collect(ImmutableMap.toImmutableMap(Function.identity(), textureMapping::method_25867));
                if (!map.isEmpty()) {
                    JsonObject texturesObject = new JsonObject();
                    map.forEach((textureSlot, resourceLocationx) -> texturesObject.addProperty(textureSlot.method_25912(), resourceLocationx.toString()));
                    modelFile.add("textures", texturesObject);
                }
                return modelFile;
            }
        );
        itemModelGenerator.field_55245.method_65460(HexItems.SCRYING_LENS, class_10410.method_65481(class_4941.method_25840(HexItems.SCRYING_LENS)));
    }

    private void buildStaff(class_4915 itemModelGenerator, class_1792 item, String name) {
        class_4943.field_22940.method_25852(
            class_4941.method_25840(item),
            class_4944.method_25895(modLoc("item/staff/" + name)),
            itemModelGenerator.field_55246);
        itemModelGenerator.field_55245.method_65460(
            item,
            class_10410.method_65492(
                new FunnyLevelPredicate(),
                List.of(
//                    Is their code bad or am I just stupid? Below is direct copy, but item/name_staff is never generated
//                    ItemModelUtils.override(
//                        ItemModelUtils.plainModel(modLoc("item/" + name + "_staff")),
//                        0
//                    ),
//                    My fix below (cuz this new system makes it kinda required to fix it or else missing texture will appear
                    class_10410.method_65486(
                        class_10410.method_65481(class_4941.method_25840(item)),
                        0
                    ),
                    class_10410.method_65486(
                        class_10410.method_65481(modLoc("item/staff/old")),
                        1
                    ),
                    class_10410.method_65486(
                        class_10410.method_65481(modLoc("item/staff/cherry")),
                        2
                    )
                )
            )
        );
    }

    private void buildPackagedSpell(class_4915 itemModelGenerator, class_1792 item, String stub, int numVariants) {
        List<class_10448.class_10449> variantOverrides = new ArrayList<>();
        for (int i = 0; i < numVariants; i++) {
            List<class_10448.class_10449> hasPatternsOverrides = new ArrayList<>();
            var plainTemplate = Arrays.asList(PACKAGED_SPELL_HANDHELD_VARIANTS).contains(i) ? class_4943.field_22940 : class_4943.field_22938;
            var filledTemplate = Arrays.asList(PACKAGED_SPELL_HANDHELD_VARIANTS).contains(i) ? class_4943.field_22940 : class_4943.field_42232;
//            var plain = i == 0 ? singleTexture(name, ResourceLocation.withDefaultNamespace(parent_tag),
//                "layer0", modLoc("item/cad/" + i + "_" + stub))
//                : withExistingParent(name + "_" + i, ResourceLocation.withDefaultNamespace(parent_tag))
//                .texture("layer0", modLoc("item/cad/" + i + "_" + stub));
            var plain = i == 0 ? plainTemplate.method_48525(item, class_4944.method_25895(modLoc("item/cad/" + i + "_" + stub)), itemModelGenerator.field_55246)
                : plainTemplate.method_25852(class_4941.method_25840(item).method_48331("_" + i),
                class_4944.method_25895(modLoc("item/cad/" + i + "_" + stub)), itemModelGenerator.field_55246);
//            var filled = withExistingParent(name + "_" + i + "_filled", ResourceLocation.withDefaultNamespace(parent_tag))
//                .texture("layer0", modLoc("item/cad/" + i + "_" + stub))
//                .texture("layer1", modLoc("item/cad/" + i + "_" + stub + "_overlay"));
            var filled = filledTemplate.method_25852(class_4941.method_25840(item).method_48331("_" + i + "_filled"),
                class_4944.method_48529(
                    modLoc("item/cad/" + i + "_" + stub),
                    modLoc("item/cad/" + i + "_" + stub + "_overlay")
                ),
                itemModelGenerator.field_55246);
//            builder.override().predicate(ItemFocus.VARIANT_PRED, i).predicate(ItemPackagedHex.HAS_PATTERNS_PRED, -0.01f)
//                .model(plain).end()
//                .override().predicate(ItemFocus.VARIANT_PRED, i).predicate(ItemPackagedHex.HAS_PATTERNS_PRED, 1f - 0.01f)
//                .model(filled).end();
            hasPatternsOverrides.add(
                class_10410.method_65486(
                    class_10410.method_65481(plain),
                    -0.01f
                )
            );
            hasPatternsOverrides.add(
                class_10410.method_65486(
                    class_10410.method_65481(filled),
                1f - 0.01f
                )
            );
            variantOverrides.add(
                class_10410.method_65486(
                    class_10410.method_65492(
                        new HasPatternsPredicate(),
                        hasPatternsOverrides
                    ),
                    i
                )
            );
        }
            itemModelGenerator.field_55245.method_65460(
                item,
                class_10410.method_65492(
                    new VariantPredicate(),
                    variantOverrides
                )
            );
    }

    private void buildFourVariantGaslight(class_10405 itemModelOutput, class_1935 item, String texturePath,
                                          Function<class_2960, class_2960> makeModel) {
        List<class_10448.class_10449> overrides = new ArrayList<>();
        for (int i = 0; i < BlockQuenchedAllay.VARIANTS; i++) {
            var textureLoc = modLoc(texturePath + "_" + i);
            var model = makeModel.apply(textureLoc);
            overrides.add(
                class_10410.method_65486(
                    class_10410.method_65481(model),
                    i
                )
            );
        }
        itemModelOutput.method_65460(
            item.method_8389(),
            class_10410.method_65492(
                new GasLightingPredicate(),
                overrides
            )
        );
    }

    @Override
    public @NotNull String method_10321() {
        return "Hexcasting Item Models";
    }
}
