package at.petrak.hexcasting.xplat;

import at.petrak.hexcasting.api.HexAPI;
import org.apache.commons.lang3.function.TriFunction;

import java.util.ServiceLoader;
import java.util.stream.Collectors;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;

public interface IXplatAccessoriesAbstractions {
    boolean accessoryModInstalled();
    class_1269 customUseCode(class_1937 level, class_1657 player, class_1268 interactionHand, TriFunction<class_1937, class_1657, class_1268, class_1269> originalFunc);

    ///

    IXplatAccessoriesAbstractions INSTANCE = find();

    private static IXplatAccessoriesAbstractions find() {
        var providers = ServiceLoader.load(IXplatAccessoriesAbstractions.class).stream().toList();
        if (providers.size() != 1) {
            var names = providers.stream().map(p -> p.type().getName()).collect(Collectors.joining(",", "[", "]"));
            throw new IllegalStateException(
                "There should be exactly one IXplatAccessoriesAbstractions implementation on the classpath. Found: " + names);
        } else {
            var provider = providers.get(0);
            HexAPI.LOGGER.debug("Instantiating xplat impl: " + provider.type().getName());
            return provider.get();
        }
    }
}
