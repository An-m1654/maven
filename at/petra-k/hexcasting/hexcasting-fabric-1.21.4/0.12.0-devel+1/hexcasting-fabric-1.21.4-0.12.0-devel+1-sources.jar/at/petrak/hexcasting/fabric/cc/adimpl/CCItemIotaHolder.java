package at.petrak.hexcasting.fabric.cc.adimpl;

import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.item.IotaHolderItem;
import org.jetbrains.annotations.Nullable;
import org.ladysnake.cca.api.v3.component.Component;

import java.util.function.Function;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_7225;

public abstract class CCItemIotaHolder implements CCIotaHolder, Component {
    final class_1799 stack;
    public CCItemIotaHolder(class_1799 stack) {
        this.stack = stack;
    }

    public static class ItemBased extends CCItemIotaHolder {
        private final IotaHolderItem iotaHolder;

        public ItemBased(class_1799 stack) {
            super(stack);
            if (!(stack.method_7909() instanceof IotaHolderItem data)) {
                throw new IllegalStateException("item is not a data holder: " + stack);
            }
            this.iotaHolder = data;
        }

        @Override
        public @Nullable Iota readIota() {
            return this.iotaHolder.readIota(this.stack);
        }

        @Override
        public boolean writeable() {
            return this.iotaHolder.writeable(this.stack);
        }

        @Override
        public boolean writeIota(@Nullable Iota iota, boolean simulate) {
            var canWrite = this.iotaHolder.canWrite(this.stack, iota);
            if (!canWrite) {
                return false;
            }
            if (!simulate) {
                this.iotaHolder.writeDatum(this.stack, iota);
            }
            return true;
        }

        @Override
        public void readFromNbt(class_2487 compoundTag, class_7225.class_7874 provider) {

        }

        @Override
        public void writeToNbt(class_2487 compoundTag, class_7225.class_7874 provider) {

        }
    }

    public static class Static extends CCItemIotaHolder {
        private final Function<class_1799, Iota> provider;

        public Static(class_1799 stack, Function<class_1799, Iota> provider) {
            super(stack);
            this.provider = provider;
        }

        @Override
        public @Nullable Iota readIota() {
            return this.provider.apply(this.stack);
        }

        @Override
        public boolean writeable() {
            return false;
        }

        @Override
        public boolean writeIota(@Nullable Iota datum, boolean simulate) {
            return false;
        }

        @Override
        public void readFromNbt(class_2487 tag, class_7225.class_7874 registryLookup) {

        }

        @Override
        public void writeToNbt(class_2487 tag, class_7225.class_7874 registryLookup) {

        }
    }
}
