package at.petrak.hexcasting.fabric.mixin;

import at.petrak.hexcasting.fabric.event.VillagerConversionCallback;
import net.minecraft.class_1538;
import net.minecraft.class_1640;
import net.minecraft.class_1646;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_1646.class)
public class FabricVillagerTurnIntoWitchMixin {
    @Inject(method = "thunderHit", locals = LocalCapture.CAPTURE_FAILSOFT, at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;addFreshEntityWithPassengers(Lnet/minecraft/world/entity/Entity;)V"))
    public void onThunderHit(class_3218 serverLevel, class_1538 lightningBolt, CallbackInfo ci, class_1640 newWitch) {
        var self = (class_1646) (Object) this;
        VillagerConversionCallback.EVENT.invoker().interact(self, newWitch);
    }
}
