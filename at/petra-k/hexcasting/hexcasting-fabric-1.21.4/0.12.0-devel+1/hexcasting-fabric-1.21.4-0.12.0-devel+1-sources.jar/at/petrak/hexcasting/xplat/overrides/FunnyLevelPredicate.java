package at.petrak.hexcasting.xplat.overrides;

import at.petrak.hexcasting.common.lib.HexDataComponents;
import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.Nullable;

import java.util.Locale;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1800;
import net.minecraft.class_638;
import net.minecraft.class_9334;

public record FunnyLevelPredicate() implements class_1800 {
    public static final MapCodec<FunnyLevelPredicate> MAP_CODEC = MapCodec.unit(FunnyLevelPredicate::new);
    @Override
    public float method_65644(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 holder, int holderID) {
        if (!stack.method_57826(class_9334.field_49631)) {
            return 0;
        }
        var name = stack.method_7964().getString().toLowerCase(Locale.ROOT);
        if (name.contains("old")) {
            return 1f;
        } else if (name.contains("cherry")) {
            return 2f;
        } else {
            return 0f;
        }
    }

    @Override
    public MapCodec<? extends class_1800> method_65643() {
        return MAP_CODEC;
    }
}
