package at.petrak.hexcasting.fabric.interop.trinkets;

import at.petrak.hexcasting.api.misc.DiscoveryHandlers;
import at.petrak.hexcasting.common.items.HexBaubleItem;
import at.petrak.hexcasting.common.items.ItemLens;
import at.petrak.hexcasting.common.items.magic.ItemCreativeUnlocker;
import at.petrak.hexcasting.common.lib.HexItems;
import com.google.common.collect.Multimap;
import dev.emi.trinkets.api.SlotReference;
import dev.emi.trinkets.api.Trinket;
import dev.emi.trinkets.api.TrinketComponent;
import dev.emi.trinkets.api.TrinketsApi;
import java.util.List;
import java.util.Optional;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3545;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

import static dev.emi.trinkets.api.client.TrinketRendererRegistry.registerRenderer;

public class TrinketsApiInterop {
    public static void init() {
        class_7923.field_41178.method_10220().forEach(item -> {
            if (item instanceof HexBaubleItem bauble) {
                TrinketsApi.registerTrinket(item, new Trinket() {
                    @Override
                    public Multimap<class_6880<class_1320>, class_1322> getModifiers(class_1799 stack, SlotReference slot, class_1309 entity, class_2960 slotIdentifier) {
                        return bauble.getHexBaubleAttrs(stack);
                    }

                    @Override
                    public boolean canEquip(class_1799 stack, SlotReference slot, class_1309 entity) {
                        return Trinket.super.canEquip(stack, slot, entity);
                    }
                });
            }
        });


        DiscoveryHandlers.addDebugItemDiscoverer((player, type) -> {
            Optional<TrinketComponent> slots = TrinketsApi.getTrinketComponent(player);
            if (slots.isPresent()) {
                var stack2 = slots.get().getEquipped(stack -> ItemCreativeUnlocker.isDebug(stack, type));
                if (stack2 != null) return stack2.getFirst().method_15441();
            }
            return class_1799.field_8037;
        });

        DiscoveryHandlers.addExtraEquipmentDiscoverer(player -> {
            Optional<TrinketComponent> optional = TrinketsApi.getTrinketComponent(player);
            if (optional.isPresent()) {
                TrinketComponent component = optional.get();
                return component.getEquipped(i -> !i.method_7960()).stream()
                        .map(class_3545::method_15441)
                        .toList();
            }
            return List.of();
        });
    }

    @Environment(EnvType.CLIENT)
    public static void clientInit() {
        registerRenderer(HexItems.SCRYING_LENS, new LensTrinketRenderer());
    }
}