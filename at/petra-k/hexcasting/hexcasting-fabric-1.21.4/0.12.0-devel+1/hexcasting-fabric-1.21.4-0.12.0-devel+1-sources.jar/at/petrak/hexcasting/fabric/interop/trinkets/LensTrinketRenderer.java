package at.petrak.hexcasting.fabric.interop.trinkets;

import at.petrak.hexcasting.common.lib.HexItems;
import dev.emi.trinkets.api.SlotReference;
import dev.emi.trinkets.api.Trinket;
import dev.emi.trinkets.api.client.TrinketRenderer;
import net.minecraft.class_10034;
import net.minecraft.class_10042;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_583;
import net.minecraft.class_591;
import net.minecraft.class_7833;
import net.minecraft.class_811;

/**
 * @author WireSegal
 * Created at 9:50 AM on 7/25/22.
 */
public class LensTrinketRenderer implements TrinketRenderer {
    @Override
    public void render(class_1799 stack, SlotReference slotReference, class_583<? extends class_10042> model,
                       class_4587 matrices, class_4597 multiBufferSource, int light, class_10042 renderState,
                       float limbAngle, float limbDistance) {
        //LivingEntityRenderState livingEntityRenderState, float v, float v1
        if (stack.method_31574(HexItems.SCRYING_LENS) &&
                model instanceof class_591 playerModel && renderState instanceof class_10034 humanoidRenderState) {
            // from https://github.com/Creators-of-Create/Create/blob/ee33823ed0b5084af10ed131a1626ce71db4c07e/src/main/java/com/simibubi/create/compat/curios/GogglesCurioRenderer.java

            // Translate and rotate with our head
            matrices.method_22903();
            TrinketRenderer.followBodyRotations(model, playerModel);
            TrinketRenderer.translateToFace(matrices, playerModel, humanoidRenderState, playerModel.method_2838().field_3675 * class_3532.field_29848, playerModel.method_2838().field_3654 * class_3532.field_29848);

            // Translate and scale to our head
            matrices.method_22904(0, 0, 0.3);
            matrices.method_22907(class_7833.field_40718.rotationDegrees(180.0f));
            matrices.method_22905(0.625f, 0.625f, 0.625f);

            // Render
            var instance = class_310.method_1551();
            instance.method_1480().method_23178(stack, class_811.field_4316,
                    light, class_4608.field_21444, matrices, multiBufferSource, instance.field_1687, 0);
            matrices.method_22909();
        }
    }
}
