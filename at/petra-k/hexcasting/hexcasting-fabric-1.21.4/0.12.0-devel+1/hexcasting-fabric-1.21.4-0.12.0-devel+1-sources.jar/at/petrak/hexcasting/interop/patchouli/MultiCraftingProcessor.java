/*
 * This class is distributed as part of the Botania Mod.
 * Get the Source Code in github:
 * https://github.com/Vazkii/Botania
 *
 * Botania is Open Source and distributed under the
 * Botania License: http://botaniamod.net/license.php
 */
package at.petrak.hexcasting.interop.patchouli;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.lib.HexItems;
import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.class_1856;
import net.minecraft.class_1869;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_9694;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.Nullable;
import vazkii.patchouli.api.IComponentProcessor;
import vazkii.patchouli.api.IVariable;
import vazkii.patchouli.api.IVariableProvider;

import javax.swing.text.html.Option;
import java.util.*;
import java.util.stream.Collectors;

public class MultiCraftingProcessor implements IComponentProcessor {
    private List<class_3955> recipes;
    private boolean shapeless = true;
    private int longestIngredientSize = 0;
    private boolean hasCustomHeading;

    @Override
    public void setup(class_1937 level, IVariableProvider vars) {
        List<String> names = vars.get("recipes", level.method_30349()).asStream(level.method_30349()).map(IVariable::asString).toList();
        this.recipes = new ArrayList<>();
        for (String name : names) {
            class_3955 recipe = PatchouliUtils.getRecipe(level, class_3956.field_17545, class_2960.method_60654(name));
            if (recipe != null) {
                recipes.add(recipe);
                if (shapeless) {
                    shapeless = !(recipe instanceof class_1869);
                }
                for (class_1856 ingredient : recipe.method_61671().method_64675()) {
                    int size = ingredient.method_8105().toArray().length;
                    if (longestIngredientSize < size) {
                        longestIngredientSize = size;
                    }
                }
            } else {
                HexAPI.LOGGER.warn("Missing crafting recipe " + name);
            }
        }
        this.hasCustomHeading = vars.has("heading");
    }

    @Override
    public @Nullable IVariable process(class_1937 level, String key) {
        if (recipes.isEmpty()) {
            return null;
        }
        if (key.equals("heading")) {
            if (!hasCustomHeading) {
//                    return IVariable.from(recipes.getFirst().getResultItem(level.registryAccess()).getHoverName(), level.registryAccess());
                return IVariable.from(recipes.getFirst().method_8116(class_9694.field_51631, level.method_30349()).method_7964(), level.method_30349());
            }
            return null;
        }
        if (key.startsWith("input")) {
            int index = Integer.parseInt(key.substring(5)) - 1;
            int shapedX = index % 3;
            int shapedY = index / 3;
            List<Optional<class_1856>> ingredients = new ArrayList<>();
            for (class_3955 recipe : recipes) {
                if (recipe instanceof class_1869 shaped) {
                    if (shaped.method_8150() < shapedX + 1) {
                        ingredients.add(Optional.empty());
                    } else {
                        int realIndex = index - (shapedY * (3 - shaped.method_8150()));
                        List<Integer> locationsList = recipe.method_61671().method_65800();
                        List<Optional<class_1856>> list = locationsList.stream().map(i -> i == -1 ? (Optional.<class_1856>empty()) : Optional.of(recipe.method_61671().method_64675().get(i))).toList();
                        ingredients.add(list.size() > realIndex ? list.get(realIndex) : Optional.empty());
                    }

                } else {
                    List<class_1856> list = recipe.method_61671().method_64675();
                    ingredients.add(list.size() > index ? Optional.of(list.get(index)) : Optional.empty());
                }
            }
            return PatchouliUtils.interweaveIngredients(ingredients, longestIngredientSize, level.method_30349());
        }
        if (key.equals("output")) {
            return IVariable.wrapList(
                recipes.stream()
                        .map(recipe -> recipe.method_8116(class_9694.field_51631, level.method_30349()))
                        .map(v -> IVariable.from(v, level.method_30349()))
                        .collect(Collectors.toList()), level.method_30349());
        }
        if (key.equals("shapeless")) {
            return IVariable.wrap(shapeless, level.method_30349());
        }
        return null;
    }
}
