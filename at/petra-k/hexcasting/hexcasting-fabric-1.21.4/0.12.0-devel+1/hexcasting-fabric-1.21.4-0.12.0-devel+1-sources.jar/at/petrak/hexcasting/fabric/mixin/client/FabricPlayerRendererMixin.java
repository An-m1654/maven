package at.petrak.hexcasting.fabric.mixin.client;

import at.petrak.hexcasting.client.model.AltioraLayer;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public abstract class FabricPlayerRendererMixin extends class_922<class_742, class_10055, class_591> {
    public FabricPlayerRendererMixin(class_5617.class_5618 context, class_591 entityModel, float f) {
        super(context, entityModel, f);
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void addAltiora(class_5617.class_5618 ctx, boolean bl, CallbackInfo ci) {
        this.method_4046(new AltioraLayer<>(this, ctx.method_32170()));
    }
}
