package at.petrak.hexcasting.interop.patchouli;

import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.class_9695;
import net.minecraft.world.item.crafting.*;
import vazkii.patchouli.api.IVariable;
import vazkii.patchouli.client.base.ClientRecipes;

import java.util.*;
import java.util.stream.Collectors;

/**
 * > no this is a "literally copy these files/parts of file into your mod"
 * > we should put this in patchy but lol
 * > lazy
 * -- Hubry Vazcord
 */
public class PatchouliUtils {
    @SuppressWarnings("unchecked")
    public static <T extends class_1860<I>, I extends class_9695> T getRecipe(class_1937 level, class_3956<T> type, class_2960 id) {
        // PageDoubleRecipeRegistry
        IXplatAbstractions.INSTANCE.askForRecipes();
        var recipe = ClientRecipes.getRecipeById(class_5321.method_29179(class_7924.field_52178, id));
        assert recipe != null;
        if (recipe.comp_1933().method_17716() == type) {
            return (T) recipe.comp_1933();
        } else {
            return null;
        }
    }

    /**
     * Combines the ingredients, returning the first matching stack of each, then the second stack of each, etc.
     * looping back ingredients that run out of matched stacks, until the ingredients reach the length
     * of the longest ingredient in the recipe set.
     *
     * @param ingredients           List of ingredients in the specific slot
     * @param longestIngredientSize Longest ingredient in the entire recipe
     * @return Serialized Patchouli ingredient string
     */
    public static IVariable interweaveIngredients(List<Optional<class_1856>> ingredients, int longestIngredientSize, class_7225.class_7226.Provider registries) {
        if (ingredients.size() == 1) {
//            return IVariable.wrapList(Arrays.stream(ingredients.get(0).getItems())
//                    .map(v -> IVariable.from(v, registries))
//                    .collect(Collectors.toList()), registries);
            if (ingredients.getFirst().isPresent()) {
                return IVariable.wrapList(Arrays.stream(ingredients.getFirst().get().method_8105().toArray())
                    .map(v -> IVariable.from(v, registries))
                    .collect(Collectors.toList()), registries);
            }
            return IVariable.empty();
        }

        class_1799[] empty = {class_1799.field_8037};
        List<class_1799[]> stacks = new ArrayList<>();
        for (Optional<class_1856> ingredient : ingredients) {
            if (ingredient.isPresent()) {
                stacks.add(ingredient.get().method_8105().map(class_1799::new).toArray(class_1799[]::new));
            } else {
                stacks.add(empty);
            }
        }
        List<IVariable> list = new ArrayList<>(stacks.size() * longestIngredientSize);
        for (int i = 0; i < longestIngredientSize; i++) {
            for (class_1799[] stack : stacks) {
                list.add(IVariable.from(stack[i % stack.length], registries));
            }
        }
        return IVariable.wrapList(list, registries);
    }

    /**
     * Overload of the method above that uses the provided list's longest ingredient size.
     */
    public static IVariable interweaveIngredients(List<Optional<class_1856>> ingredients, class_7225.class_7226.Provider registries) {
        return interweaveIngredients(ingredients,
            ingredients.stream().mapToInt(ingr -> ingr.isPresent() ? ingr.get().method_8105().toArray().length : 0).max().orElse(1), registries
        );
    }
}
