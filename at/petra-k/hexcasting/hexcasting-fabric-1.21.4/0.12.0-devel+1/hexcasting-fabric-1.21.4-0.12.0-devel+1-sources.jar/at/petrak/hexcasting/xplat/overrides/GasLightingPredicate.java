package at.petrak.hexcasting.xplat.overrides;

import at.petrak.hexcasting.client.render.GaslightingTracker;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1800;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;

public record GasLightingPredicate() implements class_1800 {
    public static final MapCodec<GasLightingPredicate> MAP_CODEC = MapCodec.unit(GasLightingPredicate::new);
    @Override
    public float method_65644(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 holder, int holderID) {
        return Math.abs(GaslightingTracker.getGaslightingAmount() % 4);
    }

    @Override
    public MapCodec<? extends class_1800> method_65643() {
        return MAP_CODEC;
    }
}
