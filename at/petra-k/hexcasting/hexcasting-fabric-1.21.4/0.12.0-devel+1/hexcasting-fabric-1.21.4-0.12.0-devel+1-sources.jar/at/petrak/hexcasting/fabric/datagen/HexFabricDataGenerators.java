package at.petrak.hexcasting.fabric.datagen;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.datagen.HexLootTables;
import at.petrak.hexcasting.datagen.IXplatIngredients;
import at.petrak.hexcasting.datagen.recipe.HexplatRecipes;
import at.petrak.hexcasting.datagen.recipe.builders.FarmersDelightToolIngredient;
import at.petrak.hexcasting.datagen.tag.HexActionTagProvider;
import at.petrak.hexcasting.datagen.tag.HexBlockTagProvider;
import at.petrak.hexcasting.datagen.tag.HexItemTagProvider;
import at.petrak.hexcasting.fabric.recipe.FabricModConditionalIngredient;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatTags;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags;
import net.minecraft.class_173;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2438;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7877;
import net.minecraft.class_7924;
import net.minecraft.world.item.*;
import java.util.EnumMap;
import java.util.List;
import java.util.Set;

public class HexFabricDataGenerators implements DataGeneratorEntrypoint {
    @Override
    public void onInitializeDataGenerator(FabricDataGenerator gen) {
        HexAPI.LOGGER.info("Starting Fabric-specific datagen");

        FabricDataGenerator.Pack pack = gen.createPack();
        IXplatTags xtags = IXplatAbstractions.INSTANCE.tags();

        pack.addProvider((output, lookup) -> new HexplatRecipes.Runner(output, lookup, INGREDIENTS, HexFabricConditionsBuilder::new));

        var btagProviderWrapper = new BlockTagProviderWrapper(); // CURSED
        pack.addProvider((output, lookup) -> {
            btagProviderWrapper.provider = new HexBlockTagProvider(output, lookup, xtags);
            return btagProviderWrapper.provider;
        });
        pack.addProvider((output, lookup) -> new HexItemTagProvider(output, lookup, btagProviderWrapper.provider.method_49662(), xtags));

        pack.addProvider(HexActionTagProvider::new);

        pack.addProvider((output, lookup) -> new class_2438(
                output, Set.of(), List.of(new class_2438.class_7790(HexLootTables::new, class_173.field_1177)), lookup
        ));

        pack.addProvider(HexModels::new);
    }

    private static class BlockTagProviderWrapper {
        HexBlockTagProvider provider;
    }

    private static final IXplatIngredients INGREDIENTS = new IXplatIngredients() {
        @Override
        public class_6862<class_1792> glowstoneDust() {
                /*return new Ingredient(HolderSet.direct(
                        Ingredient.of(Items.GLOWSTONE_DUST),
                        Ingredient.of(items.getOrThrow(tag("glowstone_dusts")))
                ));*/
            return ConventionalItemTags.GLOWSTONE_DUSTS;
        }

        @Override
        public class_1856 leather() {
            // apparently c:leather also includes rabbit hide
            return class_1856.method_8101(class_1802.field_8745);
        }

        @Override
        public class_6862<class_1792> ironNugget() {
//                return new Ingredient(Stream.of(
//                        new Ingredient.ItemValue(new ItemStack(Items.IRON_NUGGET)),
//                        new Ingredient.TagValue(tag("iron_nuggets"))
//                ));
            return ConventionalItemTags.IRON_NUGGETS;
        }

        @Override
        public class_6862<class_1792> goldNugget() {
//                return new Ingredient(Stream.of(
//                        new Ingredient.ItemValue(new ItemStack(Items.GOLD_NUGGET)),
//                        new Ingredient.TagValue(tag("gold_nuggets"))
//                ));
            return ConventionalItemTags.GOLD_NUGGETS;
        }

        @Override
        public class_6862<class_1792> copperIngot() {
//                return new Ingredient(Stream.of(
//                        new Ingredient.ItemValue(new ItemStack(Items.COPPER_INGOT)),
//                        new Ingredient.TagValue(tag("copper_ingots"))
//                ));
            return ConventionalItemTags.COPPER_INGOTS;
        }

        @Override
        public class_6862<class_1792> ironIngot() {
//                return new Ingredient(Stream.of(
//                        new Ingredient.ItemValue(new ItemStack(Items.IRON_INGOT)),
//                        new Ingredient.TagValue(tag("iron_ingots"))
//                ));
            return ConventionalItemTags.IRON_INGOTS;
        }

        @Override
        public class_6862<class_1792> goldIngot() {
//                return new Ingredient(Stream.of(
//                        new Ingredient.ItemValue(new ItemStack(Items.GOLD_INGOT)),
//                        new Ingredient.TagValue(tag("gold_ingots"))
//                ));
            return ConventionalItemTags.GOLD_INGOTS;
        }

        @Override
        public EnumMap<class_1767, class_6862<class_1792>> dyes() {
            var out = new EnumMap<class_1767, class_6862<class_1792>>(class_1767.class);
            for (var col : class_1767.values()) {
//                    out.put(col, new Ingredient(Stream.of(
//                            new Ingredient.ItemValue(new ItemStack(DyeItem.byColor(col))),
//                            new Ingredient.TagValue(
//                                    TagKey.create(Registries.ITEM,
//                                            ResourceLocation.fromNamespaceAndPath("c", col.getSerializedName() + "_dye"))),
//                            new Ingredient.TagValue(
//                                    TagKey.create(Registries.ITEM,
//                                            ResourceLocation.fromNamespaceAndPath("c", col.getSerializedName() + "_dyes"))
//                            ))));
//                ArrayList<TagKey<Item>> list = new ArrayList<>(List.of(new ItemStack(DyeItem.byColor(col)).getItemHolder()));
                out.put(col, class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "dyes/" + col.method_15434())));
            }
            return out;
        }

        @Override
        public class_6862<class_1792> stick() {
//                return new Ingredient(Stream.of(
//                        new Ingredient.ItemValue(new ItemStack(Items.STICK)),
//                        new Ingredient.TagValue(tag("wood_sticks"))
//                ));
            return ConventionalItemTags.WOODEN_RODS;
        }

        @Override
        public class_1856 whenModIngredient(class_1856 defaultIngredient, String modid, class_1856 modIngredient) {
            return FabricModConditionalIngredient.of(defaultIngredient, modid, modIngredient);
        }

        private final FarmersDelightToolIngredient AXE_INGREDIENT = () -> {
            JsonObject object = new JsonObject();
            object.addProperty("type", "farmersdelight:tool");
            object.addProperty("tag", "c:tools/axes");
            return object;
        };

        @Override
        public FarmersDelightToolIngredient axeStrip() {
            return AXE_INGREDIENT;
        }

        @Override
        public FarmersDelightToolIngredient axeDig() {
            return AXE_INGREDIENT;
        }
    };

    private static class_6862<class_1792> tag(String s) {
        return tag("c", s);
    }

    private static class_6862<class_1792> tag(String namespace, String s) {
        return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(namespace, s));
    }

    @Override
    public void buildRegistry(class_7877 registryBuilder) {

    }
}
