package at.petrak.hexcasting.xplat.overrides;

import at.petrak.hexcasting.api.item.VariantItem;
import at.petrak.hexcasting.common.items.magic.ItemPackagedHex;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1800;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;

// suck it fabric trying to be "safe"
public record HasPatternsPredicate() implements class_1800 {
    public static final MapCodec<HasPatternsPredicate> MAP_CODEC = MapCodec.unit(HasPatternsPredicate::new);
    @Override
    public float method_65644(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity,
                     int seed) {
        if (stack.method_7909() instanceof ItemPackagedHex hexItem) {
            return hexItem.hasHex(stack) ? 1f : 0f;
        }
        return 0f;
    }

    @Override
    public MapCodec<? extends class_1800> method_65643() {
        return MAP_CODEC;
    }
}