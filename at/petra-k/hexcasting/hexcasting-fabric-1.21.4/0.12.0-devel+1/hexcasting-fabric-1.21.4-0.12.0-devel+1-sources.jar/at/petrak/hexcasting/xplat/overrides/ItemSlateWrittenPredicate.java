package at.petrak.hexcasting.xplat.overrides;

import at.petrak.hexcasting.common.items.storage.ItemSlate;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1800;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;

public record ItemSlateWrittenPredicate() implements class_1800 {
    public static final MapCodec<ItemSlateWrittenPredicate> MAP_CODEC = MapCodec.unit(ItemSlateWrittenPredicate::new);
    @Override
    public float method_65644(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity,
                     int seed) {
        return ItemSlate.hasPattern(stack) ? 1f : 0f;
    }

    @Override
    public MapCodec<? extends class_1800> method_65643() {
        return MAP_CODEC;
    }
}