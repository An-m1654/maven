package at.petrak.hexcasting.mixin.client;

import at.petrak.hexcasting.api.client.ClientRenderHelper;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_1657;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public abstract class MixinPlayerRenderer extends class_922<class_742, class_10055, class_591> {
    Float partialTick = 0f;
    class_1657 player;

    public MixinPlayerRenderer(class_5617.class_5618 context, class_591 entityModel, float f) {
        super(context, entityModel, f);
    }

    @Inject(method = "extractRenderState(Lnet/minecraft/client/player/AbstractClientPlayer;Lnet/minecraft/client/renderer/entity/state/PlayerRenderState;F)V", at = @At("TAIL"))
    public void getPartialTick(class_742 abstractClientPlayer, class_10055 playerRenderState, float f, CallbackInfo ci) {
        partialTick = f;
        player = abstractClientPlayer;
    }

    @Inject(method = "Lnet/minecraft/client/renderer/entity/player/PlayerRenderer;<init>(Lnet/minecraft/client/renderer/entity/EntityRendererProvider$Context;Z)V", at = @At("TAIL"))
    public void addRenderCastingStackLayer(class_5617.class_5618 context, boolean bl, CallbackInfo ci) {
       this.method_4046(new class_3887<>((class_1007) (Object) this) {
            @Override
            public void render(class_4587 ps, class_4597 bs, int lightCoords, class_10055 playerRenderState, float yRot, float xRot) {
                ClientRenderHelper.renderCastingStack(ps, player, partialTick);
            }
        });
    }
}
