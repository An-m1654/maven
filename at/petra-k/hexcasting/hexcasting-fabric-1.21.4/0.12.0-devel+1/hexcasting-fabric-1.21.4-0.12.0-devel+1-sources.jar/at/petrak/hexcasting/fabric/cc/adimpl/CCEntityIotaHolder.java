package at.petrak.hexcasting.fabric.cc.adimpl;

import at.petrak.hexcasting.api.addldata.ItemDelegatingEntityIotaHolder;
import at.petrak.hexcasting.api.casting.iota.Iota;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class CCEntityIotaHolder implements CCIotaHolder {
    @Override
    public void writeToNbt(@NotNull class_2487 tag, class_7225.class_7874 registryLookup) {
        // NO-OP
    }

    @Override
    public void readFromNbt(@NotNull class_2487 tag, class_7225.class_7874 registryLookup) {
        // NO-OP
    }

    public static class Wrapper extends CCEntityIotaHolder {
        private final ItemDelegatingEntityIotaHolder inner;

        public Wrapper(ItemDelegatingEntityIotaHolder inner) {
            this.inner = inner;
        }


        @Override
        public @Nullable Iota readIota() {
            return inner.readIota();
        }

        @Override
        public boolean writeable() {
            return inner.writeable();
        }

        @Override
        public boolean writeIota(@Nullable Iota iota, boolean simulate) {
            return inner.writeIota(iota, simulate);
        }

        @Override
        public @Nullable Iota emptyIota() {
            return inner.emptyIota();
        }
    }
}
