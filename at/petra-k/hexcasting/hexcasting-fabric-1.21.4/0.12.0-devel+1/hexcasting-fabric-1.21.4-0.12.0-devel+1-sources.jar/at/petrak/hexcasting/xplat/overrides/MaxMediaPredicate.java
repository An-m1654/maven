package at.petrak.hexcasting.xplat.overrides;

import at.petrak.hexcasting.api.item.MediaHolderItem;
import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.common.items.magic.ItemMediaBattery;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1800;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;

// suck it fabric trying to be "safe"
public record MaxMediaPredicate() implements class_1800 {
    public static final MapCodec<MaxMediaPredicate> MAP_CODEC = MapCodec.unit(MaxMediaPredicate::new);
    @Override
    public float method_65644(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity,
                     int seed) {
        if (stack.method_7909() instanceof ItemMediaBattery item) {
            var max = item.getMaxMedia(stack);
            return 1.049658f * (float) Math.log((float) max / MediaConstants.CRYSTAL_UNIT + 9.06152f) - 2.1436f;
        }
        return 0;
    }

    @Override
    public MapCodec<? extends class_1800> method_65643() {
        return MAP_CODEC;
    }
}