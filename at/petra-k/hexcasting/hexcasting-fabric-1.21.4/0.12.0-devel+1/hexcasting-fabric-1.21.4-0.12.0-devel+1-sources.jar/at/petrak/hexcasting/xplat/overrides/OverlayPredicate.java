package at.petrak.hexcasting.xplat.overrides;

import at.petrak.hexcasting.api.item.IotaHolderItem;
import at.petrak.hexcasting.api.item.OverlayItem;
import at.petrak.hexcasting.api.item.VariantItem;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.Nullable;

import java.util.function.Predicate;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1800;
import net.minecraft.class_638;

// suck it fabric trying to be "safe"
public record OverlayPredicate() implements class_1800 {
    public static final MapCodec<OverlayPredicate> MAP_CODEC = MapCodec.unit(OverlayPredicate::new);
    @Override
    public float method_65644(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity,
                     int seed) {
        if (stack.method_7909() instanceof OverlayItem overlayItem) {
            Predicate<class_1799> hasIota = overlayItem.hasIota();
            if (!hasIota.test(stack) && !stack.method_57826(HexDataComponents.VISUAL_OVERRIDE)) {
                return 0;
            }
            Predicate<class_1799> isSealed = overlayItem.isSealed();
            if (!isSealed.test(stack)) {
                return 1;
            }
            return 2;
        }
        return 0;
    }

    @Override
    public MapCodec<? extends class_1800> method_65643() {
        return MAP_CODEC;
    }
}