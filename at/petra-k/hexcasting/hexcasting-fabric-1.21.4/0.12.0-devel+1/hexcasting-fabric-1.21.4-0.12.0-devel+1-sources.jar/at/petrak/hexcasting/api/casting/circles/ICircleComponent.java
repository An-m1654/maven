package at.petrak.hexcasting.api.casting.circles;

import at.petrak.hexcasting.api.block.circle.BlockCircleComponent;
import at.petrak.hexcasting.api.casting.ParticleSpray;
import at.petrak.hexcasting.api.casting.eval.env.CircleCastEnv;
import at.petrak.hexcasting.api.casting.eval.sideeffects.OperatorSideEffect;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import at.petrak.hexcasting.api.casting.eval.vm.CastingVM;
import at.petrak.hexcasting.api.casting.mishaps.Mishap;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.lib.HexSounds;
import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.Contract;

import java.util.EnumSet;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_156;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3532;

/**
 * Implement this on a block to make circles interact with it.
 * <p>
 * This is its own interface so you can have your blocks subclass something else, and to avoid enormous
 * files. The mod doesn't check for the interface on anything but blocks.
 */
public interface ICircleComponent {
    /**
     * The heart of the interface! Functionally modify the casting environment.
     * <p>
     * With the new update you can have the side effects happen inline. In fact, you have to have the side effects
     * happen inline.
     * <p>
     * Also, return a list of directions that the control flow can exit this block in.
     * The circle environment will mishap if not exactly 1 of the returned directions can be accepted from.
     */
    ControlFlow acceptControlFlow(CastingImage imageIn, CircleCastEnv env, class_2350 enterDir, class_2338 pos,
        class_2680 bs, class_3218 world);

    /**
     * Can this component get transferred to from a block coming in from that direction, with the given normal?
     */
    @Contract(pure = true)
    boolean canEnterFromDirection(class_2350 enterDir, class_2338 pos, class_2680 bs, class_3218 world);

    /**
     * This determines the directions the control flow <em>can</em> exit from. It's called at the beginning of execution
     * to see if the circle actually forms a loop.
     * <p>
     * For most blocks, this should be the same as returned from {@link ICircleComponent#acceptControlFlow}
     * Things like directrices might return otherwise. Whatever is returned when controlling flow must be a subset of
     * this set.
     */
    @Contract(pure = true)
    EnumSet<class_2350> possibleExitDirections(class_2338 pos, class_2680 bs, class_1937 world);

    /**
     * Given the current position and a direction, return a pair of the new position after a step
     * in that direction, along with the direction (this is a helper function for creating
     * {@link ICircleComponent.ControlFlow}s.
     */
    @Contract(pure = true)
    default Pair<class_2338, class_2350> exitPositionFromDirection(class_2338 pos, class_2350 dir) {
        return Pair.of(pos.method_10069(dir.method_10148(), dir.method_10164(), dir.method_10165()), dir);
    }

    /**
     * Start the {@link ICircleComponent} at the given position glowing. Returns the new state
     * of the given block.
     * // TODO: determine if this should just be in
     * {@link ICircleComponent#acceptControlFlow(CastingImage, CircleCastEnv, class_2350, class_2338, class_2680, class_3218)}.
     */
    class_2680 startEnergized(class_2338 pos, class_2680 bs, class_1937 world);

    /**
     * Returns whether the {@link ICircleComponent} at the given position is energized.
     */
    boolean isEnergized(class_2338 pos, class_2680 bs, class_1937 world);

    /**
     * End the {@link ICircleComponent} at the given position glowing. Returns the new state of
     * the given block.
     */
    class_2680 endEnergized(class_2338 pos, class_2680 bs, class_1937 world);

    static void sfx(class_2338 pos, class_2680 bs, class_1937 world, BlockEntityAbstractImpetus impetus, boolean success) {
        class_243 vpos;
        class_243 vecOutDir;
        FrozenPigment colorizer;

        UUID activator = class_156.field_25140;
        if (impetus != null && impetus.getExecutionState() != null && impetus.getExecutionState().caster != null)
            activator = impetus.getExecutionState().caster;

        if (impetus == null || impetus.getExecutionState() == null)
            colorizer = new FrozenPigment(new class_1799(HexItems.DYE_PIGMENTS.get(class_1767.field_7964)), activator);
        else
            colorizer = impetus.getPigment();

        if (bs.method_26204() instanceof BlockCircleComponent bcc) {
            var outDir = bcc.normalDir(pos, bs, world);
            var height = bcc.particleHeight(pos, bs, world);
            vecOutDir = new class_243(outDir.method_23955());
            vpos = class_243.method_24953(pos).method_1019(vecOutDir.method_1021(height));
        } else {
            // we probably are doing this because it's an error and we removed a block
            vpos = class_243.method_24953(pos);
            vecOutDir = new class_243(0, 0, 0);
        }

        if (world instanceof class_3218 serverLevel) {
            var spray = new ParticleSpray(vpos, vecOutDir.method_1021(success ? 1.0 : 1.5), success ? 0.1 : 0.5,
                class_3532.field_29844 / (success ? 4 : 2), success ? 30 : 100);
            spray.sprayParticles(serverLevel,
                success ? colorizer : new FrozenPigment(new class_1799(HexItems.DYE_PIGMENTS.get(class_1767.field_7964)),
                    activator));
        }

        var pitch = 1f;
        var sound = HexSounds.SPELL_CIRCLE_FAIL;
        if (success && impetus != null) {
            sound = HexSounds.SPELL_CIRCLE_FIND_BLOCK;

            var state = impetus.getExecutionState();

            // This is a good use of my time
            var note = state.reachedSlate - 1;
            var semitone = impetus.semitoneFromScale((int) note);
            pitch = (float) Math.pow(2.0, (semitone - 8) / 12d);
        }
        world.method_43128(null, vpos.field_1352, vpos.field_1351, vpos.field_1350, sound, class_3419.field_15245, 1f, pitch);
    }

    /**
     * Helper function to "throw a mishap"
     */
    default void fakeThrowMishap(class_2338 pos, class_2680 bs, CastingImage image, CircleCastEnv env, Mishap mishap) {
        Mishap.Context errorCtx = new Mishap.Context(null,
            bs.method_26204().method_9518().method_27693(" (").method_10852(class_2561.method_43470(pos.method_23854())).method_27693(")"));
        var sideEffect = new OperatorSideEffect.DoMishap(mishap, errorCtx);
        var vm = new CastingVM(image, env);
        sideEffect.performEffect(vm);
    }

    abstract sealed class ControlFlow {
        public static final class Continue extends ControlFlow {
            public final CastingImage update;
            public final List<Pair<class_2338, class_2350>> exits;

            public Continue(CastingImage update, List<Pair<class_2338, class_2350>> exits) {
                this.update = update;
                this.exits = exits;
            }
        }

        public static final class Stop extends ControlFlow {
        }
    }
}
