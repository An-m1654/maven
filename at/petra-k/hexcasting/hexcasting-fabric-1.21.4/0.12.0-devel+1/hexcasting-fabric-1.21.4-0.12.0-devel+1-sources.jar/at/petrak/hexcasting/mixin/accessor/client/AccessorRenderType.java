package at.petrak.hexcasting.mixin.accessor.client;

import net.minecraft.class_1921;
import net.minecraft.class_293;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

// https://github.com/VazkiiMods/Botania/blob/13b7bcd9cbb6b1a418b0afe455662d29b46f1a7f/Xplat/src/main/java/vazkii/botania/mixin/client/AccessorRenderType.java
@Mixin(class_1921.class)
public interface AccessorRenderType {
    @Invoker("create")
    static class_1921.class_4687 hex$create(String string, class_293 vertexFormat,
                                                 class_293.class_5596 mode, int bufSize, boolean hasCrumbling, boolean sortOnUpload,
                                                 class_1921.class_4688 compositeState) {
        throw new IllegalStateException();
    }
}
