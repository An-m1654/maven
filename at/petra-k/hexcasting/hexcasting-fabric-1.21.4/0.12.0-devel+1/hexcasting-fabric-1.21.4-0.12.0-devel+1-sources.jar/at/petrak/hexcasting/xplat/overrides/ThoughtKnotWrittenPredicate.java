package at.petrak.hexcasting.xplat.overrides;

import at.petrak.hexcasting.common.lib.HexDataComponents;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1800;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;

public record ThoughtKnotWrittenPredicate() implements class_1800 {
    public static final MapCodec<ThoughtKnotWrittenPredicate> MAP_CODEC = MapCodec.unit(ThoughtKnotWrittenPredicate::new);
    @Override
    public float method_65644(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 holder, int holderID) {
        if (stack.method_57826(HexDataComponents.IOTA_HOLDER_IOTA)) {
            return 1;
        } else {
            return 0;
        }
    }

    @Override
    public MapCodec<? extends class_1800> method_65643() {
        return MAP_CODEC;
    }
}
