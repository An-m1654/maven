package at.petrak.hexcasting.fabric.cc;

import at.petrak.hexcasting.api.pigment.FrozenPigment;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;
import org.ladysnake.cca.api.v3.component.Component;
import org.ladysnake.cca.api.v3.component.sync.AutoSyncedComponent;

/**
 * Holds the pigment item favored by the player
 */
public class CCFavoredPigment implements Component, AutoSyncedComponent {
    public static final String TAG_PIGMENT = "pigment";

    private final class_1657 owner;

    public CCFavoredPigment(class_1657 owner) {
        this.owner = owner;
    }

    private FrozenPigment pigment = FrozenPigment.DEFAULT.get();

    public FrozenPigment getPigment() {
        return pigment;
    }

    public FrozenPigment setPigment(@Nullable FrozenPigment pigment) {
        var old = this.pigment;
        this.pigment = pigment != null ? pigment : FrozenPigment.DEFAULT.get();
        HexCardinalComponents.FAVORED_PIGMENT.sync(this.owner);
        return old;
    }

    @Override
    public void readFromNbt(class_2487 tag, class_7225.class_7874 registryLookup) {
        this.pigment = FrozenPigment.fromNBT(registryLookup, tag.method_10562(TAG_PIGMENT));
    }

    @Override
    public void writeToNbt(class_2487 tag, class_7225.class_7874 registryLookup) {
        tag.method_10566(TAG_PIGMENT, this.pigment.serializeToNBT(registryLookup));
    }
}
