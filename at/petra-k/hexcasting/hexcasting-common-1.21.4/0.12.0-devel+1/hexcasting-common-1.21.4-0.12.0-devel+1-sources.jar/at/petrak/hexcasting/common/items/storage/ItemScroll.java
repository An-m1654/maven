package at.petrak.hexcasting.common.items.storage;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.PatternIota;
import at.petrak.hexcasting.api.item.IotaHolderItem;
import at.petrak.hexcasting.client.gui.PatternTooltipComponent;
import at.petrak.hexcasting.common.casting.PatternRegistryManifest;
import at.petrak.hexcasting.common.entities.EntityWallScroll;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.misc.PatternTooltip;
import at.petrak.hexcasting.interop.inline.InlinePatternData;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5632;
import net.minecraft.class_5712;
import net.minecraft.class_9334;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

/**
 * TAG_OP_ID and TAG_PATTERN: "Ancient Scroll of %s" (per-world pattern preloaded)
 * <br>
 * TAG_OP_ID: "Ancient Scroll of %s" (per-world pattern loaded on inv tick)
 * <br>
 * TAG_PATTERN: "Scroll" (custom)
 * <br>
 * (none): "Empty Scroll"
 */
public class ItemScroll extends class_1792 implements IotaHolderItem {
    public static final class_2960 ANCIENT_PREDICATE = modLoc("ancient");

    public final int blockSize;

    public ItemScroll(class_1793 pProperties, int blockSize) {
        super(pProperties);
        this.blockSize = blockSize;
    }

    // this produces a scroll that will load the correct pattern for your world once it ticks
    public static class_1799 withPerWorldPattern(class_1799 stack, class_5321<ActionRegistryEntry> action) {
        class_1792 item = stack.method_7909();
        if (item instanceof ItemScroll) {
            stack.method_57379(HexDataComponents.ACTION, action);
        }

        return stack;
    }

    @Override
    public boolean writeable(class_1799 stack) {
        return true;
    }

    @Override
    public boolean canWrite(class_1799 stack, Iota datum) {
        return datum instanceof PatternIota || datum == null;
    }

    @Override
    public void writeDatum(class_1799 stack, Iota datum) {
        if (this.canWrite(stack, datum)) {
            if (datum instanceof PatternIota pat) {
                stack.method_57379(HexDataComponents.PATTERN, pat.getPattern());
            } else if (datum == null) {
                stack.method_57381(HexDataComponents.PATTERN);
            }
        }
    }

    @Override
    public class_1269 method_7884(class_1838 ctx) {
        var posClicked = ctx.method_8037();
        var direction = ctx.method_8038();
        var posInFront = posClicked.method_10093(direction);
        class_1657 player = ctx.method_8036();
        class_1799 itemstack = ctx.method_8041();
        if (player != null && !this.mayPlace(player, direction, itemstack, posInFront)) {
            return class_1269.field_5814;
        }
        var level = ctx.method_8045();
        var scrollStack = itemstack.method_7972();
        scrollStack.method_7939(1);
        var scrollEntity = new EntityWallScroll(level, posInFront, direction, scrollStack, false, this.blockSize);

        // i guess
        var customData = itemstack.method_57824(class_9334.field_49628);
        if (customData != null) {
            class_1299.method_5881(level, player, scrollEntity, customData);
        }

        if (scrollEntity.method_6888()) {
            if (!level.field_9236) {
                scrollEntity.method_6894();
                level.method_33596(player, class_5712.field_28738, posClicked);
                level.method_8649(scrollEntity);
            }

            itemstack.method_7934(1);
            return level.field_9236 ? class_1269.field_5812 : class_1269.field_21466;
        } else {
            return class_1269.field_21466;
        }
    }

    // [VanillaCopy] of HangingEntityItem
    protected boolean mayPlace(class_1657 pPlayer, class_2350 pDirection, class_1799 pHangingEntityStack, class_2338 pPos) {
        return !pDirection.method_10166().method_10178() && pPlayer.method_7343(pPos, pDirection, pHangingEntityStack);
    }

    @Override
    public class_2561 method_7864(class_1799 pStack) {
        var descID = this.method_7876();
        var ancientAction = pStack.method_57824(HexDataComponents.ACTION);
        if (ancientAction != null) {
            return class_2561.method_43469(descID + ".of",
                class_2561.method_43471("hexcasting.action." + ancientAction.method_29177()));
        } else if (pStack.method_57826(HexDataComponents.PATTERN)) {
            var pattern = pStack.method_57824(HexDataComponents.PATTERN);
            var patternLabel = class_2561.method_43470("");
            if (pattern != null) {
                patternLabel = class_2561.method_43470(": ").method_10852(new InlinePatternData(pattern).asText(false));
            }
            return class_2561.method_43471(descID.toString()).method_10852(patternLabel);
        } else {
            return class_2561.method_43471(descID + ".empty");
        }
    }

    @Override
    public void method_7888(class_1799 pStack, class_1937 pLevel, class_1297 pEntity, int pSlotId, boolean pIsSelected) {
        // the needs_purchase tag is used so you can't see the pattern on scrolls sold by a wandering trader
        // once you put the scroll into your inventory, this removes the tag to reveal the pattern
        if(pStack.method_57826(HexDataComponents.NEEDS_PURCHASE))
            pStack.method_57381(HexDataComponents.NEEDS_PURCHASE);
        // if op_id is set but there's no stored pattern, attempt to load the pattern on inv tick
        if (pStack.method_57826(HexDataComponents.ACTION) && !pStack.method_57826(HexDataComponents.PATTERN) && pEntity.method_5682() != null) {
            var action = pStack.method_57824(HexDataComponents.ACTION);
            if (action == null) {
                // if the provided op_id is invalid, remove it so we don't keep trying every tick
                pStack.method_57381(HexDataComponents.ACTION);
                return;
            }
            var pat = PatternRegistryManifest.getCanonicalStrokesPerWorld(action, pEntity.method_5682().method_30002());
            if (pat == null) {
                // if pat is null, the per-world order hasn't been registered; remove the op_id and warn the player
                pStack.method_57379(HexDataComponents.RECALC_WARNING, action);
                pStack.method_57381(HexDataComponents.ACTION);
                return;
            }
            pStack.method_57379(HexDataComponents.PATTERN, pat);
        }
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        if (stack.method_57826(HexDataComponents.NEEDS_PURCHASE)) {
            var needsPurchase = class_2561.method_43471("hexcasting.tooltip.scroll.needs_purchase");
            tooltipComponents.add(needsPurchase.method_27692(class_124.field_1080));
        } else if (stack.method_57826(HexDataComponents.RECALC_WARNING)) {
            var spellName = class_2561.method_43471("hexcasting.action." + stack.method_57824(HexDataComponents.RECALC_WARNING));
            var line1 = class_2561.method_43469("hexcasting.tooltip.scroll.recalc_warning.line1", spellName);
            var line2 = class_2561.method_43471("hexcasting.tooltip.scroll.recalc_warning.line2");
            tooltipComponents.add(line1.method_27692(class_124.field_1061));
            tooltipComponents.add(line2.method_27692(class_124.field_1061));
        } else if (stack.method_57826(HexDataComponents.ACTION) && !stack.method_57826(HexDataComponents.PATTERN)) {
            var notLoaded = class_2561.method_43471("hexcasting.tooltip.scroll.pattern_not_loaded");
            tooltipComponents.add(notLoaded.method_27692(class_124.field_1080));
        }
    }

    @Override
    public Optional<class_5632> method_32346(class_1799 stack) {
        var pattern = stack.method_57824(HexDataComponents.PATTERN);
        if (pattern != null && !stack.method_57826(HexDataComponents.NEEDS_PURCHASE)) {
            return Optional.of(new PatternTooltip(
                pattern,
                    stack.method_57826(HexDataComponents.ACTION)
                    ? PatternTooltipComponent.ANCIENT_BG
                    : PatternTooltipComponent.PRISTINE_BG));
        }

        return Optional.empty();
    }

    @Override
    public @Nullable Iota readIota(class_1799 stack) {
        var pattern = stack.method_57824(HexDataComponents.PATTERN);
        return pattern != null ? new PatternIota(pattern) : null;
    }
}
