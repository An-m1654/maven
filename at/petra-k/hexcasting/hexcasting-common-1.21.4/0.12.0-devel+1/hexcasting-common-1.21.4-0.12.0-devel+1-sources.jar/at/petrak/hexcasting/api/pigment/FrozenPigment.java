package at.petrak.hexcasting.api.pigment;

import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_4844;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * A snapshot of a pigment item and its owner.
 * <p>
 * Due to capabilities being really slow to query many times a tick on Forge, this returns a colorizer <i>supplier</i>.
 * Get it once, and then query it a lot.
 */
public record FrozenPigment(class_1799 item, UUID owner) {
    public static final String TAG_STACK = "stack";
    public static final String TAG_OWNER = "owner";

    public static final Supplier<FrozenPigment> DEFAULT =
            () -> new FrozenPigment(new class_1799(HexItems.DEFAULT_PIGMENT), class_156.field_25140);
    public static final Supplier<FrozenPigment> ANCIENT =
            () -> new FrozenPigment(new class_1799(HexItems.ANCIENT_PIGMENT), class_156.field_25140);

    public static Codec<FrozenPigment> CODEC = RecordCodecBuilder.<FrozenPigment>create(inst ->
            inst.group(
                class_1799.field_24671.fieldOf("stack").forGetter(FrozenPigment::item),
                class_4844.field_25122.fieldOf("owner").forGetter(FrozenPigment::owner)
            ).apply(inst, FrozenPigment::new)).orElseGet(FrozenPigment.DEFAULT);
    //TODO port: maybe default here too somehow?..
    public static class_9139<class_9129, FrozenPigment> STREAM_CODEC = class_9139.method_56435(
            class_1799.field_48349, FrozenPigment::item,
            class_4844.field_48453, FrozenPigment::owner,
            FrozenPigment::new
    );

    public class_2487 serializeToNBT(class_7225.class_7874 provider) {
        var out = new class_2487();
        out.method_10566(TAG_STACK, this.item.method_57358(provider));
        out.method_25927(TAG_OWNER, this.owner);
        return out;
    }

    public static FrozenPigment fromNBT(class_7225.class_7874 provider, class_2487 tag) {
        if (tag.method_33133() || provider == null) {
            return FrozenPigment.DEFAULT.get();
        }
        try {
            class_2487 stackTag = tag.method_10562(TAG_STACK);
            var stack = class_1799.method_57359(provider, stackTag);
            var uuid = tag.method_25926(TAG_OWNER);
            return new FrozenPigment(stack, uuid);
        } catch (NullPointerException exn) {
            return FrozenPigment.DEFAULT.get();
        }
    }


    public ColorProvider getColorProvider() {
        return IXplatAbstractions.INSTANCE.getColorProvider(this);
    }
}
