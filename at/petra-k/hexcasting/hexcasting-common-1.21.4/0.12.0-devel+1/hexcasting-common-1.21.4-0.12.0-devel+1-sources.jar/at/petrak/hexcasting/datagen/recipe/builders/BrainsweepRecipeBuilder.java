package at.petrak.hexcasting.datagen.recipe.builders;

import at.petrak.hexcasting.common.recipe.BrainsweepRecipe;
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.BrainsweepeeIngredient;
import at.petrak.hexcasting.common.recipe.ingredient.state.StateIngredient;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_161;
import net.minecraft.class_170;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1860;
import net.minecraft.class_2119;
import net.minecraft.class_2680;
import net.minecraft.class_5321;
import net.minecraft.class_5797;
import net.minecraft.class_7924;
import net.minecraft.class_8782;
import net.minecraft.class_8790;

public class BrainsweepRecipeBuilder implements class_5797 {
    private final StateIngredient blockIn;
    private final BrainsweepeeIngredient entityIn;
    private final long mediaCost;
    private final class_2680 result;

    private final Map<String, class_175<?>> criteria = new LinkedHashMap<>();

    public BrainsweepRecipeBuilder(StateIngredient blockIn, BrainsweepeeIngredient entityIn, class_2680 result,
                                   long mediaCost) {
        this.blockIn = blockIn;
        this.entityIn = entityIn;
        this.result = result;
        this.mediaCost = mediaCost;
    }

    @Override
    public class_5797 method_33530(String pCriterionName, class_175<?> pCriterionTrigger) {
        criteria.put(pCriterionName, pCriterionTrigger);
        return this;
    }

    @Override
    public class_5797 method_33529(@Nullable String pGroupName) {
        return this;
    }

    @Override
    public class_1792 method_36441() {
        return this.result.method_26204().method_8389();
    }

    @Override
    public void method_17972(class_8790 recipeOutput, class_5321<class_1860<?>> id) {
        class_161.class_162 advancement = recipeOutput.method_53818()
                .method_705("has_the_recipe", class_2119.method_27847(id))
                .method_703(class_170.class_171.method_753(id))
                .method_704(class_8782.class_8797.field_1257);
        this.criteria.forEach(advancement::method_705);

		var recipe = new BrainsweepRecipe(blockIn, entityIn, mediaCost, result);
		recipeOutput.method_53819(class_5321.method_29179(class_7924.field_52178, id.method_29177().method_45138("brainsweep/")), recipe, advancement.method_695(id.method_29177().method_45138("recipes/brainsweep/")));
	}
}
