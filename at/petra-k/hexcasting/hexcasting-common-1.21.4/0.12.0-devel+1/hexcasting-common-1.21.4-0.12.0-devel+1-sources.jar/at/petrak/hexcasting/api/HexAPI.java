package at.petrak.hexcasting.api;

import at.petrak.hexcasting.api.addldata.ADMediaHolder;
import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.castables.SpecialHandler;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.player.Sentinel;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.google.common.base.Suppliers;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.EnumMap;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_10191;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public interface HexAPI {
    String MOD_ID = "hexcasting";
    Logger LOGGER = LogManager.getLogger(MOD_ID);

    Supplier<HexAPI> INSTANCE = Suppliers.memoize(() -> {
        try {
            return (HexAPI) Class.forName("at.petrak.hexcasting.common.impl.HexAPIImpl")
                .getDeclaredConstructor().newInstance();
        } catch (ReflectiveOperationException e) {
            LogManager.getLogger().warn("Unable to find HexAPIImpl, using a dummy");
            return new HexAPI() {
            };
        }
    });

    /**
     * Return the localization key for the given action.
     * <p>
     * Note we're allowed to have action <em>resource keys</em> on the client, just no actual actions.
     * <p>
     * Special handlers should be calling {@link SpecialHandler#getName()}
     */
    default String getActionI18nKey(class_5321<ActionRegistryEntry> action) {
        return "hexcasting.action.%s".formatted(action.method_29177().toString());
    }

    default String getSpecialHandlerI18nKey(class_5321<SpecialHandler.Factory<?>> action) {
        return "hexcasting.special.%s".formatted(action.method_29177().toString());
    }

    default class_2561 getActionI18n(class_5321<ActionRegistryEntry> key, boolean isGreat) {
        return class_2561.method_43471(getActionI18nKey(key))
            .method_27692(isGreat ? class_124.field_1065 : class_124.field_1076);
    }

    default class_2561 getSpecialHandlerI18n(class_5321<SpecialHandler.Factory<?>> key) {
        return class_2561.method_43471(getSpecialHandlerI18nKey(key))
            .method_27692(class_124.field_1076);
    }

    /**
     * If the entity has a special getter return that, otherwise return its normal look angle
     */
    default class_243 getEntityLookDirSpecial(class_1297 entity) {
        return entity.method_5720();
    }

    /**
     * Register an entity with the given ID to have its velocity as perceived by OpEntityVelocity be different
     * than it's "normal" velocity
     */
    // Should be OK to use the type directly as the key as they're singleton identity objects
    default <T extends class_1297> void registerSpecialVelocityGetter(class_1299<T> key, EntityVelocityGetter<T> getter) {
    }

    /**
     * If the entity has had a special getter registered with {@link HexAPI#registerSpecialVelocityGetter} then
     * return that, otherwise return its normal delta movement
     */
    default class_243 getEntityVelocitySpecial(class_1297 entity) {
        return entity.method_18798();
    }

    @FunctionalInterface
    interface EntityVelocityGetter<T extends class_1297> {
        class_243 getVelocity(T entity);
    }

    /**
     * Register an entity type to have a custom behavior when getting brainswept.
     * <p>
     * This knocks out the normal behavior; if you want that behavior you should call
     */
    default <T extends class_1308> void registerCustomBrainsweepingBehavior(class_1299<T> key, Consumer<T> hook) {
    }

    /**
     * The default behavior when an entity gets brainswept.
     * <p>
     * Something registered with {@link HexAPI#registerCustomBrainsweepingBehavior} doesn't call this automatically;
     * you can use this to add things on top of the default behavior
     */
    default Consumer<class_1308> defaultBrainsweepingBehavior() {
        return mob -> {
        };
    }

    /**
     * If something special's been returned with {@link HexAPI#registerCustomBrainsweepingBehavior}, return that,
     * otherwise return the default behavior
     */
    default <T extends class_1308> Consumer<T> getBrainsweepBehavior(class_1299<T> mobType) {
        return mob -> {
        };
    }

    /**
     * Brainsweep (flay the mind of) the given mob.
     * <p>
     * This ignores the unbrainsweepable tag.
     */
    default void brainsweep(class_1308 mob) {
        var type = (class_1299<? extends class_1308>) mob.method_5864();
        var behavior = this.getBrainsweepBehavior(type);
        var erasedBehavior = (Consumer<class_1308>) behavior;
        erasedBehavior.accept(mob);

        IXplatAbstractions.INSTANCE.setBrainsweepAddlData(mob);
    }

    default boolean isBrainswept(class_1308 mob) {
        return IXplatAbstractions.INSTANCE.isBrainswept(mob);
    }

    //
    @Nullable
    default Sentinel getSentinel(class_3222 player) {
        return null;
    }

    @Nullable
    default ADMediaHolder findMediaHolder(class_1799 stack) {
        return null;
    }

    default FrozenPigment getColorizer(class_1657 player) {
        return FrozenPigment.DEFAULT.get();
    }

//    ArmorMaterial DUMMY_ARMOR_MATERIAL = new ArmorMaterial(
//            Collections.emptyMap(),
//            0,
//            SoundEvents.ARMOR_EQUIP_LEATHER,
//            () -> Ingredient.EMPTY,
//            Collections.emptyList(),
//            0,
//            0
//    );

    class_1741 DUMMY_ARMOR_MATERIAL = new class_1741(
            0,
            Collections.emptyMap(),
            0,
            class_3417.field_14581,
            0,
            0,
            class_6862.method_40092(class_7924.field_41197, class_2960.method_60656("empty")),
            class_10191.field_54134
    );

    default class_1741 robesMaterial() {
        return DUMMY_ARMOR_MATERIAL;
    }

    /**
     * Location in the userdata of the ravenmind
     */
    String RAVENMIND_USERDATA = modLoc("ravenmind").toString();

    String MARKED_MOVED_USERDATA = modLoc("impulsed").toString();

    static HexAPI instance() {
        return INSTANCE.get();
    }

    static class_2960 modLoc(String s) {
        return class_2960.method_60655(MOD_ID, s);
    }
}
