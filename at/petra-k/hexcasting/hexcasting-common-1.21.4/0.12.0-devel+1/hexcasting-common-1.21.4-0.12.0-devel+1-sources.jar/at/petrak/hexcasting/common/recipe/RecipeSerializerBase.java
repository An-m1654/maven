package at.petrak.hexcasting.common.recipe;

import at.petrak.hexcasting.annotations.SoftImplement;
import javax.annotation.Nullable;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2960;

// https://github.com/VazkiiMods/Botania/blob/1.18.x/Xplat/src/main/java/vazkii/botania/common/crafting/RecipeSerializerBase.java
// TL;DR Forge bad, so we have to cursed self-mixin
public abstract class RecipeSerializerBase<T extends class_1860<?>> implements class_1865<T> {
    @Nullable
    private class_2960 registryName;

    @SoftImplement("IForgeRegistryEntry")
    public RecipeSerializerBase<T> setRegistryName(class_2960 name) {
        registryName = name;
        return this;
    }

    @SoftImplement("IForgeRegistryEntry")
    @Nullable
    public class_2960 getRegistryName() {
        return registryName;
    }

    @SoftImplement("IForgeRegistryEntry")
    @SuppressWarnings("unchecked")
    public Class<class_1865<?>> getRegistryType() {
        Class<?> clazz = class_1865.class;
        return (Class<class_1865<?>>) clazz;
    }

}
