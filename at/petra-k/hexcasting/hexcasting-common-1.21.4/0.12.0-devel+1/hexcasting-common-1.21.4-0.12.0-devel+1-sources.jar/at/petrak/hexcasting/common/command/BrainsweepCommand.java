package at.petrak.hexcasting.common.command;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_1308;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;

public class BrainsweepCommand {
    public static void add(LiteralArgumentBuilder<class_2168> cmd) {
        cmd.then(class_2170.method_9247("brainsweep")
            .requires(dp -> dp.method_9259(class_2170.field_31840))
            .then(class_2170.method_9244("target", class_2186.method_9309()).executes(ctx -> {
                var target = class_2186.method_9313(ctx, "target");
                if (target instanceof class_1308 mob) {
                    if (IXplatAbstractions.INSTANCE.isBrainswept(mob)) {
                        ctx.getSource().method_9213(
                            class_2561.method_43469("command.hexcasting.brainsweep.fail.already",
                                mob.method_5476()));
                        return 0;
                    }
                    HexAPI.instance().brainsweep(mob);
                    ctx.getSource().method_9226(
                        () -> class_2561.method_43469("command.hexcasting.brainsweep", mob.method_5476()), true);
                    return 1;
                } else {
                    ctx.getSource().method_9213(
                        class_2561.method_43469("command.hexcasting.brainsweep.fail.badtype",
                            target.method_5476()));
                    return 0;
                }
            })));
    }
}
