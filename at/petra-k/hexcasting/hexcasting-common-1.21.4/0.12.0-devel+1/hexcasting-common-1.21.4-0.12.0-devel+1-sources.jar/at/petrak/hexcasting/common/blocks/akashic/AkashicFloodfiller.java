package at.petrak.hexcasting.common.blocks.akashic;

import at.petrak.hexcasting.api.misc.TriPredicate;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayDeque;
import java.util.HashSet;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public interface AkashicFloodfiller {
    default boolean canBeFloodedThrough(class_2338 pos, class_2680 state, class_1937 world) {
        return true;
    }

    @Nullable
    static class_2338 floodFillFor(class_2338 start, class_1937 world, TriPredicate<class_2338, class_2680, class_1937> isTarget) {
        return floodFillFor(start, world, 0f, isTarget, 128);
    }

    @Nullable
    static class_2338 floodFillFor(class_2338 start, class_1937 world, float skipChance,
        TriPredicate<class_2338, class_2680, class_1937> isTarget, int maxRange) {
        var seenBlocks = new HashSet<class_2338>();
        var todo = new ArrayDeque<class_2338>();
        todo.add(start);
        var skippedBlocks = new HashSet<class_2338>();

        while (!todo.isEmpty()) {
            var here = todo.remove();

            for (var dir : class_2350.values()) {
                var neighbor = here.method_10093(dir);

                if (neighbor.method_10262(start) > maxRange * maxRange)
                    continue;

                if (seenBlocks.add(neighbor)) {
                    var bs = world.method_8320(neighbor);
                    if (isTarget.test(neighbor, bs, world)) {
                        if (world.field_9229.method_43057() > skipChance) {
                            return neighbor;
                        } else {
                            skippedBlocks.add(neighbor);
                        }
                    }
                    if (canItBeFloodedThrough(neighbor, bs, world)) {
                        todo.add(neighbor);
                    }
                }
            }
        }

        if (!skippedBlocks.isEmpty()) {
            // We found something valid, we just skipped past it
            return skippedBlocks.iterator().next();
        }

        return null;
    }

    static boolean canItBeFloodedThrough(class_2338 pos, class_2680 state, class_1937 world) {
        if (!(state.method_26204() instanceof AkashicFloodfiller flooder)) {
            return false;
        }

        return flooder.canBeFloodedThrough(pos, state, world);
    }

    class_1269 use(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_1657 pPlayer, class_1268 pHand,
                          class_3965 pHit);
}
