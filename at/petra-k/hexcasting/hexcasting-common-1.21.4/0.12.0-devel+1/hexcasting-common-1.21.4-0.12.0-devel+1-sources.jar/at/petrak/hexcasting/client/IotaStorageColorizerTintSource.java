package at.petrak.hexcasting.client;

import at.petrak.hexcasting.api.item.IotaHolderItem;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_10401;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;

public record IotaStorageColorizerTintSource(class_1799 item) implements class_10401 {
    public static final MapCodec<IotaStorageColorizerTintSource> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            class_1799.field_24671.fieldOf("item").forGetter(IotaStorageColorizerTintSource::item)
    ).apply(instance, IotaStorageColorizerTintSource::new));

    @Override
    public int method_65389(class_1799 itemStack, @Nullable class_638 clientLevel, @Nullable class_1309 livingEntity) {
        if (item.method_7909() instanceof IotaHolderItem typedItem) {
            return typedItem.getColor(itemStack);
        }
        LogUtils.getLogger().warn("ItemStack gotten is NOT instanceof IotaHolderItem. " +
                "This message is related to the IotaStorageColorizerTintSource thingy. " +
                "If this shows up, tell me and I'll be like: BRUHHHHHH and try to fix it.");
        return 0xff_ffffff;
    }

    @Override
    public MapCodec<? extends class_10401> method_65387() {
        return MAP_CODEC;
    }
}
