package at.petrak.hexcasting.common.msgs;

import io.netty.buffer.Unpooled;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

// https://github.com/VazkiiMods/Botania/blob/1.18.x/Common/src/main/java/vazkii/botania/network/IPacket.java
// yoink
public interface IMessage {
    default class_2540 toBuf() {
        var ret = new class_2540(Unpooled.buffer());
        serialize(ret);
        return ret;
    }

    void serialize(class_2540 buf);

    /**
     * Forge auto-assigns incrementing integers, Fabric requires us to declare an ID
     * These are sent using vanilla's custom plugin channel system and thus are written to every single packet.
     * So this ID tends to be more terse.
     */
    class_2960 getFabricId();
}
