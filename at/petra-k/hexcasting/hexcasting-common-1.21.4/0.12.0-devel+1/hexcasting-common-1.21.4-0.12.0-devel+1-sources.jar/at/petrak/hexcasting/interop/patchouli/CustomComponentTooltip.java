package at.petrak.hexcasting.interop.patchouli;

import com.google.gson.annotations.SerializedName;
import vazkii.patchouli.api.IComponentRenderContext;
import vazkii.patchouli.api.ICustomComponent;
import vazkii.patchouli.api.IVariable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.UnaryOperator;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_7225;

public class CustomComponentTooltip implements ICustomComponent {
    int width, height;

    @SerializedName("tooltip")
    IVariable tooltipReference;

    transient IVariable tooltipVar;
    transient class_7225.class_7874 registries;
    transient List<class_2561> tooltip;

    transient int x, y;

    @Override
    public void build(int componentX, int componentY, int pageNum) {
        x = componentX;
        y = componentY;
        tooltip = new ArrayList<>();
        for (IVariable s : tooltipVar.asListOrSingleton(registries)) {
            tooltip.add(s.as(class_2561.class));
        }
    }

    @Override
    public void render(class_332 graphics, IComponentRenderContext context, float pticks, int mouseX, int mouseY) {
        if (context.isAreaHovered(mouseX, mouseY, x, y, width, height)) {
            context.setHoverTooltipComponents(tooltip);
        }
    }

    @Override
    public void onVariablesAvailable(UnaryOperator<IVariable> lookup, class_7225.class_7874 registries) {
        tooltipVar = lookup.apply(tooltipReference);
        this.registries = registries;
    }
}
