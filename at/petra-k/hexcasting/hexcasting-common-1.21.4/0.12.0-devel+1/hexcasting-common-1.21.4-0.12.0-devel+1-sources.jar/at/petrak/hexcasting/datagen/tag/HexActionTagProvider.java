package at.petrak.hexcasting.datagen.tag;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.Platform;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2474;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7784;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexActionTagProvider extends class_2474<ActionRegistryEntry> {
    public HexActionTagProvider(class_7784 output, CompletableFuture<class_7225.class_7874> provider) {
        super(output, IXplatAbstractions.INSTANCE.getActionRegistry().method_46765(), provider);
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        // In-game almost all great spells are always per-world
        for (var normalGreat : new String[]{
            "lightning", "flight", "create_lava", "teleport/great", "sentinel/create/great",
            "dispel_rain", "summon_rain", "brainsweep", "craft/battery",
            "potion/regeneration", "potion/night_vision", "potion/absorption", "potion/haste", "potion/strength"
        }) {
            var loc = modLoc(normalGreat);
            var key = class_5321.method_29179(IXplatAbstractions.INSTANCE.getActionRegistry().method_46765(), loc);
            method_10512(ersatzActionTag(HexTags.Actions.REQUIRES_ENLIGHTENMENT)).method_46835(key);
            method_10512(ersatzActionTag(HexTags.Actions.CAN_START_ENLIGHTEN)).method_46835(key);
            method_10512(ersatzActionTag(HexTags.Actions.PER_WORLD_PATTERN)).method_46835(key);
        }
        // deciding that akashic write can be just a normal spell (as a treat)
    }

    private static class_6862<ActionRegistryEntry> ersatzActionTag(class_6862<ActionRegistryEntry> real) {
        if (IXplatAbstractions.INSTANCE.platform() == Platform.FABRIC) {
            // Vanilla (and Fabric) has a bug here where it *writes* hexcasting action tags to `.../tags/action`
            // instead of `.../tags/hexcasting/action`.
            // So we pull this bullshit
            var fakeKey = class_5321.<ActionRegistryEntry>method_29180(
                class_2960.method_60655("foobar", "hexcasting/tags/action"));
            return class_6862.method_40092(fakeKey, real.comp_327());
        } else {
            return real;
        }
    }
}
