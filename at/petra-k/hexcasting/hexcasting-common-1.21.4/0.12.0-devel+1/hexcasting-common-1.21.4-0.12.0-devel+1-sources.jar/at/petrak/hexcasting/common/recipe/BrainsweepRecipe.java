package at.petrak.hexcasting.common.recipe;

import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.BrainsweepeeIngredient;
import at.petrak.hexcasting.common.lib.HexBrainsweepeeIngredients;
import at.petrak.hexcasting.common.recipe.ingredient.state.StateIngredient;
import at.petrak.hexcasting.common.lib.HexStateIngredients;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_10355;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_314;
import net.minecraft.class_3218;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9695;
import net.minecraft.class_9887;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;

import java.util.List;

// God I am a horrible person
public record BrainsweepRecipe(
	StateIngredient blockIn,
	BrainsweepeeIngredient entityIn,
	long mediaCost,
	class_2680 result
) implements class_1860<class_9695> {
	public boolean matches(class_2680 blockIn, class_1297 victim, class_3218 level) {
		return this.blockIn.test(blockIn) && this.entityIn.test(victim, level);
	}

	@Override
	public class_3956<? extends class_1860<class_9695>> method_17716() {
		return HexRecipeStuffRegistry.BRAINSWEEP_TYPE;
	}

    @Override
    public class_9887 method_61671() {
        return class_9887.method_61682(class_1856.method_8101(class_1802.field_20391));
    }

    @Override
    public class_10355 method_64668() {
        return class_314.field_1810;
    }

    @Override
	public class_1865<? extends class_1860<class_9695>> method_8119() {
		return HexRecipeStuffRegistry.BRAINSWEEP;
	}

	// in order to get this to be a "Recipe" we need to do a lot of bending-over-backwards
	// to get the implementation to be satisfied even though we never use it
	@Override
	public boolean method_8115(class_9695 input, class_1937 level) {
		return false;
	}

	@Override
	public class_1799 method_8116(class_9695 input, class_7225.class_7874 registries) {
		return class_1799.field_8037;
	}

/*
    @Override
    public ItemStack getResultItem(HolderLookup.Provider registries) {
		return ItemStack.EMPTY.copy();
	}

 */

	// Because kotlin doesn't like doing raw, unchecked types
	// Can't blame it, but that's what we need to do
	@SuppressWarnings({"rawtypes", "unchecked"})
	public static class_2680 copyProperties(class_2680 original, class_2680 copyTo) {
		for (class_2769 prop : original.method_28501()) {
			if (copyTo.method_28498(prop)) {
				copyTo = copyTo.method_11657(prop, original.method_11654(prop));
			}
		}

		return copyTo;
	}

	public static class Serializer extends RecipeSerializerBase<BrainsweepRecipe> {
		public static MapCodec<BrainsweepRecipe> CODEC = RecordCodecBuilder.mapCodec(inst ->
			inst.group(
				HexStateIngredients.TYPED_CODEC.fieldOf("blockIn").forGetter(BrainsweepRecipe::blockIn),
				HexBrainsweepeeIngredients.TYPED_CODEC.fieldOf("entityIn").forGetter(BrainsweepRecipe::entityIn),
				Codec.LONG.fieldOf("cost").forGetter(BrainsweepRecipe::mediaCost),
				class_2680.field_24734.fieldOf("result").forGetter(BrainsweepRecipe::result)
			).apply(inst, BrainsweepRecipe::new)
		);
		public static class_9139<class_9129, BrainsweepRecipe> STREAM_CODEC = class_9139.method_56905(
				HexStateIngredients.TYPED_STREAM_CODEC, BrainsweepRecipe::blockIn,
				HexBrainsweepeeIngredients.TYPED_STREAM_CODEC, BrainsweepRecipe::entityIn,
				class_9135.field_48551, BrainsweepRecipe::mediaCost,
				class_9135.field_48550, (recipe) -> class_2248.method_9507(recipe.result),
				(state, ent, cost, stateId) ->
						new BrainsweepRecipe(state, ent, cost, class_2248.method_9531(stateId))
		);

		@Override
		public @NotNull MapCodec<BrainsweepRecipe> method_53736() {
			return CODEC;
		}

		@Override
		public @NotNull class_9139<class_9129, BrainsweepRecipe> method_56104() {
			return STREAM_CODEC;
		}
    }
}
