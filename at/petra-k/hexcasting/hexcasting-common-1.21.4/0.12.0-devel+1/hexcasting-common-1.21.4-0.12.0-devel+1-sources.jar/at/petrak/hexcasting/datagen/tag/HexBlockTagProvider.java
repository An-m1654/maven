package at.petrak.hexcasting.datagen.tag;

import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.common.lib.HexBlocks;
import at.petrak.hexcasting.xplat.IXplatTags;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2474;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class HexBlockTagProvider extends class_2474<class_2248> {
    public final IXplatTags xtags;

    public HexBlockTagProvider(class_7784 output, CompletableFuture<class_7225.class_7874> lookupProvider, IXplatTags xtags) {
        super(output, class_7924.field_41254, lookupProvider);
        this.xtags = xtags;
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        add(method_10512(HexTags.Blocks.IMPETI),
            HexBlocks.IMPETUS_LOOK, HexBlocks.IMPETUS_RIGHTCLICK, HexBlocks.IMPETUS_REDSTONE);
        add(method_10512(HexTags.Blocks.DIRECTRICES),
            HexBlocks.DIRECTRIX_REDSTONE, HexBlocks.DIRECTRIX_BOOLEAN);
        method_10512(HexTags.Blocks.MINDFLAYED_CIRCLE_COMPONENTS)
            .method_26792(HexTags.Blocks.IMPETI)
            .method_26792(HexTags.Blocks.DIRECTRICES);

        add(method_10512(class_3481.field_33715),
            HexBlocks.SLATE_BLOCK, HexBlocks.SLATE_TILES, HexBlocks.SLATE_BRICKS,
            HexBlocks.SLATE_BRICKS_SMALL, HexBlocks.SLATE_PILLAR, HexBlocks.SLATE,
            HexBlocks.EMPTY_DIRECTRIX, HexBlocks.DIRECTRIX_REDSTONE, HexBlocks.DIRECTRIX_BOOLEAN,
            HexBlocks.IMPETUS_EMPTY,
            HexBlocks.IMPETUS_RIGHTCLICK, HexBlocks.IMPETUS_LOOK, HexBlocks.IMPETUS_REDSTONE,
            HexBlocks.AMETHYST_TILES, HexBlocks.AMETHYST_BRICKS, HexBlocks.AMETHYST_BRICKS_SMALL,
            HexBlocks.AMETHYST_PILLAR, HexBlocks.SLATE_AMETHYST_TILES, HexBlocks.SLATE_AMETHYST_BRICKS,
            HexBlocks.SLATE_AMETHYST_BRICKS_SMALL, HexBlocks.SLATE_AMETHYST_PILLAR, HexBlocks.SCONCE,
            HexBlocks.QUENCHED_ALLAY, HexBlocks.QUENCHED_ALLAY_TILES, HexBlocks.QUENCHED_ALLAY_BRICKS,
            HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL);

        add(method_10512(class_3481.field_33716),
            HexBlocks.AMETHYST_DUST_BLOCK);

        add(method_10512(class_3481.field_33713),
            HexBlocks.AKASHIC_RECORD, HexBlocks.AKASHIC_BOOKSHELF, HexBlocks.AKASHIC_LIGATURE,
            HexBlocks.EDIFIED_LOG, HexBlocks.EDIFIED_LOG_AMETHYST,
            HexBlocks.EDIFIED_LOG_AVENTURINE, HexBlocks.EDIFIED_LOG_CITRINE,
            HexBlocks.EDIFIED_LOG_PURPLE, HexBlocks.STRIPPED_EDIFIED_LOG,
            HexBlocks.EDIFIED_WOOD, HexBlocks.STRIPPED_EDIFIED_WOOD,
            HexBlocks.EDIFIED_PLANKS, HexBlocks.EDIFIED_PANEL, HexBlocks.EDIFIED_TILE,
            HexBlocks.EDIFIED_DOOR, HexBlocks.EDIFIED_TRAPDOOR, HexBlocks.EDIFIED_SLAB,
            HexBlocks.EDIFIED_BUTTON, HexBlocks.EDIFIED_STAIRS, HexBlocks.EDIFIED_FENCE, HexBlocks.EDIFIED_FENCE_GATE);

        add(method_10512(class_3481.field_33714),
            HexBlocks.AMETHYST_EDIFIED_LEAVES, HexBlocks.AVENTURINE_EDIFIED_LEAVES,
            HexBlocks.CITRINE_EDIFIED_LEAVES);

        add(method_10512(class_3481.field_26986),
            HexBlocks.CONJURED_LIGHT, HexBlocks.CONJURED_BLOCK, HexBlocks.AMETHYST_TILES,
            HexBlocks.SCONCE);

        add(method_10512(HexTags.Blocks.EDIFIED_LOGS),
            HexBlocks.EDIFIED_LOG, HexBlocks.EDIFIED_LOG_AMETHYST,
            HexBlocks.EDIFIED_LOG_AVENTURINE, HexBlocks.EDIFIED_LOG_CITRINE,
            HexBlocks.EDIFIED_LOG_PURPLE, HexBlocks.STRIPPED_EDIFIED_LOG,
            HexBlocks.EDIFIED_WOOD, HexBlocks.STRIPPED_EDIFIED_WOOD);
        add(method_10512(class_3481.field_15475),
            HexBlocks.EDIFIED_LOG, HexBlocks.EDIFIED_LOG_AMETHYST,
            HexBlocks.EDIFIED_LOG_AVENTURINE, HexBlocks.EDIFIED_LOG_CITRINE,
            HexBlocks.EDIFIED_LOG_PURPLE, HexBlocks.STRIPPED_EDIFIED_LOG,
            HexBlocks.EDIFIED_WOOD, HexBlocks.STRIPPED_EDIFIED_WOOD);
        add(method_10512(class_3481.field_23210),
            HexBlocks.EDIFIED_LOG, HexBlocks.EDIFIED_LOG_AMETHYST,
            HexBlocks.EDIFIED_LOG_AVENTURINE, HexBlocks.EDIFIED_LOG_CITRINE,
            HexBlocks.EDIFIED_LOG_PURPLE, HexBlocks.STRIPPED_EDIFIED_LOG,
            HexBlocks.EDIFIED_WOOD, HexBlocks.STRIPPED_EDIFIED_WOOD);
        add(method_10512(class_3481.field_15503),
            HexBlocks.AMETHYST_EDIFIED_LEAVES, HexBlocks.AVENTURINE_EDIFIED_LEAVES,
            HexBlocks.CITRINE_EDIFIED_LEAVES);

        add(method_10512(class_3481.field_15471),
            HexBlocks.EDIFIED_PLANKS, HexBlocks.EDIFIED_PANEL, HexBlocks.EDIFIED_TILE);
        add(method_10512(HexTags.Blocks.EDIFIED_PLANKS),
            HexBlocks.EDIFIED_PLANKS, HexBlocks.EDIFIED_PANEL, HexBlocks.EDIFIED_TILE);
        add(method_10512(class_3481.field_15469),
            HexBlocks.EDIFIED_SLAB);
        add(method_10512(class_3481.field_15468),
            HexBlocks.EDIFIED_SLAB);
        add(method_10512(class_3481.field_15459),
            HexBlocks.EDIFIED_STAIRS);
        add(method_10512(class_3481.field_16584),
            HexBlocks.EDIFIED_FENCE);
        add(method_10512(class_3481.field_17619),
            HexBlocks.EDIFIED_FENCE);
        add(method_10512(class_3481.field_25147),
            HexBlocks.EDIFIED_FENCE_GATE);
        add(method_10512(class_3481.field_25148),
            HexBlocks.EDIFIED_FENCE_GATE);


        add(method_10512(class_3481.field_17619),
            HexBlocks.EDIFIED_FENCE);
        add(method_10512(class_3481.field_15502),
            HexBlocks.EDIFIED_STAIRS);
        add(method_10512(class_3481.field_15495),
            HexBlocks.EDIFIED_DOOR);
        add(method_10512(class_3481.field_15494),
            HexBlocks.EDIFIED_DOOR);
        add(method_10512(class_3481.field_15487),
            HexBlocks.EDIFIED_TRAPDOOR);
        add(method_10512(class_3481.field_15491),
            HexBlocks.EDIFIED_TRAPDOOR);
        add(method_10512(class_3481.field_24076),
            HexBlocks.EDIFIED_PRESSURE_PLATE);
        add(method_10512(class_3481.field_15477),
            HexBlocks.EDIFIED_PRESSURE_PLATE);
        add(method_10512(class_3481.field_15493),
            HexBlocks.EDIFIED_BUTTON);
        add(method_10512(class_3481.field_15499),
            HexBlocks.EDIFIED_BUTTON);

        add(method_10512(HexTags.Blocks.WATER_PLANTS),
            class_2246.field_9993, class_2246.field_10463, class_2246.field_10376, class_2246.field_10238);
        add(method_10512(HexTags.Blocks.CHEAP_TO_BREAK_BLOCK),
            HexBlocks.CONJURED_BLOCK, HexBlocks.CONJURED_LIGHT);

        add(method_10512(HexTags.Blocks.SLATE_BLOCKS),
            HexBlocks.SLATE_BLOCK, HexBlocks.SLATE_BRICKS, HexBlocks.SLATE_BRICKS_SMALL, HexBlocks.SLATE_TILES, HexBlocks.SLATE_PILLAR);
        add(method_10512(HexTags.Blocks.AMETHYST_BLOCKS),
            class_2246.field_27159, HexBlocks.AMETHYST_BRICKS, HexBlocks.AMETHYST_BRICKS_SMALL, HexBlocks.AMETHYST_TILES, HexBlocks.AMETHYST_PILLAR);
        add(method_10512(HexTags.Blocks.QUENCHED_ALLAY_BLOCKS),
            HexBlocks.QUENCHED_ALLAY, HexBlocks.QUENCHED_ALLAY_BRICKS, HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL, HexBlocks.QUENCHED_ALLAY_TILES);

        // this is a hack but fixes #532
        var createBrittle = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("create", "brittle"));
        method_10512(createBrittle).method_35923(class_7923.field_41175.method_10221(HexBlocks.SLATE));
    }

    void add(class_2474.class_5124<class_2248> appender, class_2248... blocks) {
        for (class_2248 block : blocks) {
            appender.method_46835(class_7923.field_41175.method_29113(block).orElseThrow());
        }
    }
}
