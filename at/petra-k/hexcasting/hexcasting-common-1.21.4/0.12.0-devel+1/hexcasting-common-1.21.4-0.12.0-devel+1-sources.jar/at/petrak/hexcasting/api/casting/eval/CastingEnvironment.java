package at.petrak.hexcasting.api.casting.eval;

import at.petrak.hexcasting.api.casting.ParticleSpray;
import at.petrak.hexcasting.api.casting.PatternShapeMatch;
import at.petrak.hexcasting.api.casting.eval.CastingEnvironmentComponent.ExtractMedia;
import at.petrak.hexcasting.api.casting.eval.CastingEnvironmentComponent.HasEditPermissionsAt;
import at.petrak.hexcasting.api.casting.eval.CastingEnvironmentComponent.IsVecInRange;
import at.petrak.hexcasting.api.casting.eval.CastingEnvironmentComponent.PostCast;
import at.petrak.hexcasting.api.casting.eval.CastingEnvironmentComponent.PostExecution;
import at.petrak.hexcasting.api.casting.eval.env.PlayerBasedCastEnv;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import at.petrak.hexcasting.api.casting.mishaps.Mishap;
import at.petrak.hexcasting.api.casting.mishaps.MishapBadLocation;
import at.petrak.hexcasting.api.casting.mishaps.MishapDisallowedSpell;
import at.petrak.hexcasting.api.casting.mishaps.MishapEntityTooFarAway;
import at.petrak.hexcasting.api.mod.HexConfig;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.lib.HexAttributes;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

import static at.petrak.hexcasting.api.HexAPI.modLoc;
import static at.petrak.hexcasting.api.casting.eval.CastingEnvironmentComponent.*;

/**
 * Environment within which hexes are cast.
 * <p>
 * Stuff like "the player with a staff," "the player with a trinket," "spell circles,"
 */
public abstract class CastingEnvironment {
    /**
     * Stores all listeners that should be notified whenever a CastingEnvironment is initialised.
     */
    private static final List<BiConsumer<CastingEnvironment, class_2487>> createEventListeners = new ArrayList<>();

    /**
     * Add a listener that will be called whenever a new CastingEnvironment is created.
     */
    public static void addCreateEventListener(BiConsumer<CastingEnvironment, class_2487> listener) {
        createEventListeners.add(listener);
    }

    /**
     * Add a listener that will be called whenever a new CastingEnvironment is created (legacy).
     *
     * @deprecated replaced by {@link #addCreateEventListener(BiConsumer)}
     */
    @Deprecated(since = "0.11.0-pre-660")
    public static void addCreateEventListener(Consumer<CastingEnvironment> listener) {
        createEventListeners.add((env, data) -> {
            listener.accept(env);
        });
    }

    private boolean createEventTriggered = false;

    public final void triggerCreateEvent(class_2487 userData) {
        if (!createEventTriggered) {
            for (var listener : createEventListeners)
                listener.accept(this, userData);
            createEventTriggered = true;
        }
    }


    protected final class_3218 world;

    protected Map<CastingEnvironmentComponent.Key<?>, @NotNull CastingEnvironmentComponent> componentMap =
        new HashMap<>();
    private final List<PostExecution> postExecutions = new ArrayList<>();

    private final List<PostCast> postCasts = new ArrayList<>();
    private final List<ExtractMedia.Pre> preMediaExtract = new ArrayList<>();
    private final List<ExtractMedia.Post> postMediaExtract = new ArrayList<>();

    private final List<IsVecInRange> isVecInRanges = new ArrayList<>();
    private final List<HasEditPermissionsAt> hasEditPermissionsAts = new ArrayList<>();

    protected CastingEnvironment(class_3218 world) {
        this.world = world;
    }

    public final class_3218 getWorld() {
        return this.world;
    }

    public int maxOpCount() {
        return HexConfig.server().maxOpCount();
    }

    /**
     * Get the caster. Might be null!
     * <p>
     * Implementations should NOT rely on this in general, use the methods on this class instead.
     * This is mostly for spells (flight, etc)
     *
     * @deprecated as of build 0.11.1-7-pre-619 you are recommended to use {@link #getCastingEntity}
     */
    @Deprecated(since = "0.11.1-7-pre-619")
    @Nullable
    public class_3222 getCaster() {
        return getCastingEntity() instanceof class_3222 sp ? sp : null;
    }

    ;

    /**
     * Gets the caster. Can be null if {@link #getCaster()} is also null
     *
     * @return the entity casting
     */
    @Nullable
    public abstract class_1309 getCastingEntity();

    /**
     * Get an interface used to do mishaps
     */
    public abstract MishapEnvironment getMishapEnvironment();

    public <T extends CastingEnvironmentComponent> void addExtension(@NotNull T extension) {
        componentMap.put(extension.getKey(), extension);
        if (extension instanceof PostExecution postExecution)
            postExecutions.add(postExecution);
        if (extension instanceof PostCast postCast)
            postCasts.add(postCast);
        if (extension instanceof ExtractMedia extractMedia)
            if (extension instanceof ExtractMedia.Pre pre) {
                preMediaExtract.add(pre);
            } else if (extension instanceof ExtractMedia.Post post) {
                postMediaExtract.add(post);
            }
        if (extension instanceof IsVecInRange isVecInRange)
            isVecInRanges.add(isVecInRange);
        if (extension instanceof HasEditPermissionsAt hasEditPermissionsAt)
            hasEditPermissionsAts.add(hasEditPermissionsAt);
    }

    public void removeExtension(@NotNull CastingEnvironmentComponent.Key<?> key) {
        var extension = componentMap.remove(key);
        if (extension == null)
            return;

        if (extension instanceof PostExecution postExecution)
            postExecutions.remove(postExecution);
        if (extension instanceof PostCast postCast)
            postCasts.remove(postCast);
        if (extension instanceof ExtractMedia extractMedia)
            if (extension instanceof ExtractMedia.Pre pre) {
                preMediaExtract.remove(pre);
            } else if (extension instanceof ExtractMedia.Post post) {
                postMediaExtract.remove(post);
            }
        if (extension instanceof IsVecInRange isVecInRange)
            isVecInRanges.remove(isVecInRange);
        if (extension instanceof HasEditPermissionsAt hasEditPermissionsAt)
            hasEditPermissionsAts.remove(hasEditPermissionsAt);
    }

    @Nullable
    @SuppressWarnings("unchecked")
    public <T extends CastingEnvironmentComponent> T getExtension(@NotNull CastingEnvironmentComponent.Key<T> key) {
        return (T) componentMap.get(key);
    }

    /**
     * If something about this ARE itself is invalid, mishap.
     * <p>
     * This is used for stuff like requiring enlightenment and pattern denylists
     */
    public void precheckAction(PatternShapeMatch match) throws Mishap {
        // TODO: this doesn't let you select special handlers.
        // Might be worth making a "no casting" tag on each thing
        class_2960 loc = actionKey(match);

        if (!HexConfig.server().isActionAllowed(loc)) {
            throw new MishapDisallowedSpell("disallowed", loc);
        }

        costModifier = this.getCostModifier(match);
    }

    /**
     * Casting env subclasses can override this to modify the cost for a given action
     */
    protected double getCostModifier(PatternShapeMatch match) {
        return 1.0;
    }

    @Nullable
    protected class_2960 actionKey(PatternShapeMatch match) {
        class_2960 key;
        if (match instanceof PatternShapeMatch.Normal normal) {
            key = normal.key.method_29177();
        } else if (match instanceof PatternShapeMatch.PerWorld perWorld) {
            key = perWorld.key.method_29177();
        } else if (match instanceof PatternShapeMatch.Special special) {
            key = special.key.method_29177();
        } else {
            key = null;
        }
        return key;
    }

    /**
     * Do whatever you like after a pattern is executed.
     */
    public void postExecution(CastResult result) {
        for (var postExecutionComponent : postExecutions)
            postExecutionComponent.onPostExecution(result);
    }

    /**
     * Do things after the whole cast is finished (i.e. every pattern to be executed has been executed).
     */
    public void postCast(CastingImage image) {
        for (var postCastComponent : postCasts)
            postCastComponent.onPostCast(image);
    }

    public abstract class_243 mishapSprayPos();

    /**
     * Return whether this env can cast great spells.
     */
    public boolean isEnlightened() {
        var adv = this.world.method_8503().method_3851().method_12896(modLoc("enlightenment"));
        if (adv == null)
            return false;

        var caster = this.getCastingEntity();
        if (caster instanceof class_3222 player)
            return player.method_14236().method_12882(adv).method_740();

        return false;
    }

    private double costModifier = 1.0;

    /**
     * Attempt to extract the given amount of media. Returns the amount of media left in the cost.
     * <p>
     * If there was enough media found, it will return less or equal to zero; if there wasn't, it will be
     * positive.
     */
    public long extractMedia(class_3218 level, long cost, boolean simulate) {
        cost = (long) (cost * costModifier);
        for (var extractMediaComponent : preMediaExtract)
            cost = extractMediaComponent.onExtractMedia(cost, simulate);
        cost = extractMediaEnvironment(level, cost, simulate);
        for (var extractMediaComponent : postMediaExtract)
            cost = extractMediaComponent.onExtractMedia(cost, simulate);
        return cost;
    }

    /**
     * Attempt to extract the given amount of media. Returns the amount of media left in the cost.
     * <p>
     * If there was enough media found, it will return less or equal to zero; if there wasn't, it will be
     * positive.
     */
    protected abstract long extractMediaEnvironment(class_3218 level, long cost, boolean simulate);

    /**
     * Get if the vec is close enough, to the player or sentinel ...
     * <p>
     * Doesn't take into account being out of the <em>world</em>.
     */
    public boolean isVecInRange(class_243 vec) {
        boolean isInRange = isVecInRangeEnvironment(vec);
        for (var isVecInRangeComponent : isVecInRanges)
            isInRange = isVecInRangeComponent.onIsVecInRange(vec, isInRange);
        return isInRange;
    }

    /**
     * Get if the vec is close enough, to the player or sentinel ...
     * <p>
     * Doesn't take into account being out of the <em>world</em>.
     */
    protected abstract boolean isVecInRangeEnvironment(class_243 vec);

    /**
     * Return whether the caster can edit blocks at the given permission (i.e. not adventure mode, etc.)
     */
    public boolean hasEditPermissionsAt(class_2338 pos) {
        boolean hasEditPermissionsAt = hasEditPermissionsAtEnvironment(pos);
        for (var hasEditPermissionsAtComponent : hasEditPermissionsAts)
            hasEditPermissionsAt = hasEditPermissionsAtComponent.onHasEditPermissionsAt(pos, hasEditPermissionsAt);
        return hasEditPermissionsAt;
    }

    /**
     * Return whether the caster can edit blocks at the given permission (i.e. not adventure mode, etc.)
     */
    protected abstract boolean hasEditPermissionsAtEnvironment(class_2338 pos);

    public final boolean isVecInWorld(class_243 vec) {
        return this.world.method_24794(class_2338.method_49638(vec))
            && this.world.method_8621().method_39458(vec.field_1352, vec.field_1350, 0.5);
    }

    public final boolean isVecInAmbit(class_243 vec) {
        return this.isVecInRange(vec) && this.isVecInWorld(vec);
    }

    public final boolean isEntityInRange(class_1297 e) {
        return isEntityInRange(e, false);
    }

    public final boolean isEntityInRange(class_1297 e, boolean ignoreTruenameAmbit) {
        boolean truenameCheat = !ignoreTruenameAmbit && (e instanceof class_1657 && HexConfig.server().trueNameHasAmbit());
        return truenameCheat || (this.isVecInWorld(e.method_19538()) && this.isVecInRange(e.method_19538()));
    }

    /**
     * Convenience function to throw if the vec is out of the caster's range or the world
     */
    public final void assertVecInRange(class_243 vec) throws MishapBadLocation {
        this.assertVecInWorld(vec);
        if (!this.isVecInRange(vec)) {
            throw new MishapBadLocation(vec, "too_far");
        }
    }

    public final void assertPosInRange(class_2338 vec) throws MishapBadLocation {
        class_243 centered = class_243.method_24953(vec);
        this.assertVecInRange(centered);
    }

    public final void assertPosInRangeForEditing(class_2338 vec) throws MishapBadLocation {
        class_243 centered = class_243.method_24953(vec);
        this.assertVecInRange(centered);
        if (!this.canEditBlockAt(vec))
            throw new MishapBadLocation(centered, "forbidden");
    }

    public final boolean canEditBlockAt(class_2338 vec) {
        return this.isVecInRange(class_243.method_24953(vec)) && this.hasEditPermissionsAt(vec);
    }

    /**
     * Convenience function to throw if the entity is out of the caster's range or the world
     */
    public final void assertEntityInRange(class_1297 e) throws MishapEntityTooFarAway {
        if (e instanceof class_3222 && HexConfig.server().trueNameHasAmbit()) {
            return;
        }
        if (!this.isVecInWorld(e.method_19538())) {
            throw new MishapEntityTooFarAway(e);
        }
        if (!this.isVecInRange(e.method_19538())) {
            throw new MishapEntityTooFarAway(e);
        }
    }

    /**
     * Convenience function to throw if the vec is out of the world (for GTP)
     */
    public final void assertVecInWorld(class_243 vec) throws MishapBadLocation {
        if (!this.isVecInWorld(vec)) {
            throw new MishapBadLocation(vec, "out_of_world");
        }
    }

    public abstract class_1268 getCastingHand();

    public class_1268 getOtherHand() {
        return HexUtils.otherHand(this.getCastingHand());
    }

    /**
     * Get all the item stacks this env can use.
     */
    public abstract List<class_1799> getUsableStacks(StackDiscoveryMode mode);

    protected List<class_1799> getUsableStacksForPlayer(StackDiscoveryMode mode, @Nullable class_1268 castingHand
        , class_3222 caster) {
        return switch (mode) {
            case QUERY -> {
                var out = new ArrayList<class_1799>();

                if (castingHand == null) {
                    var mainhand = caster.method_5998(class_1268.field_5808);
                    if (!mainhand.method_7960()) {
                        out.add(mainhand);
                    }

                    var offhand = caster.method_5998(class_1268.field_5810);
                    if (!offhand.method_7960()) {
                        out.add(offhand);
                    }
                } else {
                    var offhand = caster.method_5998(HexUtils.otherHand(castingHand));
                    if (!offhand.isEmpty()) {
                        out.add(offhand);
                    }
                }

                // If we're casting from the main hand, try to pick from the slot one to the right of the selected slot
                // Otherwise, scan the hotbar left to right
                var anchorSlot = castingHand != class_1268.field_5810
                    ? (caster.method_31548().field_7545 + 1) % 9
                    : 0;


                for (int delta = 0; delta < 9; delta++) {
                    var slot = (anchorSlot + delta) % 9;
                    out.add(caster.method_31548().method_5438(slot));
                }

                yield out;
            }
            case EXTRACTION -> {
                // https://wiki.vg/Inventory is WRONG
                // slots 0-8 are the hotbar
                // for what purpose i cannot imagine
                // http://redditpublic.com/images/b/b2/Items_slot_number.png looks right
                // and offhand is 150 Inventory.java:464
                var out = new ArrayList<class_1799>();

                // First, the inventory backwards
                // We use inv.items here to get the main inventory, but not offhand or armor
                class_1661 inv = caster.method_31548();
                for (int i = inv.field_7547.size() - 1; i >= 0; i--) {
                    if (i != inv.field_7545) {
                        out.add(inv.field_7547.get(i));
                    }
                }

                // then the offhand, then the selected hand
                out.addAll(inv.field_7544);
                out.add(inv.method_7391());

                yield out;
            }
        };
    }

    /**
     * Get the primary/secondary item stacks this env can use (i.e. main hand and offhand for the player).
     */
    public abstract List<HeldItemInfo> getPrimaryStacks();

    protected List<HeldItemInfo> getPrimaryStacksForPlayer(class_1268 castingHand, class_3222 caster) {
        var primaryItem = caster.method_5998(castingHand);

        if (primaryItem.method_7960())
            primaryItem = class_1799.field_8037.method_7972();

        var secondaryItem = caster.method_5998(HexUtils.otherHand(castingHand));

        if (secondaryItem.isEmpty())
            secondaryItem = class_1799.field_8037.method_7972();

        return List.of(new HeldItemInfo(secondaryItem, HexUtils.otherHand(castingHand)), new HeldItemInfo(primaryItem,
            castingHand));
    }

    /**
     * Return the slot from which to take blocks and items.
     */
    @Nullable
    public class_1799 queryForMatchingStack(Predicate<class_1799> stackOk) {
        var stacks = this.getUsableStacks(StackDiscoveryMode.QUERY);
        for (class_1799 stack : stacks) {
            if (stackOk.test(stack)) {
                return stack;
            }
        }

        return null;
    }

    public record HeldItemInfo(class_1799 stack, @Nullable class_1268 hand) {
        public class_1799 component1() {
            return stack;
        }

        public @Nullable class_1268 component2() {
            return hand;
        }
    }

    /**
     * Return the slot from which to take blocks and items.
     */
    // TODO winfy: resolve the null here
    public @Nullable HeldItemInfo getHeldItemToOperateOn(Predicate<class_1799> stackOk) {
        var stacks = this.getPrimaryStacks();
        for (HeldItemInfo stack : stacks) {
            if (stackOk.test(stack.stack)) {
                return stack;
            }
        }

        return null;
    }

    /**
     * Whether to provide infinite items.
     */
    protected boolean isCreativeMode() {
        return false;
    }

    /**
     * Attempt to withdraw some number of items from stacks available.
     * <p>
     * Return whether it was successful.
     */
    public boolean withdrawItem(Predicate<class_1799> stackOk, int count, boolean actuallyRemove) {
        if (this.isCreativeMode()) {
            return true;
        }

        var stacks = this.getUsableStacks(StackDiscoveryMode.EXTRACTION);

        var presentCount = 0;
        var matches = new ArrayList<class_1799>();
        for (class_1799 stack : stacks) {
            if (stackOk.test(stack)) {
                presentCount += stack.method_7947();
                matches.add(stack);

                if (presentCount >= count)
                    break;
            }
        }
        if (presentCount < count) {
            return false;
        }

        if (!actuallyRemove) {
            return true;
        } // Otherwise do the removal

        var remaining = count;
        for (class_1799 match : matches) {
            var toWithdraw = Math.min(match.method_7947(), remaining);
            match.method_7934(toWithdraw);

            remaining -= toWithdraw;
            if (remaining <= 0) {
                return true;
            }
        }

        throw new IllegalStateException("unreachable");
    }

    /**
     * Attempt to replace the first stack found which matches the predicate with the stack to replace with.
     *
     * @return whether it was successful.
     */
    public abstract boolean replaceItem(Predicate<class_1799> stackOk, class_1799 replaceWith,
        @Nullable class_1268 hand);


    public boolean replaceItemForPlayer(Predicate<class_1799> stackOk, class_1799 replaceWith,
        @Nullable class_1268 hand, class_3222 caster) {
        if (caster == null)
            return false;

        if (hand != null && stackOk.test(caster.method_5998(hand))) {
            caster.method_6122(hand, replaceWith);
            return true;
        }

        class_1661 inv = caster.method_31548();
        for (int i = inv.field_7547.size() - 1; i >= 0; i--) {
            if (i != inv.field_7545) {
                if (stackOk.test(inv.field_7547.get(i))) {
                    inv.method_5447(i, replaceWith);
                    return true;
                }
            }
        }

        if (stackOk.test(caster.method_5998(getOtherHand()))) {
            caster.method_6122(getOtherHand(), replaceWith);
            return true;
        }
        if (stackOk.test(caster.method_5998(getCastingHand()))) {
            caster.method_6122(getCastingHand(), replaceWith);
            return true;
        }

        return false;
    }

    /**
     * The order/mode stacks should be discovered in
     */
    public enum StackDiscoveryMode {
        /**
         * When finding items to pick (hotbar)
         */
        QUERY,
        /**
         * When extracting things
         */
        EXTRACTION,
    }

    public abstract FrozenPigment getPigment();

    public abstract @Nullable FrozenPigment setPigment(@Nullable FrozenPigment pigment);

    public abstract void produceParticles(ParticleSpray particles, FrozenPigment colorizer);

    public abstract void printMessage(class_2561 message);
}
