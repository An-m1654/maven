package at.petrak.hexcasting.common.blocks.decoration;

import at.petrak.hexcasting.common.particles.ConjureParticleOptions;
import net.minecraft.class_10225;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_4538;
import net.minecraft.class_5541;
import net.minecraft.class_5819;
import net.minecraft.world.level.*;

public class BlockSconce extends class_5541 implements class_3737 {
    public static final class_2754<class_2350> FACING = class_2741.field_12525;
    public static final class_2746 WATERLOGGED = class_2741.field_12508;
    protected static class_265 AABB_UP = class_2248.method_9541(4, 0, 4, 12, 1, 12);
    protected static class_265 AABB_DOWN = class_2248.method_9541(4, 15, 4, 12, 16, 12);
    protected static class_265 AABB_NORTH = class_2248.method_9541(4, 4, 15, 12, 12, 16);
    protected static class_265 AABB_SOUTH = class_2248.method_9541(4, 4, 0, 12, 12, 1);
    protected static class_265 AABB_WEST = class_2248.method_9541(15, 4, 4, 16, 12, 12);
    protected static class_265 AABB_EAST = class_2248.method_9541(0, 4, 4, 1, 12, 12);

    public BlockSconce(class_2251 p_49795_) {
        super(p_49795_);
        this.method_9590(this.field_10647.method_11664()
            .method_11657(WATERLOGGED, false).method_11657(FACING, class_2350.field_11036));
    }

    @Override
    public class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Override
    public class_265 method_9530(class_2680 pState, class_1922 pLevel, class_2338 pPos, class_3726 pContext) {
        return switch (pState.method_11654(FACING)) {
            case field_11036 -> AABB_UP;
            case field_11033 -> AABB_DOWN;
            case field_11043 -> AABB_NORTH;
            case field_11034 -> AABB_EAST;
            case field_11035 -> AABB_SOUTH;
            case field_11039 -> AABB_WEST;
        };
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(FACING, WATERLOGGED);
    }

    @Override
    public class_2680 method_9605(class_1750 pContext) {
        class_3610 fluidState = pContext.method_8045().method_8316(pContext.method_8037());
        class_2680 blockstate;
        blockstate = this.method_9564().method_11657(FACING, pContext.method_8038());
        blockstate = blockstate.method_11657(WATERLOGGED,
                fluidState.method_15767(class_3486.field_15517) && fluidState.method_15761() == 8);
        return blockstate;
    }
    
    @Override
    public class_2680 method_9559(class_2680 pState, class_4538 pLevel, class_10225 pTickAccess,
                                  class_2338 pCurrentPos, class_2350 pFacing, class_2338 pFacingPos, class_2680 pFacingState,
                                  class_5819 rand) {
        if (pState.method_11654(WATERLOGGED)) {
            pTickAccess.method_64312(pCurrentPos, class_3612.field_15910, class_3612.field_15910.method_15789(pLevel));
        }

        return super.method_9559(pState, pLevel, pTickAccess, pCurrentPos, pFacing, pFacingPos, pFacingState, rand);
    }

    @Override
    public void method_9496(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_5819 rand) {
        if (rand.method_43057() < 0.8f) {
            var cx = pPos.method_10263() + 0.5;
            var cy = pPos.method_10264() + 0.5;
            var cz = pPos.method_10260() + 0.5;
            //values for particle direction randomization
            //x 
            var dX = switch(pState.method_11654(FACING)){
                    case field_11034 -> rand.method_62816(0.01f, 0.05f);
                    case field_11039 -> rand.method_62816(-0.01f, -0.05f);
                    default -> rand.method_62816(-0.01f, 0.01f);
            };
            //y
            var dY = switch(pState.method_11654(FACING)){
                    case field_11036 -> rand.method_62816(0.01f, 0.05f);
                    case field_11033 -> rand.method_62816(-0.01f, -0.05f);
                    default -> rand.method_62816(-0.01f, 0.01f);
            };
            //z
            var dZ = switch(pState.method_11654(FACING)){
                    case field_11035 -> rand.method_62816(0.01f, 0.05f);
                    case field_11043 -> rand.method_62816(-0.01f, -0.05f);
                    default -> rand.method_62816(-0.01f, 0.01f);
            };
            int[] colors = {0xff_6f4fab, 0xff_b38ef3, 0xff_cfa0f3, 0xff_cfa0f3, 0xff_fffdd5};
            pLevel.method_8406(new ConjureParticleOptions(colors[rand.method_43048(colors.length)]), cx, cy, cz,
                dX, dY, dZ);
                
            if (rand.method_43057() < 0.08f) {
                pLevel.method_8486(cx, cy, cz,
                    class_3417.field_26980, class_3419.field_15245, 1.0F,
                    0.5F + rand.method_43057() * 1.2F, false);
            }
        }
    }
}
