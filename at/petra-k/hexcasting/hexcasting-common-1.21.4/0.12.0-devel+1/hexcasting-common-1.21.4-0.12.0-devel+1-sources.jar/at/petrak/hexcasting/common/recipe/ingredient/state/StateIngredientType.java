package at.petrak.hexcasting.common.recipe.ingredient.state;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public interface StateIngredientType<T extends StateIngredient> {

    MapCodec<T> codec();

    class_9139<class_9129, T> streamCodec();
}
