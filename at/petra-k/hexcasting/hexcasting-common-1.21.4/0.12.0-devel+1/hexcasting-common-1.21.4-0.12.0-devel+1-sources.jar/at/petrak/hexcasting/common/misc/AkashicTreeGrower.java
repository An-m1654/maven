package at.petrak.hexcasting.common.misc;

import at.petrak.hexcasting.common.lib.HexConfiguredFeatures;
import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2794;
import net.minecraft.class_2975;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

public class AkashicTreeGrower {
    public static final AkashicTreeGrower INSTANCE = new AkashicTreeGrower();

    public static final List<class_5321<class_2975<?, ?>>> GROWERS = Lists.newArrayList();

    public static void init() {
        GROWERS.add(HexConfiguredFeatures.AMETHYST_EDIFIED_TREE);
        GROWERS.add(HexConfiguredFeatures.AVENTURINE_EDIFIED_TREE);
        GROWERS.add(HexConfiguredFeatures.CITRINE_EDIFIED_TREE);
    }

    private class_5321<class_2975<?, ?>> getConfiguredFeature(class_5819 pRandom, boolean pLargeHive) {
        return GROWERS.get(pRandom.method_43048(GROWERS.size()));
    }

    public boolean growTree(class_3218 level, class_2794 chunkGenerator, class_2338 pos, class_2680 state, class_5819 random) {
        class_5321<class_2975<?, ?>> treeFeatureKey = getConfiguredFeature(random, hasFlowers(level, pos));
        if (treeFeatureKey == null) {
            return false;
        }
        class_6880<class_2975<?, ?>> holder1 = level.method_30349()
                .method_30530(class_7924.field_41239)
                .method_46746(treeFeatureKey)
                .orElse(null);
        level.method_8652(pos, class_2246.field_10124.method_9564(), class_2248.field_31036);

        class_2975<?, ?> configuredFeature = holder1.comp_349();
        return configuredFeature.method_12862(level, level.method_14178().method_12129(), level.field_9229, pos);
    }

    private boolean hasFlowers(class_1936 level, class_2338 pos) {
        for (class_2338 blockpos : class_2338.class_2339.method_10097(pos.method_10074().method_10076(2).method_10088(2), pos.method_10084().method_10077(2).method_10089(2))) {
            if (level.method_8320(blockpos).method_26164(class_3481.field_20339)) {
                return true;
            }
        }

        return false;
    }
}
