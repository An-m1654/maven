package at.petrak.hexcasting.common.casting.arithmetic;

import at.petrak.hexcasting.api.casting.arithmetic.Arithmetic;
import at.petrak.hexcasting.api.casting.arithmetic.engine.InvalidOperatorException;
import at.petrak.hexcasting.api.casting.arithmetic.operator.Operator;
import at.petrak.hexcasting.api.casting.arithmetic.operator.OperatorUnary;
import at.petrak.hexcasting.api.casting.arithmetic.predicates.IotaMultiPredicate;
import at.petrak.hexcasting.api.casting.arithmetic.predicates.IotaPredicate;
import at.petrak.hexcasting.api.casting.iota.DoubleIota;
import at.petrak.hexcasting.api.casting.iota.Vec3Iota;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.common.casting.arithmetic.operator.vec.OperatorPack;
import at.petrak.hexcasting.common.casting.arithmetic.operator.vec.OperatorUnpack;
import at.petrak.hexcasting.common.casting.arithmetic.operator.vec.OperatorVec3Delegating;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import net.minecraft.class_243;

import static at.petrak.hexcasting.api.casting.arithmetic.operator.Operator.downcast;
import static at.petrak.hexcasting.common.lib.hex.HexIotaTypes.DOUBLE;
import static at.petrak.hexcasting.common.lib.hex.HexIotaTypes.VEC3;

public enum Vec3Arithmetic implements Arithmetic {
	INSTANCE;

	public static final List<HexPattern> OPS = List.of(
			PACK,
			UNPACK,
			ADD,
			SUB,
			MUL,
			DIV,
			ABS,
			POW,
			FLOOR,
			CEIL,
			MOD
	);

	public static final IotaMultiPredicate ACCEPTS = IotaMultiPredicate.any(IotaPredicate.ofType(VEC3), IotaPredicate.ofType(DOUBLE));

	@Override
	public String arithName() {
		return "vec3_math";
	}

	@Override
	public Iterable<HexPattern> opTypes() {
		return OPS;
	}

	@Override
	public Operator getOperator(HexPattern pattern) {
		if (pattern.equals(PACK)) {
			return OperatorPack.INSTANCE;
		} else if (pattern.equals(UNPACK)) {
			return OperatorUnpack.INSTANCE;
		} else if (pattern.equals(ADD)) {
			return make2Fallback(pattern);
		} else if (pattern.equals(SUB)) {
			return make2Fallback(pattern);
		} else if (pattern.equals(MUL)) {
			return make2Double(pattern, class_243::method_1026);
		} else if (pattern.equals(DIV)) {
			return make2Vec(pattern, class_243::method_1036);
		} else if (pattern.equals(ABS)) {
			return make1Double(class_243::method_1033);
		} else if (pattern.equals(POW)) {
			return make2Vec(pattern, (u, v) -> v.normalize().scale(u.dot(v.normalize())));
		} else if (pattern.equals(FLOOR)) {
			return make1(v -> new class_243(Math.floor(v.field_1352), Math.floor(v.field_1351), Math.floor(v.field_1350)));
		} else if (pattern.equals(CEIL)) {
			return make1(v -> new class_243(Math.ceil(v.field_1352), Math.ceil(v.field_1351), Math.ceil(v.field_1350)));
		} else if (pattern.equals(MOD)) {
			return make2Fallback(pattern);
		}
		throw new InvalidOperatorException(pattern + " is not a valid operator in Arithmetic " + this + ".");
	}
	public static OperatorUnary make1(Function<class_243, class_243> op) {
		return new OperatorUnary(ACCEPTS, i -> new Vec3Iota(op.apply(downcast(i, VEC3).getVec3())));
	}
	public static OperatorUnary make1Double(Function<class_243, Double> op) {
		return new OperatorUnary(ACCEPTS, i -> new DoubleIota(op.apply(downcast(i, VEC3).getVec3())));
	}
	public static OperatorVec3Delegating make2Fallback(HexPattern pattern) {
		return new OperatorVec3Delegating(null, pattern);
	}
	public static OperatorVec3Delegating make2Double(HexPattern pattern, BiFunction<class_243, class_243, Double> op) {
		return new OperatorVec3Delegating(op.andThen(DoubleIota::new), pattern);
	}
	public static OperatorVec3Delegating make2Vec(HexPattern pattern, BiFunction<class_243, class_243, class_243> op) {
		return new OperatorVec3Delegating(op.andThen(Vec3Iota::new), pattern);
	}
}
