package at.petrak.hexcasting.common.lib;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexCreativeTabs {
    public static void registerCreativeTabs(BiConsumer<class_1761, class_2960> r) {
        for (var e : TABS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<class_2960, class_1761> TABS = new LinkedHashMap<>();

    public static final class_1761 HEX = register("hexcasting", class_1761.method_47307(class_1761.class_7915.field_41049, 0)
            .method_47320(() -> new class_1799(HexItems.SPELLBOOK)));

    public static final class_5321<class_1761> HEX_KEY = class_5321.method_29179(class_7923.field_44687.method_46765(), modLoc("hexcasting"));

    public static final class_1761 SCROLLS = register("scrolls", class_1761.method_47307(class_1761.class_7915.field_41049, 0)
            .method_47320(() -> new class_1799(HexItems.SCROLL_LARGE)));

    public static final class_5321<class_1761> SCROLLS_KEY = class_5321.method_29179(class_7923.field_44687.method_46765(), modLoc("scrolls"));

    private static class_1761 register(String name, class_1761.class_7913 tabBuilder) {
        var tab = tabBuilder.method_47321(class_2561.method_43471("itemGroup.hexcasting." + name)).method_47324();
        var old = TABS.put(modLoc(name), tab);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + name);
        }
        return tab;
    }
}
