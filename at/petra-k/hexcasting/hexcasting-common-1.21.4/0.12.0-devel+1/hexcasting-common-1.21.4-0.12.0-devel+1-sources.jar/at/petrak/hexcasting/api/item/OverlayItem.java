package at.petrak.hexcasting.api.item;

import java.util.function.Predicate;
import net.minecraft.class_1799;

public interface OverlayItem {
    Predicate<class_1799> isSealed();
    Predicate<class_1799> hasIota();
}
