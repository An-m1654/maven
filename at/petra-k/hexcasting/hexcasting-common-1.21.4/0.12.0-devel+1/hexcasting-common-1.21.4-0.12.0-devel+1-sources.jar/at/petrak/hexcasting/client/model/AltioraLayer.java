package at.petrak.hexcasting.client.model;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.class_10055;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5599;
import net.minecraft.class_563;
import net.minecraft.class_583;
import net.minecraft.class_918;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class AltioraLayer<S extends class_10055, M extends class_583<class_10055>> extends class_3887<S, M> {
    private static final class_2960 TEX_LOC = modLoc("textures/misc/altiora.png");

    private final class_563 elytraModel;

    public AltioraLayer(class_3883<S, M> renderer, class_5599 ems) {
        super(renderer);
        this.elytraModel = new class_563(ems.method_32072(HexModelLayers.ALTIORA));
        System.out.println("AltioraLayer still needs a fix. Currently, CCAltiora is changed to sync to client also. Not sure if that'll work.");
    }

//-    @Override
//    public void render(PoseStack ps, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
//        float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw,
//        float headPitch) {
//        var altiora = IXplatAbstractions.INSTANCE.getAltiora(player);
//-        // do a best effort to not render over other elytra, although we can never patch up everything
//        var chestSlot = player.getItemBySlot(EquipmentSlot.CHEST);
//        if (altiora != null && !chestSlot.is(Items.ELYTRA)) {
//            ps.pushPose();
//            ps.translate(0.0, 0.0, 0.125);
//
//            this.getParentModel().copyPropertiesTo(this.elytraModel);
//            this.elytraModel.setupAnim(player, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
//            VertexConsumer verts = ItemRenderer.getArmorFoilBuffer(
//                    buffer, RenderType.armorCutoutNoCull(TEX_LOC), true);
//-            // TODO port: check color
//            this.elytraModel.renderToBuffer(ps, verts, packedLight, OverlayTexture.NO_OVERLAY, -1);
//            ps.popPose();
//        }
//    }

    @Override
    public void render(class_4587 ps, class_4597 buffer, int packedLight, S player, float limbSwing, float limbSwingAmount) {
        var altiora = IXplatAbstractions.INSTANCE.getAltiora(class_310.method_1551().field_1724); // THIS USES CLIENT MINECRAFT PLAYER!!!!!!!!!!! IT MIGHT NOT CONNECT WITH THE OTHER MINECRAFT PLAYER USE
//         do a best effort to not render over other elytra, although we can never patch up everything
        var chestSlot = player.field_53418;
        if (altiora != null && !chestSlot.method_31574(class_1802.field_8833)) {
            ps.method_22903();
            ps.method_22904(0.0, 0.0, 0.125);

            this.elytraModel.method_17079(player);
            class_4588 verts = class_918.method_27952(
                    buffer, class_1921.method_25448(TEX_LOC), true);
            // TODO port: check color
            this.elytraModel.method_62100(ps, verts, packedLight, class_4608.field_21444, -1);

            ps.method_22909();
        }
    }
}
