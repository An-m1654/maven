package at.petrak.hexcasting.common.recipe.ingredient.state;

import at.petrak.hexcasting.common.lib.HexStateIngredients;
import com.google.common.collect.ImmutableSet;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import javax.annotation.Nonnull;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.stream.Collectors;

public class StateIngredientBlocks implements StateIngredient {
    protected final ImmutableSet<class_2248> blocks;

    public StateIngredientBlocks(Collection<class_2248> blocks) {
        this.blocks = ImmutableSet.copyOf(blocks);
    }

    @Override
    public StateIngredientType<?> getType() {
        return HexStateIngredients.BLOCKS;
    }

    @Override
    public boolean test(class_2680 state) {
        return blocks.contains(state.method_26204());
    }

    @Override
    public class_2680 pick(Random random) {
        return blocks.asList().get(random.nextInt(blocks.size())).method_9564();
    }

    @Override
    public List<class_1799> getDisplayedStacks() {
        return blocks.stream()
            .filter(b -> b.method_8389() != class_1802.field_8162)
            .map(class_1799::new)
            .collect(Collectors.toList());
    }

    @Override
    public List<class_2680> getDisplayed() {
        return blocks.stream().map(class_2248::method_9564).collect(Collectors.toList());
    }

    @Nonnull
    protected List<class_2248> getBlocks() {
        return blocks.asList();
    }

    @Override
    public String toString() {
        return "StateIngredientBlocks{" + blocks.toString() + "}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        return blocks.equals(((StateIngredientBlocks) o).blocks);
    }

    @Override
    public int hashCode() {
        return Objects.hash(blocks);
    }


    public static class Type implements StateIngredientType<StateIngredientBlocks> {
        public static final MapCodec<StateIngredientBlocks> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                class_7923.field_41175.method_39673().listOf().fieldOf("block").forGetter(StateIngredientBlocks::getBlocks)
        ).apply(instance, StateIngredientBlocks::new));
        public static final class_9139<class_9129, StateIngredientBlocks> STREAM_CODEC = class_9139.method_56434(
                class_9135.method_56365(class_7924.field_41254).method_56433(class_9135.method_56363()), StateIngredientBlocks::getBlocks,
                StateIngredientBlocks::new
        );

        @Override
        public MapCodec<StateIngredientBlocks> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, StateIngredientBlocks> streamCodec() {
            return STREAM_CODEC;
        }
    }
}
