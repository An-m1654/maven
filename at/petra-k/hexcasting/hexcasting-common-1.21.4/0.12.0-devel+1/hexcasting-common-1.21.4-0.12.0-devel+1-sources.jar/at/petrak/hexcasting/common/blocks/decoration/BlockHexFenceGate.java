package at.petrak.hexcasting.common.blocks.decoration;

import at.petrak.hexcasting.annotations.SoftImplement;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4719;

public class BlockHexFenceGate extends class_2349 {

    public BlockHexFenceGate(class_2251 $$0) {
        super(class_4719.field_21681, $$0);
    }

    @SoftImplement("forge")
    public boolean isFlammable(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return true;
    }

    @SoftImplement("forge")
    public int getFlammability(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return 20;
    }

    @SoftImplement("forge")
    public int getFireSpreadSpeed(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return 5;
    }
}
