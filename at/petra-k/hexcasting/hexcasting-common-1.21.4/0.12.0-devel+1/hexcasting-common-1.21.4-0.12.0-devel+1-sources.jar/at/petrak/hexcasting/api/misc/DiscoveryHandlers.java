package at.petrak.hexcasting.api.misc;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

public class DiscoveryHandlers {
    private static final List<BiFunction<class_1657, String, class_1799>> DEBUG_DISCOVERER = new ArrayList<>();
    private static final List<Function<class_1657, List<class_1799>>> EXTRA_EQUIPMENT_DISCOVERY = new ArrayList<>();

    public static class_1799 findDebugItem(class_1657 player, String type) {
        for (var discoverer : DEBUG_DISCOVERER) {
            var stack = discoverer.apply(player, type);
            if (!stack.method_7960()) {
                return stack;
            }
        }
        return class_1799.field_8037;
    }

    public static List<class_1799> collectExtraEquipments(class_1657 player) {
        List<class_1799> stacks = new ArrayList<>();
        for (var discoverer : EXTRA_EQUIPMENT_DISCOVERY) {
            stacks.addAll(discoverer.apply(player));
        }
        return stacks;
    }

    public static void addDebugItemDiscoverer(BiFunction<class_1657, String, class_1799> discoverer) {
        DEBUG_DISCOVERER.add(discoverer);
    }

    public static void addExtraEquipmentDiscoverer(Function<class_1657, List<class_1799>> discoverer) {
        EXTRA_EQUIPMENT_DISCOVERY.add(discoverer);
    }
}
