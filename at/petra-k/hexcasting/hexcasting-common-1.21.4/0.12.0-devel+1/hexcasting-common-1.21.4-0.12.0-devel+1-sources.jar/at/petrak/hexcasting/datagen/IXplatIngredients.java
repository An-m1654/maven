package at.petrak.hexcasting.datagen;

import at.petrak.hexcasting.datagen.recipe.builders.FarmersDelightToolIngredient;
import java.util.EnumMap;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_6862;

public interface IXplatIngredients {
    class_6862<class_1792> glowstoneDust();

    class_1856 leather();

    class_6862<class_1792> ironNugget();

    class_6862<class_1792> goldNugget();

    class_6862<class_1792> copperIngot();

    class_6862<class_1792> ironIngot();

    class_6862<class_1792> goldIngot();

    EnumMap<class_1767, class_6862<class_1792>> dyes();

    class_6862<class_1792> stick();

    class_1856 whenModIngredient(class_1856 defaultIngredient, String modid, class_1856 modIngredient);

    FarmersDelightToolIngredient axeStrip();

    FarmersDelightToolIngredient axeDig();
}
