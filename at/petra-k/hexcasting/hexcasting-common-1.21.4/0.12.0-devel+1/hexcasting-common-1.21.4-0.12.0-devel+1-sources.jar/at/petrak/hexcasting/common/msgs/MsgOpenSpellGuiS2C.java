package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.eval.ResolvedPattern;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.client.gui.GuiSpellcasting;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_2487;
import net.minecraft.class_310;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Sent server->client when the player opens the spell gui to request the server provide the current stack.
 */
public record MsgOpenSpellGuiS2C(class_1268 hand, List<ResolvedPattern> patterns,
                                 List<Iota> stack,
                                 @Nullable
                                 class_2487 ravenmind,
                                 int parenCount
)
    implements class_8710 {
    public static final class_8710.class_9154<MsgOpenSpellGuiS2C> TYPE = new class_8710.class_9154<>(HexAPI.modLoc("cgui"));

    public static final class_9139<class_9129, MsgOpenSpellGuiS2C> STREAM_CODEC = class_9139.method_56906(
            class_9135.field_48547.method_56432(
                    isMain -> isMain ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND,
                    hand -> hand == InteractionHand.MAIN_HAND
            ), MsgOpenSpellGuiS2C::hand,
            ResolvedPattern.STREAM_CODEC.apply(class_9135.method_56363()), MsgOpenSpellGuiS2C::patterns,
            IotaType.TYPED_STREAM_CODEC.method_56433(class_9135.method_56363()), MsgOpenSpellGuiS2C::stack,
            class_9135.method_56382(class_9135.field_48556).method_56432(
                    opt -> opt.orElse(null),
                    Optional::ofNullable
            ), MsgOpenSpellGuiS2C::ravenmind,
            class_9135.field_48550, MsgOpenSpellGuiS2C::parenCount,
            MsgOpenSpellGuiS2C::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public void handle() {
        Handler.handle(this);
    }

    public static final class Handler {

        public static void handle(MsgOpenSpellGuiS2C msg) {
            class_310.method_1551().execute(() -> {
                var mc = class_310.method_1551();
                mc.method_1507(
                        new GuiSpellcasting(msg.hand(), msg.patterns(), msg.stack, msg.ravenmind,
                                msg.parenCount));
            });
        }
    }
}
