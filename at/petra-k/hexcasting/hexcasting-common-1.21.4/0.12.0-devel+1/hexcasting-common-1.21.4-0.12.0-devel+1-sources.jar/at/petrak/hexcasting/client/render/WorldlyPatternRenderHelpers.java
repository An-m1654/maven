package at.petrak.hexcasting.client.render;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.mod.HexConfig;
import at.petrak.hexcasting.client.entity.WallScrollRenderState;
import at.petrak.hexcasting.common.blocks.akashic.BlockAkashicBookshelf;
import at.petrak.hexcasting.common.blocks.akashic.BlockEntityAkashicBookshelf;
import at.petrak.hexcasting.common.blocks.circles.BlockEntitySlate;
import at.petrak.hexcasting.common.blocks.circles.BlockSlate;
import at.petrak.hexcasting.common.entities.EntityWallScroll;
import javax.annotation.Nullable;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2738;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_761;
import net.minecraft.class_7833;

/**
 * Helper methods for rendering patterns in the world.
 */
public class WorldlyPatternRenderHelpers {

    public static final PatternSettings SCROLL_SETTINGS = new PatternSettings("scroll",
            PatternSettings.PositionSettings.paddedSquare(2.0/16),
            PatternSettings.StrokeSettings.fromStroke(0.8/16),
            PatternSettings.ZappySettings.STATIC
    );

    public static final PatternSettings READABLE_SCROLL_SETTINGS = new PatternSettings("scroll_readable",
            PatternSettings.PositionSettings.paddedSquare(2.0/16),
            PatternSettings.StrokeSettings.fromStroke(0.8/16),
            PatternSettings.ZappySettings.READABLE
    );

    public static final PatternSettings WORLDLY_SETTINGS = new PatternSettings("worldly",
            PatternSettings.PositionSettings.paddedSquare(2.0/16),
            PatternSettings.StrokeSettings.fromStroke(0.8/16),
            PatternSettings.ZappySettings.STATIC
    );

    public static final PatternSettings WORLDLY_SETTINGS_WOBBLY = new PatternSettings("wobbly_world",
            PatternSettings.PositionSettings.paddedSquare(2.0/16),
            PatternSettings.StrokeSettings.fromStroke(0.8/16),
            PatternSettings.ZappySettings.WOBBLY
    );

    public static void renderPatternForScroll(HexPattern pattern, WallScrollRenderState scroll, class_4587 ps, class_4597 bufSource, int light, int blockSize, boolean showStrokeOrder)
    {
        ps.method_22903();
        ps.method_46416(-blockSize / 2f, -blockSize / 2f, 1f / 32f);
        renderPattern(pattern, showStrokeOrder ? READABLE_SCROLL_SETTINGS : SCROLL_SETTINGS,
                showStrokeOrder ? PatternColors.READABLE_SCROLL_COLORS : PatternColors.DEFAULT_PATTERN_COLOR,
                new class_2338(class_3532.method_15357(scroll.field_53325), class_3532.method_15357(scroll.field_53326), class_3532.method_15357(scroll.field_53327)).hashCode(), ps, bufSource, null, null, light, blockSize);
        ps.method_22909();
    }

    private static final int[] WALL_ROTATIONS = {180, 270, 0, 90};
    private static final class_2382[] SLATE_FACINGS = {new class_2382(0, -1, 0), new class_2382(-1, -1, 0), new class_2382(-1, -1, 1), new class_2382(0, -1 , 1)};
    private static final class_243[] WALL_NORMALS = {new class_243(0, 0, 1), new class_243(-1, 0, 0), new class_243(0, 0, -1), new class_243(1, 0, 0)};
    private static final class_2382[] SLATE_FLOORCEIL_FACINGS = {new class_2382(0,0,0), new class_2382(1,0,0), new class_2382(1,0,1), new class_2382(0,0,1)};

    public static void renderPatternForSlate(BlockEntitySlate tile, HexPattern pattern, class_4587 ps, class_4597 buffer, int light, class_2680 bs)
    {

        boolean isOnWall = bs.method_11654(BlockSlate.ATTACH_FACE) == class_2738.field_12471;
        boolean isOnCeiling = bs.method_11654(BlockSlate.ATTACH_FACE) == class_2738.field_12473;
        int facing = bs.method_11654(BlockSlate.FACING).method_10161();

        boolean energized = bs.method_11654(BlockSlate.ENERGIZED);
        boolean wombly = energized;
        if (HexConfig.client().staticActiveSlates()) {
            wombly = false;
        }

        ps.method_22903();

        class_243 normal = null;
        if(isOnWall){
            ps.method_22907(class_7833.field_40718.rotationDegrees(180));
            class_2382 tV = SLATE_FACINGS[facing % 4];
            ps.method_46416(tV.method_10263(), tV.method_10264(), tV.method_10260());
            ps.method_22907(class_7833.field_40716.rotationDegrees(WALL_ROTATIONS[facing % 4]));
            normal = WALL_NORMALS[facing % 4];
        } else {
            class_2382 tV = SLATE_FLOORCEIL_FACINGS[facing % 4];
            ps.method_46416(tV.method_10263(), tV.method_10264(), tV.method_10260());

            ps.method_22907(class_7833.field_40716.rotationDegrees(facing*-90));
            ps.method_22907(class_7833.field_40714.rotationDegrees(90 * (isOnCeiling ? -1 : 1)));
            if(isOnCeiling) ps.method_46416(0,-1,1);

            // Set the normal for floor/ceiling slates so lighting is correct
            // Floor faces up, ceiling faces down
        }
        renderPattern(pattern,
            wombly ? WORLDLY_SETTINGS_WOBBLY : WORLDLY_SETTINGS,
            wombly ? PatternColors.SLATE_WOBBLY_PURPLE_COLOR : PatternColors.DEFAULT_PATTERN_COLOR,
            tile.method_11016().hashCode(), ps, buffer, normal, null, light, 1);
        ps.method_22909();
    }

    private static final class_2382[] BLOCK_FACINGS = {new class_2382(0, -1, 1), new class_2382(0, -1, 0), new class_2382(-1, -1, 0), new class_2382(-1, -1, 1)};

    public static void renderPatternForAkashicBookshelf(BlockEntityAkashicBookshelf tile, HexPattern pattern, class_4587 ps, class_4597 buffer, int light, class_2680 bs)
    {

        int facing = bs.method_11654(BlockAkashicBookshelf.FACING).method_10161();

        ps.method_22903();
        ps.method_22907(class_7833.field_40718.rotationDegrees(180));

        class_2382 tV = BLOCK_FACINGS[facing % 4];
        ps.method_46416(tV.method_10263(), tV.method_10264(), tV.method_10260());
        ps.method_22907(class_7833.field_40716.rotationDegrees(WALL_ROTATIONS[facing % 4]));

        int actualLight = class_761.method_23794(tile.method_10997(), tile.method_11016().method_10093(bs.method_11654(BlockAkashicBookshelf.FACING)));

        renderPattern(pattern, WORLDLY_SETTINGS , PatternColors.DEFAULT_PATTERN_COLOR,
                tile.method_11016().hashCode(), ps, buffer, WALL_NORMALS[facing % 4].method_18805(-1, -1, -1), -0.02f, actualLight, 1);
        ps.method_22909();
    }

    /**
     * Renders a pattern in world space based on the given transform requirements
     */
    public static void renderPattern(HexPattern pattern, PatternSettings patSets, PatternColors patColors,
        double seed, class_4587 ps, class_4597 bufSource, class_243 normal, @Nullable Float zOffset,
        int light, int blockSize)
    {

        ps.method_22903();


        float z = zOffset != null ? zOffset : ((-1f / 16f) - 0.01f);

        normal = normal != null ? normal : new class_243(0, 0, -1);

        ps.method_46416(0,0, z);
        ps.method_22905(blockSize, blockSize, 1);

        PatternRenderer.renderPattern(pattern, ps, new PatternRenderer.WorldlyBits(bufSource, light, normal),
                patSets, patColors, seed, blockSize * 512);

        ps.method_22909();
    }
}
