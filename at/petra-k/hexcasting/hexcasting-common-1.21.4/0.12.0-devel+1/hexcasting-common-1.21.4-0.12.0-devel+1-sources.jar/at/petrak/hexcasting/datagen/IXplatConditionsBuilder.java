package at.petrak.hexcasting.datagen;

import net.minecraft.class_5797;

public interface IXplatConditionsBuilder extends class_5797 {
    IXplatConditionsBuilder whenModLoaded(String modid);

    IXplatConditionsBuilder whenModMissing(String modid);
}
