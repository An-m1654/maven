package at.petrak.hexcasting.api.player;

import at.petrak.paucal.api.PaucalCodecs;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * A null sentinel means no sentinel
 */
public record Sentinel(boolean extendsRange, class_243 position, class_5321<class_1937> dimension) {

    public static final class_9139<class_9129, Sentinel> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48547, Sentinel::extendsRange,
            PaucalCodecs.VEC3, Sentinel::position,
            class_5321.method_56038(class_7924.field_41223), Sentinel::dimension,
            Sentinel::new
    );
}
