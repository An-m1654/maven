package at.petrak.hexcasting.client;

import at.petrak.hexcasting.api.mod.HexConfig;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.msgs.MsgShiftScrollC2S;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import net.minecraft.class_1792;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class ShiftScrollListener {
    private static double mainHandDelta = 0;
    private static double offHandDelta = 0;

    public static boolean onScrollInGameplay(double delta) {
        if (class_310.method_1551().field_1755 != null) {
            return false;
        }

        if (HexConfig.client().disableInworldScrolling()) return false;

        return onScroll(delta, true);
    }

    public static boolean onScroll(double delta, boolean needsSneaking) {
        return onScroll(delta, needsSneaking, true);
    }

    public static boolean onScroll(double delta, boolean needsSneaking, boolean allowInverting) {
        class_746 player = class_310.method_1551().field_1724;
        // not .isCrouching! that fails for players who are not on the ground
        // yes, this does work if you remap your sneak key
        if (player != null && (player.method_5715() || !needsSneaking)) {
            // Spectators shouldn't interact with items!
            if (player.method_7325()) {
                return false;
            }

            if (IsScrollableItem(player.method_6047().method_7909())) {
                mainHandDelta += delta * getScrollModifier(player.method_6047().method_7909(), allowInverting);
                return true;
            } else if (IsScrollableItem(player.method_6079().method_7909())) {
                offHandDelta += delta * getScrollModifier(player.method_6079().method_7909(), allowInverting);
                return true;
            }
        }

        return false;
    }

    public static void clientTickEnd() {
        if (mainHandDelta != 0 || offHandDelta != 0) {
            IClientXplatAbstractions.INSTANCE.sendPacketToServer(
                new MsgShiftScrollC2S(mainHandDelta, offHandDelta, class_310.method_1551().field_1690.field_1867.method_1434())
            );
            mainHandDelta = 0;
            offHandDelta = 0;
        }
    }

    private static boolean IsScrollableItem(class_1792 item) {
        return item == HexItems.SPELLBOOK || item == HexItems.ABACUS;
    }

    private static double getScrollModifier(class_1792 item, boolean allowInverting) {
        if (!allowInverting) return 1;

        if (item == HexItems.SPELLBOOK) {
            return HexConfig.client().invertSpellbookScrollDirection() ? -1 : 1;
        } else if (item == HexItems.ABACUS) {
            return HexConfig.client().invertAbacusScrollDirection() ? -1 : 1;
        } else {
            return 1;
        }
    }
}
