package at.petrak.hexcasting.common.items;

import at.petrak.hexcasting.annotations.SoftImplement;
import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.items.magic.ItemTrinket;
import at.petrak.hexcasting.common.lib.HexAttributes;
import at.petrak.hexcasting.xplat.IXplatAccessoriesAbstractions;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1301;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_238;
import net.minecraft.class_2969;
import net.minecraft.class_6880;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Predicate;

public class ItemLens extends class_1792 implements HexBaubleItem { // Wearable,

    // The 0.1 is *additive*

    public static final class_1322 GRID_ZOOM = new class_1322(
            HexAPI.modLoc("scrying_lens_zoom"), 0.33, class_1322.class_1323.field_6330);

    public static final class_1322 SCRY_SIGHT = new class_1322(
            HexAPI.modLoc("scrying_lens_sight"), 1.0, class_1322.class_1323.field_6328);

    public static final class_9285 MODIFIERS = class_9285.method_57480()
        .method_57487(HexAttributes.GRID_ZOOM, GRID_ZOOM, class_9274.field_49219)
        .method_57487(HexAttributes.GRID_ZOOM, GRID_ZOOM, class_9274.field_49223)
        .method_57487(HexAttributes.SCRY_SIGHT, SCRY_SIGHT, class_9274.field_49219)
        .method_57487(HexAttributes.SCRY_SIGHT, SCRY_SIGHT, class_9274.field_49223)
        .method_57486();

    public static class MobCanWearArmorEntitySelector implements Predicate<class_1297> {
        private final class_1799 itemStack;

        public MobCanWearArmorEntitySelector(class_1799 itemStack) {
            this.itemStack = itemStack;
        }

        public boolean test(@Nullable class_1297 entity) {
            if (!entity.method_5805()) {
                return false;
            } else {
                if (!(entity instanceof class_1309 livingEntity)) {
                    return false;
                } else {
                    return livingEntity.method_6118(livingEntity.method_32326(itemStack)).method_7960();
                }
            }
        }
    }

    public static boolean dispenseArmor(class_2342 blockSource, class_1799 itemStack) {
        class_2338 blockPos = blockSource.comp_1968().method_10093(blockSource.comp_1969().method_11654(class_2315.field_10918));
        List<class_1309> list = blockSource.comp_1967()
                .method_8390(class_1309.class, new class_238(blockPos), class_1301.field_6155.and(new MobCanWearArmorEntitySelector(itemStack)));
        if (list.isEmpty()) {
            return false;
        } else {
            class_1309 livingEntity = list.get(0);
            class_1304 equipmentSlot = livingEntity.method_32326(itemStack);
            class_1799 itemStack2 = itemStack.method_7971(1);
            livingEntity.method_5673(equipmentSlot, itemStack2);
            if (livingEntity instanceof class_1308) {
                ((class_1308)livingEntity).method_5946(equipmentSlot, 2.0F);
                ((class_1308)livingEntity).method_5971();
            }

            return true;
        }
    }

    public ItemLens(class_1793 pProperties) {
        super(pProperties);
        class_2315.method_10009(this, new class_2969() {
            protected @NotNull class_1799 method_10135(@NotNull class_2342 world, @NotNull class_1799 stack) {
                this.method_27955(dispenseArmor(world, stack));
                return stack;
            }
        });
    }

    @Override
    public Multimap<class_6880<class_1320>, class_1322> getHexBaubleAttrs(class_1799 stack) {
        HashMultimap<class_6880<class_1320>, class_1322> out = HashMultimap.create();
        out.put(HexAttributes.GRID_ZOOM, GRID_ZOOM);
        out.put(HexAttributes.SCRY_SIGHT, SCRY_SIGHT);
        return out;
    }

    // In fabric impled with extension property?
    @Nullable
    @SoftImplement("forge")
    public class_1304 getEquipmentSlot(class_1799 stack) {
        return class_1304.field_6169;
    }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 interactionHand) {
        if (IXplatAccessoriesAbstractions.INSTANCE.accessoryModInstalled()) {
            return IXplatAccessoriesAbstractions.INSTANCE.customUseCode(level, player, interactionHand, super::method_7836);
        }
        return super.method_7836(level, player, interactionHand);
    }

    //    @Nullable
//    @Override
//    public SoundEvent getEquipSound() {
//        return SoundEvents.AMETHYST_BLOCK_CHIME;
//    }

}
