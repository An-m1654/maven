package at.petrak.hexcasting.client.particles;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.particles.ConjureParticleOptions;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1059;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_4668;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.class_9848;
import net.minecraft.class_9851;
import net.minecraft.client.particle.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Random;
import java.util.function.Function;

public class ConjureParticle extends class_4003 {
    private static final Random RANDOM = new Random();

    private final class_4002 sprites;

    ConjureParticle(class_638 pLevel, double x, double y, double z, double dx, double dy, double dz,
        class_4002 pSprites, int color) {
        super(pLevel, x, y, z, dx, dy, dz);
        this.field_17867 *= 0.9f;
        this.method_34753(dx, dy, dz);

        var r = class_9848.method_61327(color);
        var g = class_9848.method_61329(color);
        var b = class_9848.method_61331(color);
        this.method_3084(r / 255f, g / 255f, b / 255f);
        this.method_3083(0.3f);

        this.field_28786 = 0.96F;
        this.field_3844 = dy != 0 && dx != 0 && dz != 0 ? -0.01F : 0F;
        this.field_28787 = true;
        this.sprites = pSprites;

        this.field_3839 = RANDOM.nextFloat(360);
        this.field_3857 = this.field_3839;

        this.field_3847 = (int) (64.0 / ((Math.random() + 3f) * 0.25f));
        this.field_3862 = false;
        this.method_18142(pSprites);
    }

    public @NotNull class_3999 method_18122() {
        return CONJURE_RENDER_TYPE;
    }

    public void method_3070() {
        super.method_3070();
        this.method_18142(this.sprites);
        this.field_3841 = 1.0f - ((float) this.field_3866 / (float) this.field_3847);
        this.field_3841 *= 0.3f;
        this.field_17867 *= 0.96f;
    }

    public void method_18142(@NotNull class_4002 pSprite) {
        if (!this.field_3843) {
            int age = this.field_3866 * 4;
            if (age > this.field_3847) {
                age /= 4;
            }
            this.method_18141(pSprite.method_18138(age, this.field_3847));
        }
    }

    public static class Provider implements class_707<ConjureParticleOptions> {
        private final class_4002 sprite;

        public Provider(class_4002 pSprites) {
            this.sprite = pSprites;
        }

        @Nullable
        @Override
        public class_703 createParticle(ConjureParticleOptions type, class_638 level,
            double pX, double pY, double pZ,
            double pXSpeed, double pYSpeed, double pZSpeed) {
            return new ConjureParticle(level, pX, pY, pZ, pXSpeed, pYSpeed, pZSpeed, this.sprite, type.color());
        }
    }

    // https://github.com/VazkiiMods/Botania/blob/db85d778ab23f44c11181209319066d1f04a9e3d/Xplat/src/main/java/vazkii/botania/client/fx/FXWisp.java
//    private record ConjureRenderType() implements ParticleRenderType {
//-        @Override
//        public BufferBuilder begin(Tesselator tess, TextureManager texMan) {
//            Minecraft.getInstance().gameRenderer.lightTexture().turnOnLightLayer();
//            RenderSystem.depthMask(false);
//            RenderSystem.enableBlend();
//            RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
//
//            RenderSystem.setShaderTexture(0, TextureAtlas.LOCATION_PARTICLES);
//            var tex = texMan.getTexture(TextureAtlas.LOCATION_PARTICLES);
//            IClientXplatAbstractions.INSTANCE.setFilterSave(tex, false, false);
//            RenderSystem.enableDepthTest();
//            return tess.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.PARTICLE);
//        }
//
//-        @Override
//        public String toString() {
//            return HexAPI.MOD_ID + ":conjure";
//        }
//    }
    private static final class_1921 ConjureRenderType = class_1921.method_24049(
            HexAPI.MOD_ID + ":conjure",
            class_290.field_1584,
            class_293.class_5596.field_27382,
            1536,
            false,
            false,
            class_1921.class_4688.method_23598()
                    .method_34578(class_4668.field_55138)
                    .method_23608(class_4668.field_21383) // Minecraft.getInstance().gameRenderer.lightTexture().turnOnLightLayer()
                    .method_23616(class_4668.field_21350) // RenderSystem.depthMask(false)
                    .method_23615(class_4668.field_21367) // enableBlend() & blendFunc(...)
                    .method_34577(
                        new class_4668.class_4683(
                            class_1059.field_17898,
                            class_9851.field_52395,
                            false
                        )
                    )
//                  ^ setShaderTexture(...) & IClientXplatAbstractions.INSTANCE.setFilterSave(...)
//                  .setDepthTestState(RenderStateShard.LEQUAL_DEPTH_TEST) // enableDepthTest. This is default behavior
                    .method_23617(false)
    );
    public static final class_3999 CONJURE_RENDER_TYPE = new class_3999("CONJURE_RENDER_TYPE", ConjureRenderType);
}
