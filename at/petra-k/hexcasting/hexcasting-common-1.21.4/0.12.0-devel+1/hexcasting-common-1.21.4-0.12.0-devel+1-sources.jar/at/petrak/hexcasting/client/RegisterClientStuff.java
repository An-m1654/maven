package at.petrak.hexcasting.client;

import at.petrak.hexcasting.api.item.IotaHolderItem;
import at.petrak.hexcasting.api.item.VariantItem;
import at.petrak.hexcasting.client.entity.WallScrollRenderer;
import at.petrak.hexcasting.client.render.GaslightingTracker;
import at.petrak.hexcasting.client.render.ScryingLensOverlays;
import at.petrak.hexcasting.client.render.be.BlockEntityAkashicBookshelfRenderer;
import at.petrak.hexcasting.client.render.be.BlockEntityQuenchedAllayRenderer;
import at.petrak.hexcasting.client.render.be.BlockEntitySlateRenderer;
import at.petrak.hexcasting.common.blocks.BlockQuenchedAllay;
import at.petrak.hexcasting.common.blocks.akashic.BlockAkashicBookshelf;
import at.petrak.hexcasting.common.blocks.akashic.BlockEntityAkashicBookshelf;
import at.petrak.hexcasting.common.entities.HexEntities;
import at.petrak.hexcasting.common.items.ItemStaff;
import at.petrak.hexcasting.common.items.magic.ItemMediaBattery;
import at.petrak.hexcasting.common.items.magic.ItemPackagedHex;
import at.petrak.hexcasting.common.items.storage.*;
import at.petrak.hexcasting.common.lib.HexBlockEntities;
import at.petrak.hexcasting.common.lib.HexBlocks;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import at.petrak.hexcasting.xplat.overrides.*;
import org.jetbrains.annotations.NotNull;

import java.util.*;
import java.util.function.*;
import net.minecraft.class_10402;
import net.minecraft.class_10482;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_322;
import net.minecraft.class_3300;
import net.minecraft.class_5614;
import net.minecraft.class_7923;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class RegisterClientStuff {
    public static Map<class_2960, List<class_1087>> QUENCHED_ALLAY_VARIANTS = new HashMap<>();
    public static final Map<BlockQuenchedAllay, Boolean> QUENCHED_ALLAY_TYPES = Map.of(
            HexBlocks.QUENCHED_ALLAY, false,
            HexBlocks.QUENCHED_ALLAY_TILES, true,
            HexBlocks.QUENCHED_ALLAY_BRICKS, true,
            HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL, true);

    public static void init() {
        var x = IClientXplatAbstractions.INSTANCE;
        // TODO: REMEMBER TO REGISTER THE OVERRIDES AT THE END!!!!!!!
        // TODO: registerSealableDataHolderOverrides (SHOULD SEPARATE THE TWO THAT USES IT)
        // ME: AY AY, ON IT, CAPTAIN
        // I DID IT, CAPTAIN!!!!!!!!!

        // registerVariantOverrides
        class_10482.field_55408.method_65325(ItemFocus.VARIANT_PRED, VariantPredicate.MAP_CODEC);
        // registerSealableDataHolderOverrides
        class_10482.field_55408.method_65325(ItemFocus.OVERLAY_PRED, OverlayPredicate.MAP_CODEC);
        // ThoughtKnot WRITTEN predicate
        class_10482.field_55408.method_65325(ItemThoughtKnot.WRITTEN_PRED, ThoughtKnotWrittenPredicate.MAP_CODEC);
        // registerScrollOverrides
        class_10482.field_55408.method_65325(ItemScroll.ANCIENT_PREDICATE, AncientPredicate.MAP_CODEC);
        // registerWandOverrides
        class_10482.field_55408.method_65325(ItemStaff.FUNNY_LEVEL_PREDICATE, FunnyLevelPredicate.MAP_CODEC);
        // registerGaslight4
        class_10482.field_55408.method_65325(GaslightingTracker.GASLIGHTING_PRED, GasLightingPredicate.MAP_CODEC);
        // registerPackagedSpellOverrides
        class_10482.field_55408.method_65325(ItemPackagedHex.HAS_PATTERNS_PRED, HasPatternsPredicate.MAP_CODEC);
        // Not in a function
        class_10482.field_55408.method_65325(ItemMediaBattery.MEDIA_PREDICATE, MediaPredicate.MAP_CODEC);
        class_10482.field_55408.method_65325(ItemMediaBattery.MAX_MEDIA_PREDICATE, MaxMediaPredicate.MAP_CODEC);
        class_10482.field_55408.method_65325(ItemSlate.WRITTEN_PRED, ItemSlateWrittenPredicate.MAP_CODEC);

//        registerSealableDataHolderOverrides(HexItems.FOCUS,
//            stack -> stack.has(HexDataComponents.IOTA_HOLDER_IOTA),
//            ItemFocus::isSealed);
//        registerSealableDataHolderOverrides(HexItems.SPELLBOOK,
//            stack -> HexItems.SPELLBOOK.readIota(stack) != null,
//            ItemSpellbook::isSealed);
//        registerVariantOverrides(HexItems.FOCUS, HexItems.FOCUS::getVariant);
//        registerVariantOverrides(HexItems.SPELLBOOK, HexItems.SPELLBOOK::getVariant);
//        registerVariantOverrides(HexItems.ANCIENT_CYPHER, HexItems.ANCIENT_CYPHER::getVariant);
//        registerVariantOverrides(HexItems.CYPHER, HexItems.CYPHER::getVariant);
//        registerVariantOverrides(HexItems.TRINKET, HexItems.TRINKET::getVariant);
//        registerVariantOverrides(HexItems.ARTIFACT, HexItems.ARTIFACT::getVariant);
//        IClientXplatAbstractions.INSTANCE.registerItemProperty(HexItems.THOUGHT_KNOT, ItemThoughtKnot.WRITTEN_PRED,
//            (stack, level, holder, holderID) -> {
//                if (stack.has(HexDataComponents.IOTA_HOLDER_IOTA)) {
//                    return 1;
//                } else {
//                    return 0;
//                }
//            });

//        registerPackagedSpellOverrides(HexItems.ANCIENT_CYPHER);
//        registerPackagedSpellOverrides(HexItems.CYPHER);
//        registerPackagedSpellOverrides(HexItems.TRINKET);
//        registerPackagedSpellOverrides(HexItems.ARTIFACT);

//        x.registerItemProperty(HexItems.BATTERY, ItemMediaBattery.MEDIA_PREDICATE,
//            (stack, level, holder, holderID) -> {
//                var item = (MediaHolderItem) stack.getItem();
//                return item.getMediaFullness(stack);
//            });
//        x.registerItemProperty(HexItems.BATTERY, ItemMediaBattery.MAX_MEDIA_PREDICATE,
//            (stack, level, holder, holderID) -> {
//                var item = (ItemMediaBattery) stack.getItem();
//                var max = item.getMaxMedia(stack);
//                return 1.049658f * (float) Math.log((float) max / MediaConstants.CRYSTAL_UNIT + 9.06152f) - 2.1436f;
//            });

//        registerScrollOverrides(HexItems.SCROLL_SMOL);
//        registerScrollOverrides(HexItems.SCROLL_MEDIUM);
//        registerScrollOverrides(HexItems.SCROLL_LARGE);

//        x.registerItemProperty(HexItems.SLATE, ItemSlate.WRITTEN_PRED,
//            (stack, level, holder, holderID) -> ItemSlate.hasPattern(stack) ? 1f : 0f);

//        registerWandOverrides(HexItems.STAFF_OAK);
//        registerWandOverrides(HexItems.STAFF_BIRCH);
//        registerWandOverrides(HexItems.STAFF_SPRUCE);
//        registerWandOverrides(HexItems.STAFF_JUNGLE);
//        registerWandOverrides(HexItems.STAFF_DARK_OAK);
//        registerWandOverrides(HexItems.STAFF_ACACIA);
//        registerWandOverrides(HexItems.STAFF_EDIFIED);
        // purposely skip quenched
//        registerWandOverrides(HexItems.STAFF_MINDSPLICE);

//        registerGaslight4(HexItems.STAFF_QUENCHED);
//        registerGaslight4(HexBlocks.QUENCHED_ALLAY.asItem());
//        registerGaslight4(HexBlocks.QUENCHED_ALLAY_TILES.asItem());
//        registerGaslight4(HexBlocks.QUENCHED_ALLAY_BRICKS.asItem());
//        registerGaslight4(HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL.asItem());
//        registerGaslight4(HexItems.QUENCHED_SHARD);

        x.setRenderLayer(HexBlocks.CONJURED_LIGHT, class_1921.method_23581());
        x.setRenderLayer(HexBlocks.CONJURED_BLOCK, class_1921.method_23581());
        x.setRenderLayer(HexBlocks.EDIFIED_DOOR, class_1921.method_23581());
        x.setRenderLayer(HexBlocks.EDIFIED_TRAPDOOR, class_1921.method_23581());
        x.setRenderLayer(HexBlocks.AKASHIC_BOOKSHELF, class_1921.method_23581());
        x.setRenderLayer(HexBlocks.SCONCE, class_1921.method_23581());

        x.setRenderLayer(HexBlocks.AMETHYST_EDIFIED_LEAVES, class_1921.method_23579());
        x.setRenderLayer(HexBlocks.AVENTURINE_EDIFIED_LEAVES, class_1921.method_23579());
        x.setRenderLayer(HexBlocks.CITRINE_EDIFIED_LEAVES, class_1921.method_23579());

        x.setRenderLayer(HexBlocks.AKASHIC_RECORD, class_1921.method_23583());
        x.setRenderLayer(HexBlocks.QUENCHED_ALLAY, class_1921.method_23583());

        x.registerEntityRenderer(HexEntities.WALL_SCROLL, WallScrollRenderer::new);

//        for (var tex : ResourceLocation.fromNamespaceAndPath[]{
//                PatternTooltipComponent.PRISTINE_BG,
//                PatternTooltipComponent.ANCIENT_BG,
//                PatternTooltipComponent.SLATE_BG
//        }) {
//            Minecraft.getInstance().getTextureManager().bindForSetup(tex);
//        }

        ScryingLensOverlays.addScryingLensStuff();
    }

    @Deprecated
    private static void registerGaslight4(class_1792 item) {
//        IClientXplatAbstractions.INSTANCE.registerItemProperty(item,
//            GaslightingTracker.GASLIGHTING_PRED, (stack, level, holder, holderID) ->
//                Math.abs(GaslightingTracker.getGaslightingAmount() % 4));
    }

    public static void registerColorProviders(BiConsumer<class_322, class_2248> blockColorRegistry) {
        //BiConsumer<ItemColor, Item> itemColorRegistry { colorizer, item -> ColorProviderRegistry.ITEM.register(colorizer, item) },
        class_10402.field_55235.method_65325(modLoc("hex_tint"), IotaStorageColorizerTintSource.MAP_CODEC);
        //TODO: DO THIS COLORING PLS DON'T FORGET
        //AY AY, I DID IT
//-     This is now done in IotaStorageColorizerTintSource:
//        itemColorRegistry.accept(makeIotaStorageColorizer(HexItems.FOCUS::getColor), HexItems.FOCUS);
//        itemColorRegistry.accept(makeIotaStorageColorizer(HexItems.SPELLBOOK::getColor), HexItems.SPELLBOOK);
//        itemColorRegistry.accept(makeIotaStorageColorizer(HexItems.THOUGHT_KNOT::getColor), HexItems.THOUGHT_KNOT);

        blockColorRegistry.accept((bs, level, pos, idx) -> {
            if (!bs.method_11654(BlockAkashicBookshelf.HAS_BOOKS) || level == null || pos == null) {
                return 0xff_ffffff;
            }
            var tile = level.method_8321(pos);
            if (!(tile instanceof BlockEntityAkashicBookshelf beas)) {
                // this gets called for particles for some irritating reason
                return 0xff_ffffff;
            }
            var iota = beas.getIota();
            if (iota == null) {
                return 0xff_ffffff;
            }
            return iota.getType().color();
        }, HexBlocks.AKASHIC_BOOKSHELF);
    }

    /**
     * Helper function to colorize the layers of an item that stores an iota, in the manner of foci and spellbooks.
     * <br>
     * 0 = base; 1 = overlay
     */
//    public static ItemColor makeIotaStorageColorizer(ToIntFunction<ItemStack> getColor) {
//        return (stack, tintIndex) -> {
//            if (tintIndex == 1) {
//                return getColor.applyAsInt(stack);
//            }
//            return 0xff_ffffff;
//        };
//    }

    @Deprecated
    public static void registerSealableDataHolderOverrides(IotaHolderItem item, Predicate<class_1799> hasIota,
                                               Predicate<class_1799> isSealed) {
//        IClientXplatAbstractions.INSTANCE.registerItemProperty((Item) item, ItemFocus.OVERLAY_PRED,
//            (stack, level, holder, holderID) -> {
//                if (!hasIota.test(stack) && !stack.has(HexDataComponents.VISUAL_OVERRIDE)) {
//                    return 0;
//                }
//                if (!isSealed.test(stack)) {
//                    return 1;
//                }
//                return 2;
//            });
    }

    @Deprecated
    private static void registerVariantOverrides(VariantItem item, Function<class_1799, Integer> variant) {
//        IClientXplatAbstractions.INSTANCE.registerItemProperty((Item) item, ItemFocus.VARIANT_PRED,
//                (stack, level, holder, holderID) -> variant.apply(stack));
    }

    @Deprecated
    private static void registerScrollOverrides(ItemScroll scroll) {
//        IClientXplatAbstractions.INSTANCE.registerItemProperty(scroll, ItemScroll.ANCIENT_PREDICATE,
//            (stack, level, holder, holderID) -> stack.has(HexDataComponents.ACTION) ? 1f : 0f);
    }

    @Deprecated
    private static void registerPackagedSpellOverrides(ItemPackagedHex item) {
//        IClientXplatAbstractions.INSTANCE.registerItemProperty(item, ItemPackagedHex.HAS_PATTERNS_PRED,
//            (stack, level, holder, holderID) ->
//                item.hasHex(stack) ? 1f : 0f
//        );
    }

    @Deprecated
    private static void registerWandOverrides(ItemStaff item) {
//        IClientXplatAbstractions.INSTANCE.registerItemProperty(item, ItemStaff.FUNNY_LEVEL_PREDICATE,
//            (stack, level, holder, holderID) -> {
//                if (!stack.has(DataComponents.CUSTOM_NAME)) {
//                    return 0;
//                }
//                var name = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
//                if (name.contains("old")) {
//                    return 1f;
//                } else if (name.contains("cherry")) {
//                    return 2f;
//                } else {
//                    return 0f;
//                }
//            });
    }

    public static void registerBlockEntityRenderers(@NotNull BlockEntityRendererRegisterererer registerer) {
        registerer.registerBlockEntityRenderer(HexBlockEntities.SLATE_TILE, BlockEntitySlateRenderer::new);
        registerer.registerBlockEntityRenderer(HexBlockEntities.AKASHIC_BOOKSHELF_TILE,
            BlockEntityAkashicBookshelfRenderer::new);
        registerer.registerBlockEntityRenderer(HexBlockEntities.QUENCHED_ALLAY_TILE,
            BlockEntityQuenchedAllayRenderer::new);
        registerer.registerBlockEntityRenderer(HexBlockEntities.QUENCHED_ALLAY_TILES_TILE,
                BlockEntityQuenchedAllayRenderer::new);
        registerer.registerBlockEntityRenderer(HexBlockEntities.QUENCHED_ALLAY_BRICKS_TILE,
                BlockEntityQuenchedAllayRenderer::new);
        registerer.registerBlockEntityRenderer(HexBlockEntities.QUENCHED_ALLAY_BRICKS_SMALL_TILE,
                BlockEntityQuenchedAllayRenderer::new);
    }

    @FunctionalInterface
    public interface BlockEntityRendererRegisterererer {
        <T extends class_2586> void registerBlockEntityRenderer(class_2591<T> type,
            class_5614<? super T> berp);
    }

    public static void onModelRegister(class_3300 recMan, Consumer<class_1091> extraModels) {
        for (var type : QUENCHED_ALLAY_TYPES.entrySet()) {
            var blockLoc = class_7923.field_41175.method_10221(type.getKey());
            var locStart = "block/";
            if (type.getValue())
                locStart += "deco/";

            for (int i = 0; i < BlockQuenchedAllay.VARIANTS; i++) {
                extraModels.accept(new class_1091(modLoc( locStart + blockLoc.method_12832() + "_" + i), IClientXplatAbstractions.INSTANCE.getModelLocVariant()));
            }
        }
    }

    @FunctionalInterface
    public interface FabricModelContext {
        void add(class_2960 id);
    }

    public static void onModelRegister(FabricModelContext context) {
        for (var type : QUENCHED_ALLAY_TYPES.entrySet()) {
            var blockLoc = class_7923.field_41175.method_10221(type.getKey());
            var locStart = "block/";
            if (type.getValue())
                locStart += "deco/";

            for (int i = 0; i < BlockQuenchedAllay.VARIANTS; i++) {
                context.add(modLoc( locStart + blockLoc.method_12832() + "_" + i));
            }
        }
    }

    public static void onModelBake(Function<class_2960, class_1087> getter) {
        for (var type : QUENCHED_ALLAY_TYPES.entrySet()) {
            var blockLoc = class_7923.field_41175.method_10221(type.getKey());
            var locStart = "block/";
            if (type.getValue())
                locStart += "deco/";

            var list = new ArrayList<class_1087>();
            for (int i = 0; i < BlockQuenchedAllay.VARIANTS; i++) {
//                var variantLoc = new ModelResourceLocation(modLoc(locStart + blockLoc.getPath() + "_" + i), IClientXplatAbstractions.INSTANCE.getModelLocVariant());
                var model = getter.apply(modLoc(locStart + blockLoc.method_12832() + "_" + i));
                list.add(model);
            }
            QUENCHED_ALLAY_VARIANTS.put(blockLoc, list);
        }
    }
}
