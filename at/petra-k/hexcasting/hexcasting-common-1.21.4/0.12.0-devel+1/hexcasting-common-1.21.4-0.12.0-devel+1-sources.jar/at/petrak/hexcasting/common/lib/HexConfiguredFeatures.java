package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.HexAPI;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class HexConfiguredFeatures {
    public static final class_5321<class_2975<?, ?>> AMETHYST_EDIFIED_TREE = createKey("amethyst_edified_tree");
    public static final class_5321<class_2975<?, ?>> AVENTURINE_EDIFIED_TREE = createKey("aventurine_edified_tree");
    public static final class_5321<class_2975<?, ?>> CITRINE_EDIFIED_TREE = createKey("citrine_edified_tree");

    private static class_5321<class_2975<?, ?>> createKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, class_2960.method_60655(HexAPI.MOD_ID, name));
    }
}
