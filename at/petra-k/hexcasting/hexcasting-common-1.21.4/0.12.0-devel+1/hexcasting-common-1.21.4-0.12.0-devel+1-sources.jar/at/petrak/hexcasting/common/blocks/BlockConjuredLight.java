package at.petrak.hexcasting.common.blocks;

import net.minecraft.class_10225;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3218;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import net.minecraft.world.level.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.annotation.Nonnull;

public class BlockConjuredLight extends BlockConjured implements class_3737 {
    public static final class_2746 WATERLOGGED = class_2741.field_12508;
    private static final class_265 SHAPE = class_2248.method_9541(5.0D, 5.0D, 5.0D, 11.0D, 11.0D, 11.0D);

    public BlockConjuredLight(class_4970.class_2251 properties) {
        super(properties);
        this.method_9590(method_9564().method_11657(WATERLOGGED, false));
    }

    @Override
    protected void method_9515(@NotNull class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(WATERLOGGED);
    }

    @Override
    public boolean method_9579(class_2680 state) {
        return !state.method_11654(WATERLOGGED);
    }

    @Nonnull
    @Override
    public class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 pContext) {
        class_3610 fluidState = pContext.method_8045().method_8316(pContext.method_8037());
        return method_9564().method_11657(WATERLOGGED, fluidState.method_15767(class_3486.field_15517) && fluidState.method_15761() == 8);
    }

    @Override
    protected class_2680 method_9559(class_2680 state, class_4538 level, class_10225 tickAccess, class_2338 pos,
class_2350 facing, class_2338 facingPos, class_2680 facingState, class_5819 rand) {
            if (state.method_11654(WATERLOGGED)) {
                tickAccess.method_64312(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
            }
            return super.method_9559(state, level, tickAccess, pos, facing, facingPos, facingState, rand);
    }

    @Override
    public @NotNull class_265 method_9530(@NotNull class_2680 state, @NotNull class_1922 level, @NotNull class_2338 pos,
        @NotNull class_3726 context) {
        return SHAPE;
    }

    @Override
    public void method_9591(class_1937 pLevel, @NotNull class_2338 pPos, @NotNull class_2680 pState, @NotNull class_1297 pEntity) {
        // NO-OP
    }

    @Override
    public boolean addLandingEffects(class_2680 state, class_3218 worldserver, class_2338 pos,
        class_1309 entity, int numberOfParticles) {
        return true;
    }
}

