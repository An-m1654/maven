package at.petrak.hexcasting.client.render.shader;

import com.mojang.datafixers.util.Pair;
import java.io.IOException;
import java.util.function.Consumer;
import net.minecraft.class_10149;
import net.minecraft.class_10156;
import net.minecraft.class_290;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

// https://github.com/VazkiiMods/Botania/blob/3a43accc2fbc439c9f2f00a698f8f8ad017503db/Common/src/main/java/vazkii/botania/client/core/helper/CoreShaders.java
public class HexShaders {
    private static final class_10156 grayscale = new class_10156(
            modLoc("core/hexcasting__grayscale"),
            class_290.field_1580,
            class_10149.field_53930
    );

    public static class_10156 grayscale() {
        return grayscale;
    }
}
