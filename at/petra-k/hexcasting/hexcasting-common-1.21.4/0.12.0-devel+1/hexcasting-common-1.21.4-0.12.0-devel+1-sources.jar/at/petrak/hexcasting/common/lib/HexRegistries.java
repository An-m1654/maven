package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.arithmetic.Arithmetic;
import at.petrak.hexcasting.api.casting.castables.SpecialHandler;
import at.petrak.hexcasting.api.casting.eval.sideeffects.EvalSound;
import at.petrak.hexcasting.api.casting.eval.vm.ContinuationFrame;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.BrainsweepeeIngredientType;
import at.petrak.hexcasting.common.recipe.ingredient.state.StateIngredientType;
import net.minecraft.class_2378;
import net.minecraft.class_5321;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexRegistries {
    public static final class_5321<class_2378<ActionRegistryEntry>> ACTION = class_5321.method_29180(modLoc("action"));
    public static final class_5321<class_2378<SpecialHandler.Factory<?>>> SPECIAL_HANDLER = class_5321.method_29180(modLoc("special_handler"));
    public static final class_5321<class_2378<IotaType<?>>> IOTA_TYPE = class_5321.method_29180(modLoc("iota_type"));
    public static final class_5321<class_2378<Arithmetic>> ARITHMETIC = class_5321.method_29180(modLoc("arithmetic"));
    public static final class_5321<class_2378<ContinuationFrame.Type<?>>> CONTINUATION_TYPE = class_5321.method_29180(modLoc("continuation_type"));
    public static final class_5321<class_2378<EvalSound>> EVAL_SOUND = class_5321.method_29180(modLoc("eval_sound"));
    public static final class_5321<class_2378<StateIngredientType<?>>> STATE_INGREDIENT = class_5321.method_29180(modLoc("state_ingredient"));
    public static final class_5321<class_2378<BrainsweepeeIngredientType<?>>> BRAINSWEEPEE_INGREDIENT = class_5321.method_29180(modLoc("brainsweepee_ingredient"));
}
