package at.petrak.hexcasting.api.casting.math

import at.petrak.hexcasting.api.utils.coordToPx
import at.petrak.hexcasting.api.utils.findCenter
import com.mojang.serialization.Codec
import com.mojang.serialization.DataResult
import com.mojang.serialization.codecs.RecordCodecBuilder
import net.minecraft.network.RegistryFriendlyByteBuf
import net.minecraft.network.codec.ByteBufCodecs
import net.minecraft.network.codec.StreamCodec
import net.minecraft.world.phys.Vec2

/**
 * Sequence of angles to define a pattern traced.
 */
data class HexPattern(val startDir: HexDir, val angles: MutableList<HexAngle> = arrayListOf()) {
    /**
     * @return True if it successfully appended, false if not.
     */
    fun tryAppendDir(newDir: HexDir): Boolean {
        // Two restrictions:
        // - No adding a pos/dir pair we previously added
        // - No backtracking
        val linesSeen = mutableSetOf<Pair<HexCoord, HexDir>>()

        var compass = this.startDir
        var cursor = HexCoord.Origin
        for (a in this.angles) {
            linesSeen.add(cursor to compass)
            // Line from here to there also blocks there to here
            linesSeen.add(cursor + compass to compass.rotatedBy(HexAngle.BACK))
            cursor += compass
            compass *= a
        }
        cursor += compass

        val potentialNewLine = cursor to newDir
        if (potentialNewLine in linesSeen) return false
        val nextAngle = newDir - compass
        if (nextAngle == HexAngle.BACK) return false

        this.angles.add(nextAngle)
        return true
    }

    @JvmOverloads
    fun positions(start: HexCoord = HexCoord.Origin): List<HexCoord> {
        val out: ArrayList<HexCoord> = ArrayList(this.angles.size + 2)
        out.add(start)
        var compass: HexDir = this.startDir
        var cursor = start
        for (a in this.angles) {
            cursor += compass
            out.add(cursor)
            compass *= a
        }
        out.add(cursor + compass)
        return out
    }

    fun directions(): List<HexDir> {
        val out = ArrayList<HexDir>(this.angles.size + 1)
        out.add(this.startDir)

        var compass: HexDir = this.startDir
        for (a in this.angles) {
            compass *= a
            out.add(compass)
        }
        return out
    }

    fun finalDir(): HexDir =
        this.angles.fold(this.startDir) { acc, angle -> acc * angle }

    // Terrible shorthand method for easy matching
    fun anglesSignature(): String {
        return buildString {
            for (a in this@HexPattern.angles) {
                append(
                    when (a) {
                        HexAngle.FORWARD -> "w"
                        HexAngle.RIGHT -> "e"
                        HexAngle.RIGHT_BACK -> "d"
                        HexAngle.BACK -> "s"
                        HexAngle.LEFT_BACK -> "a"
                        HexAngle.LEFT -> "q"
                    }
                )
            }
        }
    }

    /**
     * Return the "center of mass" of the pattern.
     * Drawing the pattern with the returned vector as the origin will center the pattern around it.
     */
    @JvmOverloads
    fun getCenter(hexRadius: Float, origin: HexCoord = HexCoord.Origin): Vec2 {
        val originPx = coordToPx(origin, hexRadius, Vec2.ZERO)
        val points = this.toLines(hexRadius, originPx)
        return findCenter(points)
    }


    /**
     * Convert a hex pattern into a sequence of straight linePoints spanning its points.
     */
    fun toLines(hexSize: Float, origin: Vec2): List<Vec2> =
        this.positions().map { coordToPx(it, hexSize, origin) }

    fun sigsEqual(that: HexPattern) = this.angles == that.angles

    override fun toString(): String = buildString {
        append("HexPattern[")
        append(this@HexPattern.startDir)
        append(", ")
        append(this@HexPattern.anglesSignature())
        append("]")
    }

    data class RawHexPattern(val anglesSignature: String, val startDir: String)

    companion object {
        const val TAG_START_DIR = "start_dir"
        const val TAG_ANGLES = "angles"

        @JvmField
        val CODEC: Codec<HexPattern> = RecordCodecBuilder.create { instance ->
            instance.group(
                Codec.STRING.fieldOf(TAG_ANGLES).forGetter(RawHexPattern::anglesSignature),
                Codec.STRING.fieldOf(TAG_START_DIR).forGetter(RawHexPattern::startDir)
            ).apply(instance, ::RawHexPattern)
        }.flatXmap({
            val dir = HexDir.fromString(it.startDir)
            try {
                return@flatXmap DataResult.success(fromAnglesUnchecked(it.anglesSignature, dir))
            } catch (exception: IllegalArgumentException) {
                return@flatXmap DataResult.error { exception.message }
            }
        }, { DataResult.success(RawHexPattern(it.anglesSignature(), it.startDir.name)) })

        @JvmField
        val STREAM_CODEC: StreamCodec<RegistryFriendlyByteBuf, HexPattern> = StreamCodec.composite(
            ByteBufCodecs.STRING_UTF8, HexPattern::anglesSignature,
            HexDir.STREAM_CODEC, HexPattern::startDir,
            HexPattern::fromAngles
        )

        /**
         * Construct a [HexPattern] from an angle signature and starting direction.
         *
         * Throws if the signature contains an invalid character, or if the resulting pattern would contain overlaps.
         */
        @JvmStatic
        @Throws(IllegalArgumentException::class, IllegalStateException::class)
        fun fromAngles(signature: String, startDir: HexDir): HexPattern {
            val out = HexPattern(startDir)

            var cursor = HexCoord.Origin
            var compass = startDir
            val linesSeen = mutableSetOf(
                cursor to compass,
                cursor + compass to compass.rotatedBy(HexAngle.BACK),
            )

            for ((idx, c) in signature.withIndex()) {
                val angle = HexAngle.fromChar(c)
                    ?: throw IllegalArgumentException("Cannot match $c at idx $idx to a direction")

                cursor += compass
                compass *= angle

                if (
                    !linesSeen.add(cursor to compass)
                    // Line from here to there also blocks there to here
                    || !linesSeen.add(cursor + compass to compass.rotatedBy(HexAngle.BACK))
                ) {
                    throw IllegalStateException("Adding the angle $c at index $idx made the pattern invalid by looping back on itself")
                }

                out.angles.add(angle)
            }

            return out
        }

        /**
         * Construct a [HexPattern] from an angle signature and starting direction, without checking for overlaps.
         *
         * Throws if the signature contains an invalid character.
         */
        @JvmStatic
        @Throws(IllegalArgumentException::class)
        fun fromAnglesUnchecked(signature: String, startDir: HexDir): HexPattern {
            val out = HexPattern(startDir)

            for ((idx, c) in signature.withIndex()) {
                val angle = HexAngle.fromChar(c)
                    ?: throw IllegalArgumentException("Cannot match $c at idx $idx to a direction")
                out.angles.add(angle)
            }

            return out
        }
    }
}
