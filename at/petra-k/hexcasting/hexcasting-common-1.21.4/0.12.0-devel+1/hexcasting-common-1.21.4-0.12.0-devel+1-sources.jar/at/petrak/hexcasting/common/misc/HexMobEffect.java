package at.petrak.hexcasting.common.misc;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

/**
 * Dodge protected ctor
 */
public class HexMobEffect extends class_1291 {
    public HexMobEffect(class_4081 category, int color) {
        super(category, color);
    }
}
