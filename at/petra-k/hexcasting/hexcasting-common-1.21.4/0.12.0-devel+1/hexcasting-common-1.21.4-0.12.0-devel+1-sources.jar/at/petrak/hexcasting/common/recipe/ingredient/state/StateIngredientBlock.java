package at.petrak.hexcasting.common.recipe.ingredient.state;

import at.petrak.hexcasting.common.lib.HexStateIngredients;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class StateIngredientBlock implements StateIngredient {
    private final class_2248 block;

    public StateIngredientBlock(class_2248 block) {
        this.block = block;
    }

    @Override
    public StateIngredientType<?> getType() {
        return HexStateIngredients.BLOCK_TYPE;
    }

    @Override
    public boolean test(class_2680 blockState) {
        return block == blockState.method_26204();
    }

    @Override
    public class_2680 pick(Random random) {
        return block.method_9564();
    }

    @Override
    public List<class_1799> getDisplayedStacks() {
        if (block.method_8389() == class_1802.field_8162) {
            return Collections.emptyList();
        }
        return Collections.singletonList(new class_1799(block));
    }

    @Override
    public List<class_2680> getDisplayed() {
        return Collections.singletonList(block.method_9564());
    }

    public class_2248 getBlock() {
        return block;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        return block == ((StateIngredientBlock) o).block;
    }

    @Override
    public int hashCode() {
        return block.hashCode();
    }

    @Override
    public String toString() {
        return "StateIngredientBlock{" + block + "}";
    }


    public static class Type implements StateIngredientType<StateIngredientBlock> {
        public static final MapCodec<StateIngredientBlock> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                class_7923.field_41175.method_39673().fieldOf("block").forGetter(StateIngredientBlock::getBlock)
        ).apply(instance, StateIngredientBlock::new));
        public static final class_9139<class_9129, StateIngredientBlock> STREAM_CODEC = class_9139.method_56434(
                class_9135.method_56365(class_7924.field_41254), StateIngredientBlock::getBlock,
                StateIngredientBlock::new
        );

        @Override
        public MapCodec<StateIngredientBlock> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, StateIngredientBlock> streamCodec() {
            return STREAM_CODEC;
        }
    }
}