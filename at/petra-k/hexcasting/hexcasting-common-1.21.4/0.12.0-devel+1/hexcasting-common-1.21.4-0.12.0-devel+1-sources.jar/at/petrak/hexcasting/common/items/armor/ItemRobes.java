package at.petrak.hexcasting.common.items.armor;

import at.petrak.hexcasting.api.HexAPI;
import net.minecraft.class_1738;
import net.minecraft.class_8051;

/**
 * To get the armor model in;
 * On forge: cursed self-mixin
 * On fabric: hook in ClientInit
 */
public class ItemRobes extends class_1738 {
    public final class_8051 type;

    public ItemRobes(class_8051 type, class_1793 properties) {
        super(HexAPI.instance().robesMaterial(), type, properties);
        this.type = type;
    }
}
