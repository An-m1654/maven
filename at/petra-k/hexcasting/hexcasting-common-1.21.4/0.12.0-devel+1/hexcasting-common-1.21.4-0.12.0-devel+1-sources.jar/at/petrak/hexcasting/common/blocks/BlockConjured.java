package at.petrak.hexcasting.common.blocks;

import at.petrak.hexcasting.annotations.SoftImplement;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.common.blocks.entity.BlockEntityConjured;
import at.petrak.hexcasting.xplat.IForgeLikeBlock;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3726;
import net.minecraft.class_5558;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class BlockConjured extends class_2248 implements class_2343, IForgeLikeBlock {

    public BlockConjured(class_2251 properties) {
        super(properties);
    }

    @Override
    public class_2680 method_9576(class_1937 pLevel, class_2338 pPos, class_2680 pState, class_1657 pPlayer) {
        var res = super.method_9576(pLevel, pPos, pState, pPlayer);
        // For some reason the block doesn't play breaking noises. So we fix that!
        pPlayer.method_5783(class_3417.field_26979, 1f, 1f);
        return res;
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 pLevel, class_2680 pState,
        class_2591<T> pBlockEntityType) {
        if (pLevel.method_8608()) {
            return BlockConjured::tick;
        } else {
            return null;
        }
    }

    private static <T extends class_2586> void tick(class_1937 level, class_2338 blockPos, class_2680 blockState, T t) {
        if (t instanceof BlockEntityConjured conjured) {
            conjured.particleEffect();
        }
    }

    @Override
    public void method_9591(class_1937 pLevel, @NotNull class_2338 pPos, @NotNull class_2680 pState, @NotNull class_1297 pEntity) {
        class_2586 tile = pLevel.method_8321(pPos);
        if (tile instanceof BlockEntityConjured bec) {
            bec.walkParticle(pEntity);
        }
    }

    @Nullable
    @Override
    public class_2586 method_10123(@NotNull class_2338 pPos, @NotNull class_2680 pState) {
        return new BlockEntityConjured(pPos, pState);
    }

    public static void setColor(class_1936 pLevel, class_2338 pPos, FrozenPigment colorizer) {
        class_2586 blockentity = pLevel.method_8321(pPos);
        if (blockentity instanceof BlockEntityConjured tile) {
            tile.setColorizer(colorizer);
        }
    }

    @Override
    public void method_9615(@NotNull class_2680 pState, class_1937 pLevel, @NotNull class_2338 pPos, @NotNull class_2680 pOldState,
        boolean pIsMoving) {
        pLevel.method_8413(pPos, pState, pState, class_2248.field_31028);
        super.method_9615(pState, pLevel, pPos, pOldState, pIsMoving);
    }

    @Override
    public boolean method_9579(@NotNull class_2680 pState) {
        return true;
    }

    @Override
    public @NotNull class_265 method_26159(class_2680 pState, class_1922 pLevel, class_2338 pPos,
        class_3726 pContext) {
        return class_259.method_1073();
    }

    @Override
    public float method_9575(class_2680 pState, class_1922 pLevel, class_2338 pPos) {
        return 1.0F;
    }

    @Override
    public @NotNull class_2464 method_9604(@NotNull class_2680 state) {
        return class_2464.field_11455;
    }

    @Override
    protected void method_33614(class_1937 pLevel, class_1657 pPlayer, class_2338 pPos, class_2680 pState) {
        // NO-OP
    }


    @SoftImplement("forge")
    public boolean addLandingEffects(class_2680 state1, class_3218 worldserver, class_2338 pos, class_2680 state2,
        class_1309 entity, int numberOfParticles) {
        return addLandingEffects(state1, worldserver, pos, entity, numberOfParticles);
    }

    @Override
    public boolean addLandingEffects(class_2680 state, class_3218 worldserver, class_2338 pos,
        class_1309 entity, int numberOfParticles) {
        class_2586 tile = worldserver.method_8321(pos);
        if (tile instanceof BlockEntityConjured bec) {
            bec.landParticle(entity, numberOfParticles);
        }
        return true;
    }
}

