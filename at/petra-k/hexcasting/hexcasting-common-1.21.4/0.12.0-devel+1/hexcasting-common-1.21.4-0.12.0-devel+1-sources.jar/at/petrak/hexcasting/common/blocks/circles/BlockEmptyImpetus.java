package at.petrak.hexcasting.common.blocks.circles;

import at.petrak.hexcasting.api.block.circle.BlockCircleComponent;
import at.petrak.hexcasting.api.casting.eval.env.CircleCastEnv;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_3218;

// As it turns out, not actually an impetus
public class BlockEmptyImpetus extends BlockCircleComponent {
    public static final class_2754<class_2350> FACING = class_2741.field_12525;

    public BlockEmptyImpetus(class_2251 p_49795_) {
        super(p_49795_);
        this.method_9590(this.field_10647.method_11664()
            .method_11657(ENERGIZED, false).method_11657(FACING, class_2350.field_11043));
    }

    @Override
    public ControlFlow acceptControlFlow(CastingImage imageIn, CircleCastEnv env, class_2350 enterDir, class_2338 pos,
        class_2680 bs, class_3218 world) {
        return new ControlFlow.Continue(imageIn, List.of(this.exitPositionFromDirection(pos, bs.method_11654(FACING))));
    }

    @Override
    public boolean canEnterFromDirection(class_2350 enterDir, class_2338 pos, class_2680 bs, class_3218 world) {
        return enterDir != bs.method_11654(FACING).method_10153();
    }

    @Override
    public EnumSet<class_2350> possibleExitDirections(class_2338 pos, class_2680 bs, class_1937 world) {
        return EnumSet.of(bs.method_11654(FACING));
    }

    @Override
    public class_2350 normalDir(class_2338 pos, class_2680 bs, class_1937 world, int recursionLeft) {
        return normalDirOfOther(pos.method_10093(bs.method_11654(FACING)), world, recursionLeft);
    }

    @Override
    public float particleHeight(class_2338 pos, class_2680 bs, class_1937 world) {
        return 0.5f;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(FACING);
    }

    @Override
    public class_2680 method_9605(class_1750 pContext) {
        return BlockCircleComponent.placeStateDirAndSneak(this.method_9564(), pContext);
    }

    @Override
    public class_2680 method_9598(class_2680 pState, class_2470 pRot) {
        return pState.method_11657(FACING, pRot.method_10503(pState.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 pState, class_2415 pMirror) {
        return pState.method_26186(pMirror.method_10345(pState.method_11654(FACING)));
    }
}
