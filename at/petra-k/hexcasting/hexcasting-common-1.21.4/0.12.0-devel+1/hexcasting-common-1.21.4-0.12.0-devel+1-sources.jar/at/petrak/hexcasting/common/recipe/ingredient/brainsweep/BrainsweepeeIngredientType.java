package at.petrak.hexcasting.common.recipe.ingredient.brainsweep;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public interface BrainsweepeeIngredientType<T extends BrainsweepeeIngredient> {

    MapCodec<T> codec();

    class_9139<class_9129, T> streamCodec();
}
