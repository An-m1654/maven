package at.petrak.hexcasting.api.casting.eval.env;

import at.petrak.hexcasting.api.casting.eval.MishapEnvironment;
import at.petrak.hexcasting.api.casting.mishaps.Mishap;
import at.petrak.hexcasting.common.lib.HexDamageTypes;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3222;

public class PlayerBasedMishapEnv extends MishapEnvironment {
    public PlayerBasedMishapEnv(class_3222 player) {
        super(player.method_51469(), player);
    }

    @Override
    public void yeetHeldItemsTowards(class_243 targetPos) {
        var pos = this.caster.method_19538();
        var delta = targetPos.method_1020(pos).method_1029().method_1021(0.5);

        for (var hand : class_1268.values()) {
            var stack = this.caster.method_5998(hand);
            this.caster.method_6122(hand, class_1799.field_8037);
            this.yeetItem(stack, pos, delta);
        }
    }

    @Override
    public void dropHeldItems() {
        var delta = this.caster.method_5720();
        this.yeetHeldItemsTowards(this.caster.method_19538().method_1019(delta));
    }

    @Override
    public void damage(float healthProportion) {
        Mishap.trulyHurt(this.caster, this.caster.method_48923().method_48795(HexDamageTypes.OVERCAST), this.caster.method_6032() * healthProportion);
    }

    @Override
    public void drown() {
        if (this.caster.method_5669() < 200) {
            this.caster.method_64419(this.caster.method_48923().method_48824(), 2f);
        }
        this.caster.method_5855(0);
    }

    @Override
    public void removeXp(int amount) {
        this.caster.method_7255(-amount);
    }

    @Override
    public void blind(int ticks) {
        this.caster.method_6092(new class_1293(class_1294.field_5919, ticks));
    }

    @Override
    public void nauseate(int ticks) {
        this.caster.method_6092(new class_1293(class_1294.field_5916, ticks));
    }
}
