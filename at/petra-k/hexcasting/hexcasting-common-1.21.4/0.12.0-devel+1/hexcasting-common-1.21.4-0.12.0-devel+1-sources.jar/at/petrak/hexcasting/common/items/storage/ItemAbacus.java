package at.petrak.hexcasting.common.items.storage;

import at.petrak.hexcasting.api.casting.iota.DoubleIota;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.item.IotaHolderItem;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.lib.HexSounds;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class ItemAbacus extends class_1792 implements IotaHolderItem {

    public ItemAbacus(class_1793 pProperties) {
        super(pProperties);
    }

    @Override
    public @Nullable Iota readIota(class_1799 stack) {
        return new DoubleIota(stack.method_57825(HexDataComponents.ABACUS_VALUE, 0.0));
    }

    @Override
    public boolean writeable(class_1799 stack) {
        return false;
    }

    @Override
    public boolean canWrite(class_1799 stack, Iota datum) {
        return false;
    }

    @Override
    public void writeDatum(class_1799 stack, Iota datum) {
        // nope
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        var stack = player.method_5998(hand);
        if (player.method_5715()) {
            Double oldNum = stack.method_57824(HexDataComponents.ABACUS_VALUE);
            stack.method_57381(HexDataComponents.ABACUS_VALUE);

            player.method_5783(HexSounds.ABACUS_SHAKE, 1f, 1f);

            var key = "hexcasting.tooltip.abacus.reset";
            if (oldNum != null && oldNum == 69) {
                key += ".nice";
            }
            player.method_7353(class_2561.method_43471(key), true);

            return world.field_9236 ? class_1269.field_5812 : class_1269.field_21466;
        } else {
            return class_1269.field_5811;
        }
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        IotaHolderItem.appendHoverText(this, stack, tooltipComponents, tooltipFlag);
    }
}
