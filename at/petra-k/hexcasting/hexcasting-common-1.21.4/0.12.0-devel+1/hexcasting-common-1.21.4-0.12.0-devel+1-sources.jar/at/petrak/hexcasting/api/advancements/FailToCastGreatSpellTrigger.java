package at.petrak.hexcasting.api.advancements;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.class_2048;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;

public class FailToCastGreatSpellTrigger extends class_4558<FailToCastGreatSpellTrigger.Instance> {
    private static final class_2960 ID = class_2960.method_60655("hexcasting", "fail_to_cast_great_spell");

    @Override
    public Codec<Instance> method_54937() {
        return Instance.CODEC;
    }

    public void trigger(class_3222 player) {
        super.method_22510(player, e -> true);
    }

    public static record Instance(Optional<class_5258> player) implements class_4558.class_8788 {
        public static final Codec<FailToCastGreatSpellTrigger.Instance> CODEC = RecordCodecBuilder.create(
                triggerInstance -> triggerInstance.group(
                                class_2048.field_47250.optionalFieldOf("player").forGetter(FailToCastGreatSpellTrigger.Instance::comp_2029)
                        )
                        .apply(triggerInstance, FailToCastGreatSpellTrigger.Instance::new)
        );

        @Override
        public Optional<class_5258> comp_2029() {
            return player;
        }
    }
}
