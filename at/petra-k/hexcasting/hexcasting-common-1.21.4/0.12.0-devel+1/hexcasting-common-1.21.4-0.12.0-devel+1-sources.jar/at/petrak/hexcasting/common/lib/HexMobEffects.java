package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.misc.HexMobEffect;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import net.minecraft.class_1291;
import net.minecraft.class_1322;
import net.minecraft.class_4081;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

public class HexMobEffects {

    private static final IXplatRegister<class_1291> REGISTER = IXplatAbstractions.INSTANCE
            .createRegistar(class_7924.field_41208);

    public static void register() {
        REGISTER.registerAll();
    }

    public static final class_6880<class_1291> ENLARGE_GRID = REGISTER.registerHolder("enlarge_grid",
            () ->  new HexMobEffect(class_4081.field_18271, 0xc875ff).method_5566(HexAttributes.GRID_ZOOM, HexAPI.modLoc("enlarge_grid"),
                    0.25, class_1322.class_1323.field_6331));
    public static final class_6880<class_1291> SHRINK_GRID = REGISTER.registerHolder("shrink_grid",
            () -> new HexMobEffect(class_4081.field_18272, 0xc0e660).method_5566(HexAttributes.GRID_ZOOM, HexAPI.modLoc("shrink_grid"),
                -0.2, class_1322.class_1323.field_6331));
}
