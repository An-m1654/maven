package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.items.ItemJewelerHammer;
import at.petrak.hexcasting.common.items.ItemLens;
import at.petrak.hexcasting.common.items.ItemLoreFragment;
import at.petrak.hexcasting.common.items.ItemStaff;
import at.petrak.hexcasting.common.items.magic.*;
import at.petrak.hexcasting.common.items.pigment.*;
import at.petrak.hexcasting.common.items.storage.*;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.google.common.base.Suppliers;
import net.minecraft.class_1304;
import net.minecraft.class_156;
import net.minecraft.class_1761;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9886;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

// https://github.com/VazkiiMods/Botania/blob/2c4f7fdf9ebf0c0afa1406dfe1322841133d75fa/Common/src/main/java/vazkii/botania/common/item/ModItems.java
public class HexItems {
    public static void registerItems(BiConsumer<class_1792, class_2960> r) {
        for (var e : ITEMS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    public static void registerItemCreativeTab(class_1761.class_7704 r, class_1761 tab) {
        if (tab == HexCreativeTabs.SCROLLS)
            generateScrollEntries(r);
        for (var item : ITEM_TABS.getOrDefault(tab, Collections.emptyList())) {
            item.register(r);
        }
    }

    private static final Map<class_2960, class_1792> ITEMS = new LinkedHashMap<>(); // preserve insertion order
    private static final Map<class_1761, List<TabEntry>> ITEM_TABS = new LinkedHashMap<>();

    public static final class_1792 AMETHYST_DUST = make("amethyst_dust", new class_1792(props().method_63686(getId("amethyst_dust"))));
    public static final class_1792 CHARGED_AMETHYST = make("charged_amethyst", new class_1792(props().method_63686(getId("charged_amethyst"))));

    public static final class_1792 QUENCHED_SHARD = make("quenched_allay_shard", new class_1792(props().method_7894(class_1814.field_8907).method_63686(getId("quenched_allay_shard"))));

    public static final ItemStaff STAFF_OAK = make("staff/oak", new ItemStaff(unstackable().method_63686(getId("staff/oak"))));
    public static final ItemStaff STAFF_SPRUCE = make("staff/spruce", new ItemStaff(unstackable().method_63686(getId("staff/spruce"))));
    public static final ItemStaff STAFF_BIRCH = make("staff/birch", new ItemStaff(unstackable().method_63686(getId("staff/birch"))));
    public static final ItemStaff STAFF_JUNGLE = make("staff/jungle", new ItemStaff(unstackable().method_63686(getId("staff/jungle"))));
    public static final ItemStaff STAFF_ACACIA = make("staff/acacia", new ItemStaff(unstackable().method_63686(getId("staff/acacia"))));
    public static final ItemStaff STAFF_DARK_OAK = make("staff/dark_oak", new ItemStaff(unstackable().method_63686(getId("staff/dark_oak"))));
    public static final ItemStaff STAFF_CRIMSON = make("staff/crimson", new ItemStaff(unstackable().method_63686(getId("staff/crimson"))));
    public static final ItemStaff STAFF_WARPED = make("staff/warped", new ItemStaff(unstackable().method_63686(getId("staff/warped"))));
    public static final ItemStaff STAFF_MANGROVE = make("staff/mangrove", new ItemStaff(unstackable().method_63686(getId("staff/mangrove"))));
    public static final ItemStaff STAFF_CHERRY = make("staff/cherry", new ItemStaff(unstackable().method_63686(getId("staff/cherry"))));
    public static final ItemStaff STAFF_BAMBOO = make("staff/bamboo", new ItemStaff(unstackable().method_63686(getId("staff/bamboo"))));
    public static final ItemStaff STAFF_EDIFIED = make("staff/edified", new ItemStaff(unstackable().method_63686(getId("staff/edified"))));
    public static final ItemStaff STAFF_QUENCHED = make("staff/quenched", new ItemStaff(unstackable().method_7894(class_1814.field_8907).method_63686(getId("staff/quenched"))));
    // mindsplice staffaratus
    public static final ItemStaff STAFF_MINDSPLICE = make("staff/mindsplice", new ItemStaff(unstackable().method_7894(class_1814.field_8907).method_63686(getId("staff/mindsplice"))));

    public static final ItemLens SCRYING_LENS = make("lens", new ItemLens(
            IXplatAbstractions.INSTANCE.addEquipSlotsFabric(class_1304.field_6169)
                    .method_7889(1)
                    .method_57348(ItemLens.MODIFIERS)
                    .method_63686(getId("lens"))
    ));

    public static final ItemAbacus ABACUS = make("abacus", new ItemAbacus(unstackable().method_63686(getId("abacus"))));
    public static final ItemThoughtKnot THOUGHT_KNOT = make("thought_knot", new ItemThoughtKnot(unstackable().method_63686(getId("thought_knot"))));
    public static final ItemFocus FOCUS = make("focus", new ItemFocus(unstackable().method_63686(getId("focus"))));
    public static final ItemSpellbook SPELLBOOK = make("spellbook", new ItemSpellbook(unstackable().method_63686(getId("spellbook"))));

    public static final ItemCypher ANCIENT_CYPHER = make("ancient_cypher", new ItemAncientCypher(unstackable().method_63686(getId("ancient_cypher"))));
    public static final ItemCypher CYPHER = make("cypher", new ItemCypher(unstackable().method_63686(getId("cypher"))));
    public static final ItemTrinket TRINKET = make("trinket", new ItemTrinket(unstackable().method_7894(class_1814.field_8907).method_63686(getId("trinket"))));
    public static final ItemArtifact ARTIFACT = make("artifact", new ItemArtifact(unstackable().method_7894(class_1814.field_8903).method_63686(getId("artifact"))));

    public static final ItemJewelerHammer JEWELER_HAMMER = make("jeweler_hammer",
            new ItemJewelerHammer(class_9886.field_52587,
                    1f,
                    -2.8f,
                    props()
                            .method_7889(1)
                            .method_7895(class_9886.field_52588.comp_2931())
                            .method_63686(getId("jeweler_hammer"))
            )
    );

    public static final ItemScroll SCROLL_SMOL = make("scroll_small", new ItemScroll(props().method_63686(getId("scroll_small")), 1));
    public static final ItemScroll SCROLL_MEDIUM = make("scroll_medium", new ItemScroll(props().method_63686(getId("scroll_medium")), 2));
    public static final ItemScroll SCROLL_LARGE = make("scroll", new ItemScroll(props().method_63686(getId("scroll")), 3));

    public static final ItemSlate SLATE = make("slate", new ItemSlate(HexBlocks.SLATE, props().method_63686(getId("slate"))));

    public static final ItemMediaBattery BATTERY = make("battery",
            new ItemMediaBattery(unstackable().method_63686(getId("battery"))), null);

    public static final Supplier<class_1799> BATTERY_DUST_STACK = addToTab(() -> ItemMediaBattery.withMedia(
            new class_1799(HexItems.BATTERY),
            MediaConstants.DUST_UNIT * 64,
            MediaConstants.DUST_UNIT * 64), HexCreativeTabs.HEX);
    public static final Supplier<class_1799> BATTERY_SHARD_STACK = addToTab(() -> ItemMediaBattery.withMedia(
            new class_1799(HexItems.BATTERY),
            MediaConstants.SHARD_UNIT * 64,
            MediaConstants.SHARD_UNIT * 64), HexCreativeTabs.HEX);
    public static final Supplier<class_1799> BATTERY_CRYSTAL_STACK = addToTab(() -> ItemMediaBattery.withMedia(
            new class_1799(HexItems.BATTERY),
            MediaConstants.CRYSTAL_UNIT * 64,
            MediaConstants.CRYSTAL_UNIT * 64), HexCreativeTabs.HEX);
    public static final Supplier<class_1799> BATTERY_QUENCHED_SHARD_STACK = addToTab(() -> ItemMediaBattery.withMedia(
            new class_1799(HexItems.BATTERY),
            MediaConstants.QUENCHED_SHARD_UNIT * 64,
            MediaConstants.QUENCHED_SHARD_UNIT * 64), HexCreativeTabs.HEX);
    public static final Supplier<class_1799> BATTERY_QUENCHED_BLOCK_STACK = addToTab(() -> ItemMediaBattery.withMedia(
            new class_1799(HexItems.BATTERY),
            MediaConstants.QUENCHED_BLOCK_UNIT * 64,
            MediaConstants.QUENCHED_BLOCK_UNIT * 64), HexCreativeTabs.HEX);

    public static final EnumMap<class_1767, ItemDyePigment> DYE_PIGMENTS = class_156.method_656(() -> {
        var out = new EnumMap<class_1767, ItemDyePigment>(class_1767.class);
        for (var dye : class_1767.values()) {
            out.put(dye, make("dye_colorizer_" + dye.method_7792(), new ItemDyePigment(dye, unstackable().method_63686(getId("dye_colorizer_" + dye.method_7792())))));
        }
        return out;
    });
    public static final EnumMap<ItemPridePigment.Type, ItemPridePigment> PRIDE_PIGMENTS = class_156.method_656(() -> {
        var out = new EnumMap<ItemPridePigment.Type, ItemPridePigment>(ItemPridePigment.Type.class);
        for (var politicsInMyVidya : ItemPridePigment.Type.values()) {
            out.put(politicsInMyVidya, make("pride_colorizer_" + politicsInMyVidya.getName(),
                    new ItemPridePigment(politicsInMyVidya, unstackable().method_63686(getId("pride_colorizer_" + politicsInMyVidya.getName())))));
        }
        return out;
    });

    public static final class_1792 UUID_PIGMENT = make("uuid_colorizer", new ItemUUIDPigment(unstackable().method_63686(getId("uuid_colorizer"))));
    public static final class_1792 DEFAULT_PIGMENT = make("default_colorizer",
        new ItemAmethystPigment(unstackable().method_63686(getId("default_colorizer"))));
    public static final class_1792 ANCIENT_PIGMENT = make("ancient_colorizer",
        new ItemAmethystAndCopperPigment(unstackable().method_63686(getId("ancient_colorizer"))));

    // BUFF SANDVICH
    public static final class_1792 SUBMARINE_SANDWICH = make("sub_sandwich",
            new class_1792(props().method_19265(new class_4174.class_4175().method_19238(14).method_19237(1.2f).method_19242()).method_63686(getId("sub_sandwich"))));

    public static final ItemLoreFragment LORE_FRAGMENT = make("lore_fragment",
            new ItemLoreFragment(unstackable()
                    .method_7894(class_1814.field_8903).method_63686(getId("lore_fragment"))));

    public static final ItemCreativeUnlocker CREATIVE_UNLOCKER = make("creative_unlocker",
            new ItemCreativeUnlocker(unstackable()
                    .method_7894(class_1814.field_8904)
                    .method_19265(new class_4174.class_4175().method_19238(20).method_19237(1f).method_19240().method_19242()).method_63686(getId("creative_unlocker"))));

    //

    public static class_1792.class_1793 props() {
        return new class_1792.class_1793();
    }

    public static class_1792.class_1793 unstackable() {
        return props().method_7889(1);
    }

    private static void generateScrollEntries(class_1761.class_7704 r) {
        var keyList = new ArrayList<class_5321<ActionRegistryEntry>>();
        class_2378<ActionRegistryEntry> regi = IXplatAbstractions.INSTANCE.getActionRegistry();
        for (var key : regi.method_42021())
            if (HexUtils.isOfTag(regi, key, HexTags.Actions.PER_WORLD_PATTERN))
                keyList.add(key);
        keyList.sort(Comparator.comparing(class_5321::method_29177));
        for (var key : keyList) {
            r.method_45420(ItemScroll.withPerWorldPattern(
                    new class_1799(HexItems.SCROLL_LARGE),
                    key
            ));
        }
    }

    private static <T extends class_1792> T make(class_2960 id, T item, @Nullable class_1761 tab) {
        var old = ITEMS.put(id, item);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + id);
        }
        if (tab != null) {
            ITEM_TABS.computeIfAbsent(tab, t -> new ArrayList<>()).add(new TabEntry.ItemEntry(item));
        }
        return item;
    }

    private static <T extends class_1792> T make(String id, T item, @Nullable class_1761 tab) {
        return make(modLoc(id), item, tab);
    }

    private static <T extends class_1792> T make(String id, T item) {
        return make(modLoc(id), item, HexCreativeTabs.HEX);
    }

    private static Supplier<class_1799> addToTab(Supplier<class_1799> stack, class_1761 tab) {
        var memoised = Suppliers.memoize(stack::get);
        ITEM_TABS.computeIfAbsent(tab, t -> new ArrayList<>()).add(new TabEntry.StackEntry(memoised));
        return memoised;
    }
    private static class_5321<class_1792> getId(String name) {
        return class_5321.method_29179(class_7924.field_41197, modLoc(name));
    }

    private static abstract class TabEntry {
        abstract void register(class_1761.class_7704 r);

        static class ItemEntry extends TabEntry {
            private final class_1792 item;

            ItemEntry(class_1792 item) {
                this.item = item;
            }

            @Override
            void register(class_1761.class_7704 r) {
                r.method_45421(item);
            }
        }

        static class StackEntry extends TabEntry {
            private final Supplier<class_1799> stack;

            StackEntry(Supplier<class_1799> stack) {
                this.stack = stack;
            }

            @Override
            void register(class_1761.class_7704 r) {
                r.method_45420(stack.get());
            }
        }
    }
}
