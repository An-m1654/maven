package at.petrak.hexcasting.common.command;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.casting.PatternRegistryManifest;
import at.petrak.hexcasting.common.lib.HexRegistries;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_7079;

public class PatternResKeyArgument extends class_7079<ActionRegistryEntry> {
    private static final DynamicCommandExceptionType ERROR_UNKNOWN_PATTERN = new DynamicCommandExceptionType(
        (errorer) ->
            class_2561.method_43469("hexcasting.pattern.unknown", errorer)
    );

    public PatternResKeyArgument() {
        super(HexRegistries.ACTION);
    }

    public static PatternResKeyArgument id() {
        return new PatternResKeyArgument();
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        var suggestions = new ArrayList<String>();
        var registry = IXplatAbstractions.INSTANCE.getActionRegistry();
        for (var key : registry.method_42021()) {
            if (HexUtils.isOfTag(registry, key, HexTags.Actions.PER_WORLD_PATTERN)) {
                suggestions.add(key.method_29177().toString());
            }
        }

        return class_2172.method_9265(suggestions, builder);
    }

    public static <T> class_5321<T> getResourceKey(
            CommandContext<class_2168> context,
            String argumentName,
            class_5321<class_2378<T>> registryKey,
            DynamicCommandExceptionType exceptionType
    ) throws CommandSyntaxException {
        class_5321<?> key = context.getArgument(argumentName, class_5321.class);
        Optional<class_5321<T>> optional = key.method_39752(registryKey);
        return optional.orElseThrow(() -> exceptionType.create(key.method_29177()));
    }

    public static class_5321<ActionRegistryEntry> getPatternKey(
            CommandContext<class_2168> ctx, String argumentName) throws CommandSyntaxException {
        return getResourceKey(ctx, argumentName, HexRegistries.ACTION, ERROR_UNKNOWN_PATTERN);
    }

    public static HexPattern getPattern(
        CommandContext<class_2168> ctx, String argumentName) throws CommandSyntaxException {
        var targetKey = getPatternKey(ctx, argumentName);
        var foundPat = PatternRegistryManifest.getCanonicalStrokesPerWorld(targetKey, ctx.getSource().method_9211().method_30002());
        if (foundPat == null) {
            throw ERROR_UNKNOWN_PATTERN.create(targetKey.method_29177());
        } else {
            return foundPat;
        }
    }
}
