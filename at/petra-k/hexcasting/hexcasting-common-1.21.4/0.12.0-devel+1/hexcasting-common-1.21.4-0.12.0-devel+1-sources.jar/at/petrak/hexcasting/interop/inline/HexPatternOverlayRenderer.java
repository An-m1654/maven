package at.petrak.hexcasting.interop.inline;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.utils.NBTHelper;
import at.petrak.hexcasting.client.render.PatternColors;
import at.petrak.hexcasting.client.render.PatternRenderer;
import at.petrak.hexcasting.client.render.PatternSettings;
import at.petrak.hexcasting.client.render.RenderLib;
import at.petrak.hexcasting.common.items.storage.ItemScroll;
import at.petrak.hexcasting.common.items.storage.ItemSlate;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import com.samsthenerd.inline.api.client.extrahooks.ItemOverlayRenderer;
import java.util.function.Function;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_437;

@FunctionalInterface
public interface HexPatternOverlayRenderer extends ItemOverlayRenderer {
    HexPattern getPattern(class_1799 stack);

    HexPatternOverlayRenderer SCROLL_RENDERER = (stack) -> {
        var pattern = stack.method_57824(HexDataComponents.PATTERN);
        if (pattern != null && !stack.method_57826(HexDataComponents.NEEDS_PURCHASE)) {
            return pattern;
        }
        return null;
    };

    HexPatternOverlayRenderer SLATE_RENDERER = (stack) -> ItemSlate.getPattern(stack).orElse(null);

    PatternSettings OVERLAY_RENDER_SETTINGS = new PatternSettings("overlay",
        new PatternSettings.PositionSettings(14, 14, 0.5, 0.5,
            PatternSettings.AxisAlignment.CENTER_FIT, PatternSettings.AxisAlignment.CENTER_FIT, 4.0, 0, 0),
        PatternSettings.StrokeSettings.fromStroke(1.5),
        new PatternSettings.ZappySettings(10, 0, 0, 0,
            PatternSettings.ZappySettings.READABLE_OFFSET, 0.7f)
    );

    // higher contrast purple based on slate wobble color
    PatternColors HC_PURPLE_COLOR =
        new PatternColors(RenderLib.screenCol(0xff_cfa0f3), 0xff_763fa1);

    @Override
    default void render(class_1799 itemStack, class_332 guiGraphics) {
        if(!class_437.method_25442()) return;
        HexPattern pat = getPattern(itemStack);
        if(pat == null) return;
        var ps = guiGraphics.method_51448();
        ps.method_22903();
        ps.method_46416(1,1,100);
        PatternRenderer.renderPattern(pat, guiGraphics.method_51448(), OVERLAY_RENDER_SETTINGS, HC_PURPLE_COLOR, 0, 16);
        ps.method_22909();
    }
}
