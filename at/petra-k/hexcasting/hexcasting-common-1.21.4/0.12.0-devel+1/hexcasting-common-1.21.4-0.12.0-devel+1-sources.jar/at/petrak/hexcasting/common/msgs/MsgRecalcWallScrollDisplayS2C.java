package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.entities.EntityWallScroll;
import net.minecraft.class_310;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Sent S->C to have a wall scroll recalculate its pattern, to get readability offset.
 */
public record MsgRecalcWallScrollDisplayS2C(int entityId, boolean showStrokeOrder) implements class_8710 {
    public static final class_8710.class_9154<MsgRecalcWallScrollDisplayS2C> TYPE = new class_8710.class_9154<>(HexAPI.modLoc("redoscroll"));

    public static final class_9139<class_9129, MsgRecalcWallScrollDisplayS2C> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48550, MsgRecalcWallScrollDisplayS2C::entityId,
            class_9135.field_48547, MsgRecalcWallScrollDisplayS2C::showStrokeOrder,
            MsgRecalcWallScrollDisplayS2C::new
    );

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public void handle() {
        Handler.handle(this);
    }

    public static final class Handler {

        public static void handle(MsgRecalcWallScrollDisplayS2C msg) {
            class_310.method_1551().execute(() -> {
                var mc = class_310.method_1551();
                var entity = mc.field_1687.method_8469(msg.entityId);
                if (entity instanceof EntityWallScroll scroll
                        && scroll.getShowsStrokeOrder() != msg.showStrokeOrder) {
                    scroll.recalculateDisplay();
                }
            });
        }
    }
}
