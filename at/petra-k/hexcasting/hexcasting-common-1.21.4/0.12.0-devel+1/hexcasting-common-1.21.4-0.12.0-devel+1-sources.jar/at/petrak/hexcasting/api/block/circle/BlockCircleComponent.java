package at.petrak.hexcasting.api.block.circle;

import at.petrak.hexcasting.api.casting.circles.ICircleComponent;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3218;

// Convenience impl of ICircleComponent
public abstract class BlockCircleComponent extends class_2248 implements ICircleComponent {
    public static final class_2746 ENERGIZED = class_2746.method_11825("energized");

    public BlockCircleComponent(class_2251 p_49795_) {
        super(p_49795_);
    }

    @Override
    public class_2680 startEnergized(class_2338 pos, class_2680 bs, class_1937 world) {
        var newState = bs.method_11657(ENERGIZED, true);
        world.method_8501(pos, newState);

        return newState;
    }

    @Override
    public boolean isEnergized(class_2338 pos, class_2680 bs, class_1937 world) {
        return bs.method_11654(ENERGIZED);
    }

    @Override
    public class_2680 endEnergized(class_2338 pos, class_2680 bs, class_1937 world) {
        var newState = bs.method_11657(ENERGIZED, false);
        world.method_8501(pos, newState);
        return newState;
    }

    /**
     * Which direction points "up" or "out" for this block?
     * This is used for {@link ICircleComponent#canEnterFromDirection(class_2350, class_2338, class_2680, class_3218)}
     * as well as particles.
     */
    public class_2350 normalDir(class_2338 pos, class_2680 bs, class_1937 world) {
        return normalDir(pos, bs, world, 16);
    }

    abstract public class_2350 normalDir(class_2338 pos, class_2680 bs, class_1937 world, int recursionLeft);

    public static class_2350 normalDirOfOther(class_2338 other, class_1937 world, int recursionLeft) {
        if (recursionLeft <= 0) {
            return class_2350.field_11036;
        }

        var stateThere = world.method_8320(other);
        if (stateThere.method_26204() instanceof BlockCircleComponent bcc) {
            return bcc.normalDir(other, stateThere, world, recursionLeft - 1);
        } else {
            return class_2350.field_11036;
        }
    }

    /**
     * How many blocks in the {@link BlockCircleComponent#normalDir(class_2338, class_2680, class_1937)} from the center
     * particles should be spawned in
     */
    abstract public float particleHeight(class_2338 pos, class_2680 bs, class_1937 world);

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> pBuilder) {
        pBuilder.method_11667(ENERGIZED);
    }

    @Override
    public boolean method_9498(class_2680 pState) {
        return true;
    }

    @Override
    public int method_9572(class_2680 pState, class_1937 pLevel, class_2338 pPos) {
        return pState.method_11654(ENERGIZED) ? 15 : 0;
    }

    public static class_2680 placeStateDirAndSneak(class_2680 stock, class_1750 ctx) {
        var dir = ctx.method_7715();
        if (ctx.method_8036() != null && ctx.method_8036().method_21751()) {
            dir = dir.method_10153();
        }
        return stock.method_11657(class_2741.field_12525, dir);
    }
}
