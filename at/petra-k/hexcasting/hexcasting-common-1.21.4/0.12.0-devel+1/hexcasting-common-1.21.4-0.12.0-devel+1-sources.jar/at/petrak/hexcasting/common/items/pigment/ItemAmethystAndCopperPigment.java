package at.petrak.hexcasting.common.items.pigment;

import at.petrak.hexcasting.api.addldata.ADPigment;
import at.petrak.hexcasting.api.item.PigmentItem;
import at.petrak.hexcasting.api.pigment.ColorProvider;
import java.util.UUID;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_243;

public class ItemAmethystAndCopperPigment extends class_1792 implements PigmentItem {
    public ItemAmethystAndCopperPigment(class_1793 pProperties) {
        super(pProperties);
    }

    @Override
    public ColorProvider provideColor(class_1799 stack, UUID owner) {
        return colorProvider;
    }

    protected MyColorProvider colorProvider = new MyColorProvider();

    protected class MyColorProvider extends ColorProvider {
        private static final int[] COLORS = {
            0xff_54398a, // dark purple
            0xff_cfa0f3, // light purple
            0xff_fecbe6, // pink
            0xff_cfa0f3, // light purple
            0xff_e77c56, // dark copper
        };

        @Override
        protected int getRawColor(float time, class_243 position) {
            return ADPigment.morphBetweenColors(COLORS, new class_243(0.1, 0.1, 0.1), time / 600, position);
        }
    }
}
