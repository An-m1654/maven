package at.petrak.hexcasting.client.entity;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import net.minecraft.class_10011;
import net.minecraft.class_1937;

public class WallScrollRenderState extends class_10011 {
    public HexPattern pattern;
    public boolean showStrokeOrder;
    public boolean isAncient;
    public int blockSize;
    public class_1937 level;

    public boolean getShowsStrokeOrder() {
        return showStrokeOrder;
    }

    @Override
    public boolean method_62610() {
        return false;
    }
}
