package at.petrak.hexcasting.client.render;


import at.petrak.hexcasting.api.casting.math.HexPattern;
import com.mojang.blaze3d.systems.RenderSystem;
import javax.annotation.Nullable;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9848;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class PatternRenderer {

    public static void renderPattern(HexPattern pattern, class_4587 ps, PatternSettings patSets, PatternColors patColors, double seed, int resPerUnit) {
        renderPattern(pattern, ps, null, patSets, patColors, seed, resPerUnit);
    }

    public static void renderPattern(HexPattern pattern, class_4587 ps, @Nullable WorldlyBits worldlyBits, PatternSettings patSets, PatternColors patColors, double seed, int resPerUnit) {
        renderPattern(HexPatternLike.of(pattern), ps, worldlyBits, patSets, patColors, seed, resPerUnit);
    }

    /**
     * Renders a pattern (or rather a pattern-like) according to the given settings.
     * @param patternlike the pattern (or more generally the lines) to render.
     * @param ps pose/matrix stack to render based on. (0,0) is treated as the top left corner. The size of the render is determined by patSets.
     * @param worldlyBits used for rendering with light/normals/render-layers if possible. This is optional and probably shouldn't be used for UI rendering.
     * @param patSets settings that control how the pattern is drawn.
     * @param patColors colors to use for drawing the pattern and dots.
     * @param seed seed to use for zappy wobbles.
     * @param resPerUnit the texture resolution per pose unit space to be used *if* the texture renderer is used.
     */
    public static void renderPattern(HexPatternLike patternlike, class_4587 ps, @Nullable WorldlyBits worldlyBits, PatternSettings patSets, PatternColors patColors, double seed, int resPerUnit){
        var oldShader = RenderSystem.getShader();
        HexPatternPoints staticPoints = HexPatternPoints.getStaticPoints(patternlike, patSets, seed);

        boolean shouldRenderDynamic = true;

        // only do texture rendering if it's static and has solid colors
        if(patSets.getSpeed() == 0 && PatternTextureManager.useTextures && patColors.innerStartColor() == patColors.innerEndColor()
        && patColors.outerStartColor() == patColors.outerEndColor()){
            boolean didRender = renderPatternTexture(patternlike, ps, worldlyBits, patSets, patColors, seed, resPerUnit);
            if(didRender) shouldRenderDynamic = false;
        }
        if(shouldRenderDynamic){
            List<class_241> zappyPattern;

            if(patSets.getSpeed() == 0) {
                // re-use our static points if we're rendering a static pattern anyway
                zappyPattern = staticPoints.zappyPoints;
            } else {
                List<class_241> nonzappyLines = patternlike.getNonZappyPoints();
                Set<Integer> dupIndices = RenderLib.findDupIndices(nonzappyLines);
                zappyPattern = RenderLib.makeZappy(nonzappyLines, dupIndices,
                        patSets.getHops(), patSets.getVariance(), patSets.getSpeed(), patSets.getFlowIrregular(),
                        patSets.getReadabilityOffset(), patSets.getLastSegmentProp(), seed);
            }

            List<class_241> zappyRenderSpace = staticPoints.scaleVecs(zappyPattern);

            var isGlowyInline = patSets.getName().equals("inlineglowy");

            if(class_9848.method_61320(patColors.outerEndColor()) != 0 && class_9848.method_61320(patColors.outerStartColor()) != 0){
                RenderLib.drawLineSeq(ps.method_23760().method_23761(), zappyRenderSpace, (float)patSets.getOuterWidth(staticPoints.finalScale),
                        patColors.outerStartColor(), patColors.outerEndColor(), VCDrawHelper.getHelper(worldlyBits, ps,outerZ));
            }
            if(class_9848.method_61320(patColors.innerEndColor()) != 0 && class_9848.method_61320(patColors.innerStartColor()) != 0) {
                RenderLib.drawLineSeq(ps.method_23760().method_23761(), zappyRenderSpace, (float)patSets.getInnerWidth(staticPoints.finalScale),
                        patColors.innerStartColor(), patColors.innerEndColor(), VCDrawHelper.getHelper(worldlyBits, ps,isGlowyInline ? 1f : innerZ));
            }
        }

        // render dots and grid dynamically

        float dotZ = 0.0011f;

        if(class_9848.method_61320(patColors.startingDotColor()) != 0) {
            RenderLib.drawSpot(ps.method_23760().method_23761(), staticPoints.dotsScaled.get(0), (float)patSets.getStartDotRadius(staticPoints.finalScale),
                    patColors.startingDotColor(), VCDrawHelper.getHelper(worldlyBits, ps, dotZ));
        }

        if(class_9848.method_61320(patColors.gridDotsColor()) != 0) {
            for(int i = 1; i < staticPoints.dotsScaled.size(); i++){
                class_241 gridDot = staticPoints.dotsScaled.get(i);
                RenderLib.drawSpot(ps.method_23760().method_23761(), gridDot, (float)patSets.getGridDotsRadius(staticPoints.finalScale),
                    patColors.gridDotsColor(), VCDrawHelper.getHelper(worldlyBits, ps, dotZ));
            }
        }

        RenderSystem.setShader(oldShader);
    }

    private static final float outerZ = 0.0005f;

    private static float innerZ = 0.001f;

    private static boolean renderPatternTexture(HexPatternLike patternlike, class_4587 ps, @Nullable WorldlyBits worldlyBits, PatternSettings patSets, PatternColors patColors, double seed, int resPerUnit){

        Optional<Map<String, class_2960>> maybeTextures = PatternTextureManager.getTextures(patternlike, patSets, seed, resPerUnit);
        if(maybeTextures.isEmpty()){
            return false;
        }

        Map<String, class_2960> textures = maybeTextures.get();
        HexPatternPoints staticPoints = HexPatternPoints.getStaticPoints(patternlike, patSets, seed);

        class_4588 vc;

        if(class_9848.method_61320(patColors.outerStartColor()) != 0) {
            VCDrawHelper vcHelper = VCDrawHelper.getHelper(worldlyBits, ps, outerZ, textures.get("outer"));
            vc = vcHelper.vcSetupAndSupply(class_293.class_5596.field_27382);

            int cl = patColors.outerStartColor();

            vcHelper.vertex(vc, cl, new class_241(0, 0), new class_241(0, 0), ps.method_23760().method_23761());
            vcHelper.vertex(vc, cl, new class_241(0, (float) staticPoints.fullHeight), new class_241(0, 1), ps.method_23760().method_23761());
            vcHelper.vertex(vc, cl, new class_241((float) staticPoints.fullWidth, (float) staticPoints.fullHeight), new class_241(1, 1), ps.method_23760().method_23761());
            vcHelper.vertex(vc, cl, new class_241((float) staticPoints.fullWidth, 0), new class_241(1, 0), ps.method_23760().method_23761());

            vcHelper.vcEndDrawer(vc);
        }

        if(class_9848.method_61320(patColors.innerStartColor()) != 0) {
            VCDrawHelper vcHelper = VCDrawHelper.getHelper(worldlyBits, ps, innerZ, textures.get("inner"));
            vc = vcHelper.vcSetupAndSupply(class_293.class_5596.field_27382);

            int cl = patColors.innerStartColor();

            vcHelper.vertex(vc, cl, new class_241(0, 0), new class_241(0, 0), ps.method_23760().method_23761());
            vcHelper.vertex(vc, cl, new class_241(0, (float) staticPoints.fullHeight), new class_241(0, 1), ps.method_23760().method_23761());
            vcHelper.vertex(vc, cl, new class_241((float) staticPoints.fullWidth, (float) staticPoints.fullHeight), new class_241(1, 1), ps.method_23760().method_23761());
            vcHelper.vertex(vc, cl, new class_241((float) staticPoints.fullWidth, 0), new class_241(1, 0), ps.method_23760().method_23761());

            vcHelper.vcEndDrawer(vc);
        }

        return true;
    }

    // TODO did we want to un-hardcode this for accessibility reasons ?
    public static boolean shouldDoStrokeGradient(){
        return class_437.method_25441();
    }

    public record WorldlyBits(@Nullable class_4597 provider, Integer light, class_243 normal){}
}
