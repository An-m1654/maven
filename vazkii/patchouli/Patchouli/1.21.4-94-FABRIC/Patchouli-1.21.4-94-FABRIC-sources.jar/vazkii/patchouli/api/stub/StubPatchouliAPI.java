package vazkii.patchouli.api.stub;

import vazkii.patchouli.api.IMultiblock;
import vazkii.patchouli.api.IStateMatcher;
import vazkii.patchouli.api.IStyleStack;
import vazkii.patchouli.api.PatchouliAPI.IPatchouliAPI;
import vazkii.patchouli.api.PatchouliConfigAccess;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_6862;

public class StubPatchouliAPI implements IPatchouliAPI {

	public static final StubPatchouliAPI INSTANCE = new StubPatchouliAPI();

	private StubPatchouliAPI() {}

	@Override
	public boolean isStub() {
		return true;
	}

	@NotNull
	@Override
	public PatchouliConfigAccess getConfig() {
		return new PatchouliConfigAccess() {
			@Override
			public boolean disableAdvancementLocking() {
				return false;
			}

			@NotNull
			@Override
			public List<String> noAdvancementBooks() {
				return Collections.emptyList();
			}

			@Override
			public boolean testingMode() {
				return false;
			}

			@NotNull
			@Override
			public String inventoryButtonBook() {
				return "";
			}

			@Override
			public boolean useShiftForQuickLookup() {
				return false;
			}

			@NotNull
			@Override
			public TextOverflowMode overflowMode() {
				return TextOverflowMode.OVERFLOW;
			}

			@Override
			public int quickLookupTime() {
				return Integer.MAX_VALUE;
			}
		};
	}

	@Override
	public void setConfigFlag(String flag, boolean value) {
		// NO-OP
	}

	@Override
	public boolean getConfigFlag(String flag) {
		return false;
	}

	@Override
	public void openBookGUI(class_3222 player, class_2960 book) {
		// NO-OP
	}

	@Override
	public void openBookEntry(class_3222 player, class_2960 book, class_2960 entry, int page) {

	}

	@Override
	public void openBookGUI(class_2960 book) {
		// NO-OP
	}

	@Override
	public void openBookEntry(class_2960 book, class_2960 entry, int page) {}

	@Override
	public class_2960 getOpenBookGui() {
		return null;
	}

	@Override
	public class_2561 getSubtitle(class_2960 bookId) {
		throw new IllegalArgumentException("Patchouli is not loaded");
	}

	@Override
	public void registerCommand(String name, Function<IStyleStack, String> command) {
		// NO-OP
	}

	@Override
	public void registerFunction(String name, BiFunction<String, IStyleStack, String> function) {
		// NO-OP
	}

	@Override
	public class_1799 getBookStack(class_2960 book) {
		return class_1799.field_8037;
	}

	@Override
	public void registerTemplateAsBuiltin(class_2960 res, Supplier<InputStream> streamProvider) {
		// NO-OP
	}

	@Override
	public IMultiblock getMultiblock(class_2960 res) {
		return null;
	}

	@Override
	public IMultiblock registerMultiblock(class_2960 res, IMultiblock mb) {
		return mb;
	}

	@Nullable
	@Override
	public IMultiblock getCurrentMultiblock() {
		return null;
	}

	@Override
	public void showMultiblock(IMultiblock multiblock, class_2561 displayName, class_2338 center, class_2470 rotation) {

	}

	@Override
	public void clearMultiblock() {

	}

	@Override
	public IMultiblock makeMultiblock(String[][] pattern, Object... targets) {
		return StubMultiblock.INSTANCE;
	}

	@Override
	public IMultiblock makeSparseMultiblock(Map<class_2338, IStateMatcher> positions) {
		return StubMultiblock.INSTANCE;
	}

	@Override
	public IStateMatcher predicateMatcher(class_2680 display, Predicate<class_2680> predicate) {
		return StubMatcher.INSTANCE;
	}

	@Override
	public IStateMatcher predicateMatcher(class_2248 display, Predicate<class_2680> predicate) {
		return StubMatcher.INSTANCE;
	}

	@Override
	public IStateMatcher stateMatcher(class_2680 state) {
		return StubMatcher.INSTANCE;
	}

	@Override
	public IStateMatcher propertyMatcher(class_2680 state, class_2769<?>... properties) {
		return StubMatcher.INSTANCE;
	}

	@Override
	public IStateMatcher looseBlockMatcher(class_2248 block) {
		return StubMatcher.INSTANCE;
	}

	@Override
	public IStateMatcher strictBlockMatcher(class_2248 block) {
		return StubMatcher.INSTANCE;
	}

	@Override
	public IStateMatcher displayOnlyMatcher(class_2680 state) {
		return StubMatcher.INSTANCE;
	}

	@Override
	public IStateMatcher displayOnlyMatcher(class_2248 block) {
		return StubMatcher.INSTANCE;
	}

	@Override
	public IStateMatcher airMatcher() {
		return StubMatcher.INSTANCE;
	}

	@Override
	public IStateMatcher anyMatcher() {
		return StubMatcher.INSTANCE;
	}

	@Override
	public IStateMatcher tagMatcher(class_6862<class_2248> block) {
		return StubMatcher.INSTANCE;
	}
}
