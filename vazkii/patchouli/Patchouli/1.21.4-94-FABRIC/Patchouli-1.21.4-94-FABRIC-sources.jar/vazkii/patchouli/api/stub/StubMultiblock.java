package vazkii.patchouli.api.stub;

import com.mojang.datafixers.util.Pair;
import vazkii.patchouli.api.IMultiblock;

import java.util.Collection;
import java.util.Collections;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2470;
import net.minecraft.class_2960;

public class StubMultiblock implements IMultiblock {

	public static final StubMultiblock INSTANCE = new StubMultiblock();

	private StubMultiblock() {}

	@Override
	public IMultiblock offset(int x, int y, int z) {
		return this;
	}

	@Override
	public IMultiblock offsetView(int x, int y, int z) {
		return this;
	}

	@Override
	public IMultiblock setSymmetrical(boolean symmetrical) {
		return this;
	}

	@Override
	public class_2960 getID() {
		return class_2960.method_60655("patchouli", "stub");
	}

	@Override
	public IMultiblock setId(class_2960 res) {
		return this;
	}

	@Override
	public boolean isSymmetrical() {
		return false;
	}

	@Override
	public void place(class_1937 world, class_2338 pos, class_2470 rotation) {
		// NO-OP
	}

	@Override
	public Pair<class_2338, Collection<SimulateResult>> simulate(class_1937 world, class_2338 anchor, class_2470 rotation, boolean forView) {
		return Pair.of(class_2338.field_10980, Collections.emptyList());
	}

	@Override
	public class_2470 validate(class_1937 world, class_2338 pos) {
		return null;
	}

	@Override
	public boolean validate(class_1937 world, class_2338 pos, class_2470 rotation) {
		return false;
	}

	@Override
	public boolean test(class_1937 world, class_2338 start, int x, int y, int z, class_2470 rotation) {
		return false;
	}

	@Override
	public class_2382 getSize() {
		return class_2382.field_11176;
	}

}
