package vazkii.patchouli.fabric.client;

import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import net.minecraft.class_776;
import net.minecraft.class_8786;
import vazkii.patchouli.xplat.IClientXplatAbstractions;

public class FabricClientXplatImpl implements IClientXplatAbstractions {
	@Override
	public void renderForMultiblock(class_2680 state, class_2338 pos, class_1920 multiblock, class_4587 ps, class_4597 buffers, class_5819 rand) {
		final class_776 blockRenderer = class_310.method_1551().method_1541();
		if (state.method_26217() != class_2464.field_11455) {
			final class_1921 layer = class_4696.method_23679(state);
			final class_4588 buffer = buffers.getBuffer(layer);
			blockRenderer.method_3355(state, pos, multiblock, ps, buffer, false, rand);
		}
	}

    @Override
    public class_8786<?> getRecipes() {
        return null;
    }
}
