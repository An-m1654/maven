package vazkii.patchouli.fabric.common;

import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.class_4516;
import net.minecraft.class_6302;

public class PatchouliSmokeTest {
	@class_6302(method_35936 = FabricGameTest.EMPTY_STRUCTURE)
	public void doesItRun(class_4516 helper) {
		helper.method_36036();
	}
}
