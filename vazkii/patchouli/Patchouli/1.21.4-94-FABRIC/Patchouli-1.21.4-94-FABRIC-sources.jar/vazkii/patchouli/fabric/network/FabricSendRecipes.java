package vazkii.patchouli.fabric.network;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import vazkii.patchouli.client.base.ClientRecipes;
import vazkii.patchouli.fabric.event.ReceivedRecipeEvent;
import vazkii.patchouli.network.AskForRecipes;
import vazkii.patchouli.network.SendRecipes;

public class FabricSendRecipes {
    public static void handle(SendRecipes message, ClientPlayNetworking.Context handler) {
        //This is client
        ClientRecipes.receivedRecipes(message.recipes());
        ReceivedRecipeEvent.RECEIVED.invoker().interact();
    }
}
