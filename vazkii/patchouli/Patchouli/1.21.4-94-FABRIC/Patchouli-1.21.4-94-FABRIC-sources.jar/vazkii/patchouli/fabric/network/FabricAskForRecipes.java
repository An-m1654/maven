package vazkii.patchouli.fabric.network;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import vazkii.patchouli.network.AskForRecipes;
import vazkii.patchouli.network.SendRecipes;

public class FabricAskForRecipes {
    public static void ask() {
        //This is client
        ClientPlayNetworking.send(new AskForRecipes());
    }

    public static void handle(AskForRecipes message, ServerPlayNetworking.Context handler) {
        ServerPlayNetworking.send(handler.player(), new SendRecipes(handler.player().field_13995.method_3772().method_8126()));
    }
}
