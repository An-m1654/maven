package vazkii.patchouli.fabric.client;

import com.mojang.serialization.MapCodec;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientWorldEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_10443;
import net.minecraft.class_10482;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1800;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_638;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import vazkii.patchouli.api.PatchouliAPI;
import vazkii.patchouli.client.base.BookModel;
import vazkii.patchouli.client.base.ClientAdvancements;
import vazkii.patchouli.client.base.ClientTicker;
import vazkii.patchouli.client.base.PersistentData;
import vazkii.patchouli.client.book.BookContentResourceListenerLoader;
import vazkii.patchouli.client.book.ClientBookRegistry;
import vazkii.patchouli.client.handler.BookRightClickHandler;
import vazkii.patchouli.client.handler.MultiblockVisualizationHandler;
import vazkii.patchouli.common.item.ItemModBook;
import vazkii.patchouli.fabric.event.ReceivedRecipeEvent;
import vazkii.patchouli.fabric.network.FabricAskForRecipes;
import vazkii.patchouli.fabric.network.FabricMessageOpenBookGui;
import vazkii.patchouli.fabric.network.FabricMessageReloadBookContents;
import vazkii.patchouli.fabric.network.FabricSendRecipes;
import vazkii.patchouli.network.MessageOpenBookGui;
import vazkii.patchouli.network.MessageReloadBookContents;
import vazkii.patchouli.network.SendRecipes;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public class FabricClientInitializer implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ClientBookRegistry.INSTANCE.init();
		PersistentData.setup();
		ClientTickEvents.END_CLIENT_TICK.register(ClientTicker::endClientTick);
		HudRenderCallback.EVENT.register(BookRightClickHandler::onRenderHUD);
		UseBlockCallback.EVENT.register(BookRightClickHandler::onRightClick);
		UseBlockCallback.EVENT.register(MultiblockVisualizationHandler::onPlayerInteract);
		ClientTickEvents.END_CLIENT_TICK.register(MultiblockVisualizationHandler::onClientTick);
		HudRenderCallback.EVENT.register(MultiblockVisualizationHandler::onRenderHUD);
		ClientPlayNetworking.registerGlobalReceiver(MessageOpenBookGui.TYPE, FabricMessageOpenBookGui::handle);
		ClientPlayNetworking.registerGlobalReceiver(MessageReloadBookContents.TYPE, FabricMessageReloadBookContents::handle);

        ClientPlayNetworking.registerGlobalReceiver(SendRecipes.TYPE, FabricSendRecipes::handle);

        ReceivedRecipeEvent.RECEIVED.register(() -> {
            ClientAdvancements.onClientPacket();
            return class_1269.field_5812;
        });

//		ModelLoadingPlugin.register(pluginContext -> {
//			for (Book book : BookRegistry.INSTANCE.books.values()) {
//				PatchouliAPI.LOGGER.info("Adding model {}", book.model);
//				pluginContext.addModels(book.model);
//			}
//
//			pluginContext.modifyModelAfterBake().register(
//					(oldModel, ctx) -> {
//						if (PatchouliItems.BOOK_ID.equals(ctx.id()) // checks namespace and path
//								&& ctx().equals("inventory")
//								&& oldModel != null) {
//							return new BookModel(oldModel, (model) -> Minecraft.getInstance().getModelManager().getModel(model));
//						}
//						return oldModel;
//					}
//			);
//		});

        class_10443.field_55336.method_65325(BookModel.Unbaked.ID, BookModel.Unbaked.MAP_CODEC);
        record CompletionItemProperty(class_1799 stack) implements class_1800 {
            public static final class_2960 ID = class_2960.method_60655(PatchouliAPI.MOD_ID, "completion");
            public static final MapCodec<CompletionItemProperty> MAP_CODEC = MapCodec.unit(new CompletionItemProperty(
                class_1799.field_8037
            ));
            @Override
            public float method_65644(class_1799 itemStack, @Nullable class_638 clientLevel, @Nullable class_1309 livingEntity, int i) {
                return ItemModBook.getCompletion(itemStack);
            }

            @Override
            public @NotNull MapCodec<? extends class_1800> method_65643() {
                return MAP_CODEC;
            }
        }
//		ItemProperties.register(PatchouliItems.BOOK,
//				ResourceLocation.fromNamespaceAndPath(PatchouliAPI.MOD_ID, "completion"),
//				(stack, world, entity, seed) -> ItemModBook.getCompletion(stack));
        class_10482.field_55408.method_65325(class_2960.method_60655(PatchouliAPI.MOD_ID, "completion"), CompletionItemProperty.MAP_CODEC);

		ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new IdentifiableResourceReloadListener() {
            private static final class_2960 id = class_2960.method_60655(PatchouliAPI.MOD_ID, "resource_pack_books");

			@Override
			public @NotNull CompletableFuture<Void> method_25931(class_4045 barrier, class_3300 manager, Executor backgroundExecutor, Executor gameExecutor) {
				return BookContentResourceListenerLoader.INSTANCE.method_25931(barrier, manager, backgroundExecutor, gameExecutor);
			}

			@Override
			public class_2960 getFabricId() {
				return id;
			}
		});
		ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
			private static final class_2960 id = class_2960.method_60655(PatchouliAPI.MOD_ID, "reload_hook");

			@Override
			public class_2960 getFabricId() {
				return id;
			}

			@Override
			public void method_14491(class_3300 manager) {
				if (class_310.method_1551().field_1687 != null) {
					PatchouliAPI.LOGGER.info("Reloading resource pack-based books");
					ClientBookRegistry.INSTANCE.reload();
				} else {
					PatchouliAPI.LOGGER.debug("Not reloading resource pack-based books as client world is missing");
				}
			}
		});
	}
}
