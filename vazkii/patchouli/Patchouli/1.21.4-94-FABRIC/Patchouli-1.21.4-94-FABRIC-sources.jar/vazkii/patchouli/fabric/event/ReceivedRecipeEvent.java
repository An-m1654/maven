package vazkii.patchouli.fabric.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1269;

public interface ReceivedRecipeEvent {
    Event<ReceivedRecipeEvent> RECEIVED = EventFactory.createArrayBacked(
        ReceivedRecipeEvent.class,
        receivedRecipeEvents -> () -> {
            for (ReceivedRecipeEvent event : receivedRecipeEvents) {
                class_1269 result = event.interact();

                if (result != class_1269.field_5811) {
                    return result;
                }
            }

            return class_1269.field_5811;
        });

    class_1269 interact();
}
