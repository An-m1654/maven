package vazkii.patchouli.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Optional;

//@Mixin(SmithingTransformRecipe.class)
//public interface AccessorSmithingTransformRecipe {
//	@Accessor
//    Optional<Ingredient> getTemplate();
//
//	@Accessor
//    Optional<Ingredient> getBase();
//
//	@Accessor
//    Optional<Ingredient> getAddition();
//}
