package vazkii.patchouli.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.SequencedMap;
import net.minecraft.class_1921;
import net.minecraft.class_4597;
import net.minecraft.class_9799;

@Mixin(class_4597.class_4598.class)
public interface AccessorMultiBufferSource {
	@Accessor("sharedBuffer")
	class_9799 getFallbackBuffer();

	@Accessor("fixedBuffers")
	SequencedMap<class_1921, class_9799> getFixedBuffers();
}
