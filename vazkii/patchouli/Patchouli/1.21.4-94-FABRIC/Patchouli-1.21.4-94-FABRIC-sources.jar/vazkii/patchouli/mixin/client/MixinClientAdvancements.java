package vazkii.patchouli.mixin.client;

import net.minecraft.class_2779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import vazkii.patchouli.client.base.ClientAdvancements;
import vazkii.patchouli.xplat.IXplatAbstractions;

@Mixin(net.minecraft.class_632.class)
public abstract class MixinClientAdvancements {

	@Inject(at = @At("RETURN"), method = "update")
	public void patchouli_onSync(class_2779 packet, CallbackInfo info) {
        IXplatAbstractions.INSTANCE.askForRecipes();
	}
}
