package vazkii.patchouli.client.book.template.variable;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.mojang.serialization.JsonOps;
import vazkii.patchouli.api.IVariableSerializer;
import vazkii.patchouli.common.util.ItemStackUtil;

import java.util.List;
import net.minecraft.class_1856;
import net.minecraft.class_7225;

public class IngredientVariableSerializer implements IVariableSerializer<class_1856> {
    private JsonArray listToJsonArray(List<? extends JsonElement> list) {
        JsonArray array = new JsonArray();
        for (JsonElement element : list) {
            array.add(element);
        }
        return array;
    }

	@Override
	public class_1856 fromJson(JsonElement json, class_7225.class_7874 registries) {
        if (json.isJsonObject() && json.getAsJsonObject().has("tag")) {
            JsonElement tag = json.getAsJsonObject().get("tag");
            json = tag.isJsonArray() ? listToJsonArray(tag.getAsJsonArray().asList().stream().map(jsonElement -> new JsonPrimitive(("#" + jsonElement.getAsString()))).toList()) : new JsonPrimitive("#" + tag.getAsJsonPrimitive().getAsString());
        }
//		return (json.isJsonPrimitive()) ? ItemStackUtil.loadIngredientFromString(json.getAsString(), registries) : Ingredient.CODEC.parse(registries.createSerializationContext(JsonOps.INSTANCE), json).result().orElseThrow();
        return class_1856.field_46095.parse(registries.method_57093(JsonOps.INSTANCE), json).result().orElseThrow();
	}

	@Override
	public JsonElement toJson(class_1856 stack, class_7225.class_7874 registries) {
		return class_1856.field_46095.encodeStart(registries.method_57093(JsonOps.INSTANCE), stack).result().orElseThrow();
	}
}
