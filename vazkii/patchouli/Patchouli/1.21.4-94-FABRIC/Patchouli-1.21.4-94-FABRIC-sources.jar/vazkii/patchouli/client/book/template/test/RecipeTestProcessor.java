package vazkii.patchouli.client.book.template.test;

import net.minecraft.class_10294;
import net.minecraft.class_10295;
import net.minecraft.class_10300;
import net.minecraft.class_10301;
import net.minecraft.class_10302;
import net.minecraft.class_10314;
import net.minecraft.class_10315;
import net.minecraft.class_10363;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_8786;
import net.minecraft.world.item.crafting.display.*;
import org.jetbrains.annotations.Nullable;
import vazkii.patchouli.api.IComponentProcessor;
import vazkii.patchouli.api.IVariable;
import vazkii.patchouli.api.IVariableProvider;
import vazkii.patchouli.client.base.ClientRecipes;

import java.util.List;

public class RecipeTestProcessor implements IComponentProcessor {

	private class_1860<?> recipe;

	@Override
	public void setup(class_1937 level, IVariableProvider variables) {
		// TODO probably add a recipe serializer?
		String recipeId = variables.get("recipe", level.method_30349()).asString();
        class_8786<class_1860<?>> recipe = ClientRecipes.getRecipeById(class_2960.method_60654(recipeId));
//		RecipeManager manager = level.getRecipeManager();
//		recipe = manager.byKey(ResourceLocation.tryParse(recipeId)).orElseThrow(IllegalArgumentException::new).value();
        if (recipe == null) {
            throw new IllegalArgumentException("No recipe with id " + recipeId + " found");
        }
        this.recipe = recipe.comp_1933();
	}

	@Override
	public @Nullable IVariable process(class_1937 level, String key) {
        List<class_10295> display = recipe.method_64664();
        if (display.isEmpty()) {
            return null;
        }
		if (key.startsWith("item")) {
			int index = Integer.parseInt(key.substring(4)) - 1;
            List<class_10302> ingredients = switch (display.getFirst()) {
                case class_10300 shaped -> shaped.comp_3270();
                case class_10301 shapeless -> shapeless.comp_3271();
                case class_10294 furnace -> List.of(furnace.comp_3256());
                case class_10314 smithing -> List.of(smithing.comp_3303(), smithing.comp_3304());
                case class_10315 stonecutter -> List.of(stonecutter.comp_3305());
                default -> throw new IllegalArgumentException("Unsupported recipe display type: " + display.getFirst().getClass().getName());
            };
            class_10302 slotDisplay = ingredients.get(index);
//			Ingredient ingredient = recipe.getIngredients().get(index);
//			ItemStack[] stacks = ingredient.getItems();
//			ItemStack stack = stacks.length == 0 ? ItemStack.EMPTY : stacks[0];

			return IVariable.from(slotDisplay.method_64742(class_10363.method_65008(level)), level.method_30349());
		} else if (key.equals("text")) {
			class_1799 out = display.getFirst().comp_3258().method_64742(class_10363.method_65008(level));
			return IVariable.wrap(out.method_7947() + "x$(br)" + out.method_7964(), level.method_30349());
		} else if (key.equals("icount")) {
			return IVariable.wrap(display.getFirst().comp_3258().method_64742(class_10363.method_65008(level)).method_7947(), level.method_30349());
		} else if (key.equals("iname")) {
			return IVariable.wrap(display.getFirst().comp_3258().method_64742(class_10363.method_65008(level)).method_7964().getString(), level.method_30349());
		}
		return null;
	}

}
