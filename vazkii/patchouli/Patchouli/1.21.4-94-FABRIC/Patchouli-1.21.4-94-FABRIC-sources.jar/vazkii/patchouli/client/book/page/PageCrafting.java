package vazkii.patchouli.client.book.page;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_10295;
import net.minecraft.class_10300;
import net.minecraft.class_10301;
import net.minecraft.class_10302;
import net.minecraft.class_10352;
import net.minecraft.class_1860;
import net.minecraft.class_1869;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3956;
import net.minecraft.class_9838;
import net.minecraft.world.item.crafting.display.*;
import vazkii.patchouli.client.book.gui.GuiBook;
import vazkii.patchouli.client.book.page.abstr.PageDoubleRecipeRegistry;

import java.util.List;

public class PageCrafting extends PageDoubleRecipeRegistry<class_1860<?>, class_10295> {

	public PageCrafting() {
		super(class_3956.field_17545, class_10295.class);
	}

	@Override
	protected void drawRecipe(class_332 graphics, class_10295 recipe, class_10352 context, int recipeX, int recipeY, int mouseX, int mouseY, boolean second) {
		class_1937 level = class_310.method_1551().field_1687;
		if (level == null) {
			return;
		}

		RenderSystem.enableBlend();
		graphics.method_25290(
            class_1921::method_62277,
            book.craftingTexture,
            recipeX - 2, recipeY - 2,
            0, 0,
            100, 62,
            128, 256
        );

		boolean shaped = recipe instanceof class_1869;
		if (!shaped) {
			int iconX = recipeX + 62;
			int iconY = recipeY + 2;
			graphics.method_25290(class_1921::method_62277,
                book.craftingTexture,
                iconX, iconY,
                0, 64,
                11, 11,
                128, 256);
			if (parent.isMouseInRelativeRange(mouseX, mouseY, iconX, iconY, 11, 11)) {
				parent.setTooltip(class_2561.method_43471("patchouli.gui.lexicon.shapeless"));
			}
		}

		parent.drawCenteredStringNoShadow(graphics, getTitle(second).method_30937(), GuiBook.PAGE_WIDTH / 2, recipeY - 10, book.headerColor);

        int width;
        int height;
        class_10302 result;
        List<class_10302> ingredients;
        class_10302 craftingStation;
        switch (recipe) {
            case class_10300 shapedDisplay -> {
                ingredients = shapedDisplay.comp_3270();
                result = shapedDisplay.comp_3258();
                craftingStation = shapedDisplay.comp_3259();
                width = shapedDisplay.comp_3268();
                height = shapedDisplay.comp_3269();
            }
            case class_10301 shapelessDisplay -> {
                ingredients = shapelessDisplay.comp_3271();
                result = shapelessDisplay.comp_3258();
                craftingStation = shapelessDisplay.comp_3259();
                width = height = 3;
            }
            case null, default -> {
                return;
            }
        }

        class_9838.method_61229(3, 3, width, height, ingredients, (item, slot, x, y) -> {
            parent.renderItemStack(graphics, recipeX + x * 19 + 3, recipeY + y * 19 + 3, mouseX, mouseY, item.method_64742(context));
        });

		parent.renderItemStack(graphics, recipeX + 79, recipeY + 22, mouseX, mouseY, result.method_64742(context));

//		NonNullList<Ingredient> ingredients = recipe.getIngredients();
//		int wrap = 3;
//		if (shaped) {
//			wrap = ((ShapedRecipe) recipe).getWidth();
//		}
//
//		for (int i = 0; i < ingredients.size(); i++) {
//			parent.renderIngredient(graphics, recipeX + (i % wrap) * 19 + 3, recipeY + (i / wrap) * 19 + 3, mouseX, mouseY, ingredients.get(i));
//		}

		parent.renderItemStack(graphics, recipeX + 79, recipeY + 41, mouseX, mouseY, craftingStation.method_64742(context));
	}

	@Override
	protected int getRecipeHeight() {
		return 78;
	}

//	@Override
//	protected ItemStack getRecipeOutput(Level level, RecipeDisplay recipe) {
//		if (recipe == null || level == null) {
//			return ItemStack.EMPTY;
//		}
//		return recipe.getResultItem(level.registryAccess());
//	}

}
