package vazkii.patchouli.client.book.template.component;

import com.google.gson.annotations.SerializedName;
import com.mojang.blaze3d.systems.RenderSystem;
import vazkii.patchouli.api.IVariable;
import vazkii.patchouli.client.book.BookContentsBuilder;
import vazkii.patchouli.client.book.BookEntry;
import vazkii.patchouli.client.book.BookPage;
import vazkii.patchouli.client.book.template.TemplateComponent;

import java.util.function.UnaryOperator;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_7225;
import net.minecraft.class_9848;

public class ComponentImage extends TemplateComponent {

	public String image;

	public int u, v, width, height;

	@SerializedName("texture_width") public int textureWidth = 256;
	@SerializedName("texture_height") public int textureHeight = 256;

	public float scale = 1F;

	transient class_2960 resource;

	@Override
	public void build(BookContentsBuilder builder, BookPage page, BookEntry entry, int pageNum) {
		resource = class_2960.method_12829(image);
	}

	@Override
	public void onVariablesAvailable(UnaryOperator<IVariable> lookup, class_7225.class_7874 registries) {
		super.onVariablesAvailable(lookup, registries);
		image = lookup.apply(IVariable.wrap(image, registries)).asString();
	}

	@Override
	public void render(class_332 graphics, BookPage page, int mouseX, int mouseY, float pticks) {
		if (scale == 0F) {
			return;
		}

		graphics.method_51448().method_22903();
		graphics.method_51448().method_46416(x, y, 0);
		graphics.method_51448().method_22905(scale, scale, scale);
		RenderSystem.enableBlend();
		graphics.method_25291(
            class_1921::method_62277,
            resource,
            0, 0,
            u, v,
            width, height,
            textureWidth, textureHeight,
            class_9848.method_61318(1F, 1F, 1F, 1F)
        );
		graphics.method_51448().method_22909();
	}

}
