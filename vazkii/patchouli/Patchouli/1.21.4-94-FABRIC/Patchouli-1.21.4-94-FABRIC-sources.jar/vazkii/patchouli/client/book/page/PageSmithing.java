package vazkii.patchouli.client.book.page;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_10314;
import net.minecraft.class_10352;
import net.minecraft.class_1921;
import net.minecraft.class_332;
import net.minecraft.class_3956;
import net.minecraft.class_8059;
import net.minecraft.world.item.crafting.*;
import vazkii.patchouli.client.book.gui.GuiBook;
import vazkii.patchouli.client.book.page.abstr.PageDoubleRecipeRegistry;

public class PageSmithing extends PageDoubleRecipeRegistry<class_8059, class_10314> {

	public PageSmithing() {
		super(class_3956.field_25388, class_10314.class);
	}

	@Override
	protected void drawRecipe(class_332 graphics, class_10314 recipe, class_10352 context, int recipeX, int recipeY, int mouseX, int mouseY, boolean second) {
//		Level level = Minecraft.getInstance().level;
//		if (level == null) {
//			return;
//		}

		RenderSystem.enableBlend();
		graphics.method_25290(
            class_1921::method_62277,
            book.craftingTexture,
            recipeX, recipeY,
            11, 135,
            96, 43,
            128, 256
        );
		parent.drawCenteredStringNoShadow(graphics, getTitle(second).method_30937(), GuiBook.PAGE_WIDTH / 2, recipeY - 10, book.headerColor);

		parent.renderItemStack(graphics, recipeX + 4, recipeY + 4, mouseX, mouseY, recipe.comp_3303().method_64742(context));
		parent.renderItemStack(graphics, recipeX + 4, recipeY + 23, mouseX, mouseY, recipe.comp_3304().method_64742(context));
		parent.renderItemStack(graphics, recipeX + 40, recipeY + 4, mouseX, mouseY, recipe.comp_3302().method_64742(context));
		parent.renderItemStack(graphics, recipeX + 40, recipeY + 20, mouseX, mouseY, recipe.comp_3259().method_64742(context));
		parent.renderItemStack(graphics, recipeX + 76, recipeY + 13, mouseX, mouseY, recipe.comp_3258().method_64742(context));
	}

//	private Ingredient getBase(SmithingRecipe recipe) {
//		if (recipe instanceof SmithingTrimRecipe) {
//			return ((AccessorSmithingTrimRecipe) recipe).getBase();
//		}
//		if (recipe instanceof SmithingTransformRecipe) {
//			return ((AccessorSmithingTransformRecipe) recipe).getBase();
//		}
//		return Ingredient.of();
//	}
//
//	private Ingredient getAddition(SmithingRecipe recipe) {
//		if (recipe instanceof SmithingTrimRecipe) {
//			return ((AccessorSmithingTrimRecipe) recipe).getAddition();
//		}
//		if (recipe instanceof SmithingTransformRecipe) {
//			return ((AccessorSmithingTransformRecipe) recipe).getAddition();
//		}
//		return Ingredient.of();
//	}
//
//	private Ingredient getTemplate(SmithingRecipe recipe) {
//		if (recipe instanceof SmithingTrimRecipe) {
//			return ((AccessorSmithingTrimRecipe) recipe).getTemplate();
//		}
//		if (recipe instanceof SmithingTransformRecipe) {
//			return ((AccessorSmithingTransformRecipe) recipe).getTemplate();
//		}
//		return Ingredient.of();
//	}

//	@Override
//	protected ItemStack getRecipeOutput(Level level, SmithingRecipe recipe) {
//		if (recipe == null || level == null) {
//			return ItemStack.EMPTY;
//		}
//
//		return recipe.getResultItem(level.registryAccess());
//	}

	@Override
	protected int getRecipeHeight() {
		return 60;
	}
}
