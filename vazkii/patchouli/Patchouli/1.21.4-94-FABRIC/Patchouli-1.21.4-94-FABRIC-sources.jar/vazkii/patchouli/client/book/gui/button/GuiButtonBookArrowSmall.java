package vazkii.patchouli.client.book.gui.button;

import vazkii.patchouli.client.book.gui.GuiBook;

import java.util.function.Supplier;
import net.minecraft.class_2561;

public class GuiButtonBookArrowSmall extends GuiButtonBook {

	public final boolean left;

	public GuiButtonBookArrowSmall(GuiBook parent, int x, int y, boolean left, Supplier<Boolean> displayCondition, class_4241 onPress) {
		super(parent, x, y, 272, left ? 27 : 20, 5, 7, displayCondition, onPress,
				class_2561.method_43471(left ? "patchouli.gui.lexicon.button.prev_page" : "patchouli.gui.lexicon.button.next_page"));
		this.left = left;
	}

}
