package vazkii.patchouli.client.book.template.variable;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import net.minecraft.class_1799;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_9323;
import vazkii.patchouli.api.IVariableSerializer;
import vazkii.patchouli.common.util.ItemStackUtil;

public class ItemStackVariableSerializer implements IVariableSerializer<class_1799> {
	@Override
	public class_1799 fromJson(JsonElement json, class_7225.class_7874 registries) {
		if (json.isJsonNull()) {
			return class_1799.field_8037;
		}
		if (json.isJsonPrimitive()) {
			return ItemStackUtil.loadStackFromString(json.getAsString(), registries);
		}
		if (json.isJsonObject()) {
			return ItemStackUtil.loadStackFromJson(json.getAsJsonObject(), registries);
		}
		throw new IllegalArgumentException("Can't make an ItemStack from an array!");
	}

	@Override
	public JsonElement toJson(class_1799 stack, class_7225.class_7874 registries) {
		// Adapted from net.minecraftforge.common.crafting.StackList::toJson
		JsonObject ret = new JsonObject();
		ret.addProperty("item", class_7923.field_41178.method_10221(stack.method_7909()).toString());
		if (stack.method_7947() != 1) {
			ret.addProperty("count", stack.method_7947());
		}
		if (!stack.method_57353().method_57837()) {
			class_9323 data = stack.method_57353();
			class_9323.field_50234.encodeStart(registries.method_57093(JsonOps.INSTANCE), data).result().ifPresent(e -> ret.add("components", e));
		}
		return ret;
	}

}
