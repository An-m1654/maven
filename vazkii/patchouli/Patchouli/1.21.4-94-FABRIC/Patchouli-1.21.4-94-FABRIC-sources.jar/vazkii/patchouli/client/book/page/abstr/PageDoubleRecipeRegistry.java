package vazkii.patchouli.client.book.page.abstr;

import net.minecraft.class_10295;
import net.minecraft.class_10363;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7923;
import net.minecraft.class_8786;
import net.minecraft.world.item.crafting.*;
import vazkii.patchouli.api.PatchouliAPI;
import vazkii.patchouli.client.base.ClientRecipes;
import vazkii.patchouli.client.book.BookContentsBuilder;
import vazkii.patchouli.client.book.BookEntry;

import org.jetbrains.annotations.Nullable;

import java.util.List;

public abstract class PageDoubleRecipeRegistry<T extends class_1860<?>, D extends class_10295> extends PageDoubleRecipe<D> {
	private final class_3956<? extends T> recipeType;
    private final Class<D> displayClass;

	public PageDoubleRecipeRegistry(class_3956<? extends T> recipeType, Class<D> displayClass) {
		this.recipeType = recipeType;
        this.displayClass = displayClass;
	}

	@Nullable
	private T getRecipe(class_2960 id) {
//		RecipeManager manager = level.getRecipeManager();
        class_8786<T> recipeHolder = ClientRecipes.getRecipeById(id);
//		var recipeHolder = manager.byKey(id).filter(recipe -> recipe.value().getType() == recipeType).orElse(null);
        return recipeHolder != null && recipeHolder.comp_1933().method_17716() == recipeType ? recipeHolder.comp_1933() : null;
	}

	@Override
	protected D loadRecipe(class_1937 level, BookContentsBuilder builder, BookEntry entry, class_2960 res, boolean linkRecipe) {
		if (res == null || level == null) {
			return null;
		}

		T tempRecipe = getRecipe(res);
		if (tempRecipe == null) { // this is hacky but it works around Forge requiring custom recipes to have the prefix of the adding mod
			tempRecipe = getRecipe(class_2960.method_60655("crafttweaker", res.method_12832()));
		}

        if (tempRecipe == null) {
            PatchouliAPI.LOGGER.warn("Recipe {} (of type {}) not found", res, class_7923.field_41188.method_10221(recipeType));
            return null;
        }

        if (linkRecipe) {
            List<class_10295> display = tempRecipe.method_64664();
            if (!display.isEmpty()) {
                entry.addRelevantStack(builder, display.getFirst().comp_3258().method_64742(class_10363.method_65008(level)), pageNum);
            }
        }

        for (class_10295 recipeDisplay : tempRecipe.method_64664()) {
            if (displayClass.isInstance(recipeDisplay)) {
                return displayClass.cast(recipeDisplay);
            }
        }
        return null;

//        if (linkRecipe) {
//            entry.addRelevantStack(builder, tempRecipe.getResultItem(level.registryAccess()), pageNum);
//        }
//        return tempRecipe;
//
//		PatchouliAPI.LOGGER.warn("Recipe {} (of type {}) not found", res, BuiltInRegistries.RECIPE_TYPE.getKey(recipeType));
//		return null;
	}

}
