package vazkii.patchouli.client.book.page;

import net.minecraft.class_10294;
import net.minecraft.class_10302;
import net.minecraft.class_3859;
import net.minecraft.class_3956;
import vazkii.patchouli.client.book.page.abstr.PageSimpleProcessingRecipe;

public class PageBlasting extends PageSimpleProcessingRecipe<class_3859, class_10294> {

	public PageBlasting() {
		super(class_3956.field_17547, class_10294.class);
	}

    @Override
    protected class_10302 getIngredient(class_10294 display) {
        return display.comp_3256();
    }
}
