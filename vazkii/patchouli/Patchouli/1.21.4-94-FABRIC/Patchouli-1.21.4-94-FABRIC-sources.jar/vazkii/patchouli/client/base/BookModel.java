package vazkii.patchouli.client.base;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_10439;
import net.minecraft.class_10442;
import net.minecraft.class_10443;
import net.minecraft.class_10444;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_811;
import net.minecraft.client.resources.model.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4fc;
import vazkii.patchouli.api.PatchouliAPI;
import vazkii.patchouli.common.book.Book;
import vazkii.patchouli.common.item.ItemModBook;

import java.util.List;
import java.util.function.Function;

public class BookModel implements class_10439 {
	private final class_10439 original;

	public BookModel(class_10439 original/*, Function<ResourceLocation, BakedModel> modelGetter*/) {
		this.original = original;

//		this.itemHandler = new ItemOverrides(DummyModelBaker.INSTANCE, null, Collections.emptyList()) {
//			@Override
//			public BakedModel resolve(@NotNull BakedModel original, @NotNull ItemStack stack,
//					@Nullable ClientLevel world, @Nullable LivingEntity entity, int seed) {
//				Book book = ItemModBook.getBook(stack);
//				if (book != null) {
//					return modelGetter.apply(book.model);
//				}
//				return original;
//			}
//		};
	}

    @Override
    public void method_65584(class_10444 itemStackRenderState, class_1799 itemStack, class_10442 itemModelResolver, class_811 itemDisplayContext, @Nullable class_638 clientLevel, @Nullable class_1309 livingEntity, int i) {
        Book book = ItemModBook.getBook(itemStack);
        class_10439 model;
        if (book == null) {
            model = original;
        } else {
            model = class_310.method_1551().method_1554().method_65746(book.model);
        }
        model.method_65584(itemStackRenderState, itemStack, itemModelResolver, itemDisplayContext, clientLevel, livingEntity, i);
    }

//	@NotNull
//	@Override
//	public List<BakedQuad> getQuads(@Nullable BlockState state, @Nullable Direction side, @NotNull RandomSource rand) {
//		return original.getQuads(state, side, rand);
//	}
//
//	@Override
//	public boolean useAmbientOcclusion() {
//		return original.useAmbientOcclusion();
//	}
//
//	@Override
//	public boolean isGui3d() {
//		return original.isGui3d();
//	}
//
//	@Override
//	public boolean usesBlockLight() {
//		return original.usesBlockLight();
//	}
//
//	@NotNull
//	@Override
//	public TextureAtlasSprite getParticleIcon() {
//		return original.getParticleIcon();
//	}
//
//	@Override
//	public ItemTransforms getTransforms() {
//		return original.getTransforms();
//	}

    public record Unbaked(class_10439.class_10441 base) implements class_10439.class_10441 {
        public static final class_2960 ID = class_2960.method_60655(PatchouliAPI.MOD_ID, "book");
        public static final MapCodec<Unbaked> MAP_CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
            class_10443.field_55335.fieldOf("base").forGetter(Unbaked::base)
        ).apply(inst, Unbaked::new));

        @Override
        public MapCodec<? extends class_10439.class_10441> method_65585() {
            return MAP_CODEC;
        }

        @Override
        public class_10439 method_65587(class_10439.class_10440 bakingContext) {
            return new BookModel(base().method_65587(bakingContext));
        }

        @Override
        public void method_62326(class_10103 resolver) {
            base().method_62326(resolver);
        }
    }

//	private static class DummyModelBaker implements ModelBaker {
//		static ModelBaker INSTANCE = new DummyModelBaker();
//
//		// soft implement IModelBakerExtension
//		public Function<Material, TextureAtlasSprite> getModelTextureGetter() {
//			return null;
//		}
//
//		// soft implement IModelBakerExtension
//		public BakedModel bake(ResourceLocation location, ModelState state, Function<Material, TextureAtlasSprite> sprites) {
//			return null;
//		}
//
//		// soft implement IModelBakerExtension
//		public BakedModel bakeUncached(UnbakedModel model, ModelState state, Function<Material, TextureAtlasSprite> sprites) {
//			return null;
//		}
//
//		// soft implement IModelBakerExtension
//		public UnbakedModel getTopLevelModel(ModelResourceLocation location) {
//			return null;
//		}
//
//		@Nullable
//		@Override
//		public BakedModel bake(ResourceLocation resourceLocation, ModelState modelState) {
//			return null;
//		}
//	}
}
