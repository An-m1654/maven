package vazkii.patchouli.client.book.gui.button;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import vazkii.patchouli.client.base.PersistentData.Bookmark;
import vazkii.patchouli.client.book.BookEntry;
import vazkii.patchouli.client.book.gui.GuiBook;
import vazkii.patchouli.common.book.Book;

public class GuiButtonBookBookmark extends GuiButtonBook {

	private final Book book;

	public final Bookmark bookmark;
	public final boolean multiblock;

	public GuiButtonBookBookmark(GuiBook parent, int x, int y, Bookmark bookmark) {
		this(parent, x, y, bookmark, false);
	}

	public GuiButtonBookBookmark(GuiBook parent, int x, int y, Bookmark bookmark, boolean multiblock) {
		super(parent, x, y, 272, bookmark == null ? 170 : 160, 13, 10, parent::handleButtonBookmark, getTooltip(parent.book, bookmark, multiblock));
		this.book = parent.book;
		this.bookmark = bookmark;
		this.multiblock = multiblock;
	}

	@Override
	public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		super.method_48579(graphics, mouseX, mouseY, partialTicks);

		BookEntry entry = bookmark == null ? null : bookmark.getEntry(book);
		if (bookmark != null && entry != null) {
			graphics.method_51448().method_22903();
			graphics.method_51448().method_22905(0.5F, 0.5F, 0.5F);
			int px = method_46426() * 2 + (method_25367() ? 6 : 2);
			int py = method_46427() * 2 + 2;
			entry.getIcon().render(graphics, px, py);

			RenderSystem.disableDepthTest();
			String s = Integer.toString(bookmark.spread + 1);
			if (multiblock) {
				s = class_1074.method_4662("patchouli.gui.lexicon.visualize_letter");
			}
			graphics.method_51433(parent.getMinecraft().field_1772, s, px + 12, py + 10, 0xFFFFFF, true);
			RenderSystem.enableDepthTest();
			graphics.method_51448().method_22909();
		}
	}

	private static class_2561[] getTooltip(Book book, Bookmark bookmark, boolean multiblock) {
		BookEntry entry = bookmark == null ? null : bookmark.getEntry(book);

		if (bookmark == null || entry == null) {
			return new class_2561[] { class_2561.method_43471("patchouli.gui.lexicon.add_bookmark") };
		}

		return new class_2561[] {
				entry.getName(),
				class_2561.method_43471(multiblock
						? "patchouli.gui.lexicon.multiblock_bookmark"
						: "patchouli.gui.lexicon.remove_bookmark").method_27692(class_124.field_1080)
		};
	}

}
