package vazkii.patchouli.client.book.gui.button;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1144;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_5250;
import net.minecraft.class_9848;
import vazkii.patchouli.client.base.ClientTicker;
import vazkii.patchouli.client.book.BookEntry;
import vazkii.patchouli.client.book.gui.GuiBook;

public class GuiButtonEntry extends class_4185 {

	private static final int ANIM_TIME = 5;

	private final GuiBook parent;
	private final BookEntry entry;
	private float timeHovered;

	public GuiButtonEntry(GuiBook parent, int x, int y, BookEntry entry, class_4185.class_4241 onPress) {
		super(x, y, GuiBook.PAGE_WIDTH, 10, entry.getName(), onPress, field_40754);
		this.parent = parent;
		this.entry = entry;
	}

	@Override
	protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		if (!field_22763) {
			return;
		}
		if (method_25367()) {
			timeHovered = Math.min(ANIM_TIME, timeHovered + ClientTicker.delta);
		} else {
			timeHovered = Math.max(0, timeHovered - ClientTicker.delta);
		}

		float time = Math.max(0, Math.min(ANIM_TIME, timeHovered + (method_25367() ? partialTicks : -partialTicks)));
		float widthFract = time / ANIM_TIME;
		boolean locked = entry.isLocked();

		graphics.method_51448().method_22905(0.5F, 0.5F, 0.5F);
		graphics.method_25294(method_46426() * 2, method_46427() * 2, (method_46426() + (int) ((float) field_22758 * widthFract)) * 2, (method_46427() + field_22759) * 2, 0x22000000);
		RenderSystem.enableBlend();

		if (locked) {
			GuiBook.drawLock(graphics, parent.book, method_46426() * 2 + 2, method_46427() * 2 + 2, class_9848.method_61318(0.7F, 1F, 1F, 1F));
		} else {
			entry.getIcon().render(graphics, method_46426() * 2 + 2, method_46427() * 2 + 2);
		}

		graphics.method_51448().method_22905(2F, 2F, 2F);

		class_5250 name;
		if (locked) {
			name = class_2561.method_43471("patchouli.gui.lexicon.locked");
		} else {
			name = entry.getName();
			if (entry.isPriority()) {
				name = name.method_27692(class_124.field_1056);
			}
		}

		name = name.method_27696(entry.getBook().getFontStyle());
		graphics.method_51439(class_310.method_1551().field_1772, name, method_46426() + 12, method_46427(), getColor(), false);

		if (!entry.isLocked()) {
			GuiBook.drawMarking(graphics, parent.book, method_46426() + field_22758 - 5, method_46427() + 1, entry.hashCode(), entry.getReadState());
		}
	}

	private int getColor() {
		if (entry.isSecret()) {
			return 0xAA000000 | (parent.book.textColor & 0x00FFFFFF);
		}
		if (entry.isLocked()) {
			return 0x77000000 | (parent.book.textColor & 0x00FFFFFF);
		}
		return entry.getEntryColor();
	}

	@Override
	public void method_25354(class_1144 soundHandlerIn) {
		if (entry != null && !entry.isLocked()) {
			GuiBook.playBookFlipSound(parent.book);
		}
	}

	public BookEntry getEntry() {
		return entry;
	}

}
