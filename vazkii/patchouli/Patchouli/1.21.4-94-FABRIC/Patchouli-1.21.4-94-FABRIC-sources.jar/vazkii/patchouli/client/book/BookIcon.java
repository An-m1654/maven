package vazkii.patchouli.client.book;

import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7225;
import net.minecraft.class_9848;
import vazkii.patchouli.api.PatchouliAPI;
import vazkii.patchouli.common.util.ItemStackUtil;

public sealed interface BookIcon permits BookIcon.StackIcon, BookIcon.TextureIcon {
	void render(class_332 graphics, int x, int y);

	record StackIcon(class_1799 stack) implements BookIcon {
		@Override
		public void render(class_332 graphics, int x, int y) {
			graphics.method_51427(stack(), x, y);
			graphics.method_51431(class_310.method_1551().field_1772, stack(), x, y);
		}
	}

	record TextureIcon(class_2960 texture) implements BookIcon {
		@Override
		public void render(class_332 graphics, int x, int y) {
			graphics.method_25291(
                class_1921::method_62277,
                texture(),
                x, y,
                0, 0,
                16, 16,
                16, 16,
                class_9848.method_61318(1F, 1F, 1F, 1F));
		}
	}

	static BookIcon from(String str, class_7225.class_7874 registries) {
		if (str.endsWith(".png")) {
			return new TextureIcon(class_2960.method_12829(str));
		} else {
			try {
				class_1799 stack = ItemStackUtil.loadStackFromString(str, registries);
				return new StackIcon(stack);
			} catch (Exception e) {
				PatchouliAPI.LOGGER.warn("Invalid icon item stack: {}", e.getMessage());
				return new StackIcon(class_1799.field_8037);
			}
		}
	}

}
