package vazkii.patchouli.common.item;

import vazkii.patchouli.api.PatchouliAPI;
import vazkii.patchouli.xplat.IXplatAbstractions;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_1792;
import net.minecraft.class_6880;

public class PatchouliItems {

	public static final class_6880<class_1792> BOOK = IXplatAbstractions.INSTANCE.registerItem("guide_book", ItemModBook::new, properties -> properties.method_7889(1));

    public static void init() {}
}
