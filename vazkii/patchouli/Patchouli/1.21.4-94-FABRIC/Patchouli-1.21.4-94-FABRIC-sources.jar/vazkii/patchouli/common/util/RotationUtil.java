package vazkii.patchouli.common.util;

import net.minecraft.class_2350;
import net.minecraft.class_2470;

public final class RotationUtil {

	private RotationUtil() {}

	public static class_2470 rotationFromFacing(class_2350 facing) {
		return switch (facing) {
		case field_11034 -> class_2470.field_11463;
		case field_11035 -> class_2470.field_11464;
		case field_11039 -> class_2470.field_11465;
		default -> class_2470.field_11467;
		};
	}

	// TODO figure out why this is needed and document it.
	public static class_2470 fixHorizontal(class_2470 rot) {
		return switch (rot) {
		case field_11463 -> class_2470.field_11465;
		case field_11465 -> class_2470.field_11463;
		default -> rot;
		};
	}
}
