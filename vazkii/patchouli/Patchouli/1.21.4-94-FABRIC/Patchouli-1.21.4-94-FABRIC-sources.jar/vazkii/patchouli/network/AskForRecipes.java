package vazkii.patchouli.network;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import vazkii.patchouli.api.PatchouliAPI;

public record AskForRecipes() implements class_8710 {
    public static final class_2960 ASK_FOR_RECIPES_PAYLOAD_ID = class_2960.method_60655(PatchouliAPI.MOD_ID, "ask_for_recipes");
    public static final class_9154<AskForRecipes> TYPE = new class_9154<>(ASK_FOR_RECIPES_PAYLOAD_ID);
    public static final class_9139<class_9129, AskForRecipes> STREAM_CODEC = class_9139.method_56431(new AskForRecipes());

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
