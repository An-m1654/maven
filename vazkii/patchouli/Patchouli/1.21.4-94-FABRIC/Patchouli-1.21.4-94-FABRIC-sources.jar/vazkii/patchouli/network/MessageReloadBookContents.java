package vazkii.patchouli.network;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import vazkii.patchouli.api.PatchouliAPI;

public record MessageReloadBookContents() implements class_8710 {
	public static final class_2960 ID = class_2960.method_60655(PatchouliAPI.MOD_ID, "reload_books");
	public static final class_9139<class_2540, MessageReloadBookContents> CODEC = class_9139.method_56431(new MessageReloadBookContents());
	public static final class_9154<MessageReloadBookContents> TYPE = new class_9154<>(ID);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return TYPE;
	}
}
