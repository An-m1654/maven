package vazkii.patchouli.network;

import vazkii.patchouli.api.PatchouliAPI;

import java.util.ArrayList;
import java.util.Collection;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_8786;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SendRecipes(Collection<class_8786<?>> recipes) implements class_8710 {
    public static final class_2960 SEND_RECIPES_PAYLOAD_ID = class_2960.method_60655(PatchouliAPI.MOD_ID, "send_recipes");
    public static final class_9154<SendRecipes> TYPE = new class_9154<>(SEND_RECIPES_PAYLOAD_ID);
    public static final class_9139<class_9129, SendRecipes> STREAM_CODEC = class_9139.method_56434(
        class_9135.method_56376(
            ArrayList::new,
            class_8786.field_48357
        ),
        SendRecipes::recipes,
        SendRecipes::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
