package com.samsthenerd.inline.mixin.prompts;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_4717;

@Mixin(class_408.class)
public class MixinSuggestInChat {

    @Shadow
    protected class_342 chatField;


    @WrapOperation(
        method="render(Lnet/minecraft/client/gui/DrawContext;IIF)V",
        at=@At(
            value="INVOKE",
            target="net/minecraft/client/gui/screen/ChatInputSuggestor.render (Lnet/minecraft/client/gui/DrawContext;II)V"
        )
    )
    public void renderInlineSuggestions(class_4717 chatSuggestor, class_332 context, int mouseX, int mouseY, Operation<Void> original){
        class_327 textRenderer = class_310.method_1551().field_1772;
        int textWidth = textRenderer.method_1727(chatField.method_1882());
        // context.drawText(textRenderer, chatField.getText(), textWidth+chatField.getX(), chatField.getY()-12, 0xFFFFFF, true);
        original.call(chatSuggestor, context, mouseX, mouseY);
    }
}
