package com.samsthenerd.inline.mixin.feature.playerskins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_922;

@Mixin(class_922.class)
public class MixinTurnOffLabel {
    @ModifyReturnValue(
        method = "hasLabel(Lnet/minecraft/entity/LivingEntity;D)Z",
        at = @At("RETURN")
    )
    private boolean killPlayerLabel(boolean original, class_1309 entity){
        if(!original) return original;
        if(entity instanceof class_1657 otherPlayer){
            return otherPlayer.method_5733();
        }
        return original;
    }
}
