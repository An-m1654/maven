package com.samsthenerd.inline.impl.extrahooks;

import com.mojang.blaze3d.systems.RenderSystem;
import com.samsthenerd.inline.api.client.extrahooks.ItemOverlayRenderer;
import com.samsthenerd.inline.utils.VCPImmediateButImLyingAboutIt;
import java.util.*;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;

public class ItemOverlayManager {
    private static final Map<class_1792, List<ItemOverlayRenderer>> ITEM_RENDERERS = new HashMap<>();
    private static final Set<ItemOverlayRenderer> GLOBAL_RENDERERS = new HashSet<>();

    public static List<ItemOverlayRenderer> getRenderers(class_1792 item){
        var renderers = new ArrayList<>(ITEM_RENDERERS.getOrDefault(item, List.of()));
        renderers.addAll(GLOBAL_RENDERERS);
        return renderers;
    }

    public static void addRenderer(class_1792 item, ItemOverlayRenderer renderer){
        ITEM_RENDERERS.computeIfAbsent(item, it -> new ArrayList<>()).add(renderer);
    }

    public static void addRenderer(ItemOverlayRenderer renderer){
        GLOBAL_RENDERERS.add(renderer);
    }

    public static void removeRenderer(ItemOverlayRenderer renderer){
        GLOBAL_RENDERERS.remove(renderer);
    }

    public static void renderDetailTexture(class_1799 stack, class_4587 matrices,
                                           class_811 renderMode, class_4597 vertexConsumers,
                                           int light, int overlay, boolean leftHanded){
        if(renderMode != class_811.field_4317) return;
        var renderers = ItemOverlayManager.getRenderers(stack.method_7909());
        for(var overlayRenderer : renderers) {

            if(!overlayRenderer.isActive(stack)) continue;

            boolean overItem = overlayRenderer.renderInFront(stack);
            class_4597.class_4598 immVC;
            if (overItem && vertexConsumers instanceof class_4597.class_4598 immediateVCs) {
                RenderSystem.disableDepthTest();
                immediateVCs.method_22993();
                RenderSystem.enableDepthTest();
                immVC = immediateVCs;
            } else {
                immVC = VCPImmediateButImLyingAboutIt.of(vertexConsumers);
            }

            class_332 drawCtx = new class_332(class_310.method_1551(), immVC);
            class_4587 ctxMat = drawCtx.method_51448();
            ctxMat.method_22903();
            ctxMat.method_34425(matrices.method_23760().method_23761());
            ctxMat.method_22905(1f/16, -1f/16, 1f/16);
            ctxMat.method_46416(0, -16, overItem ? 10 : -100);
            overlayRenderer.render(stack, drawCtx);
            ctxMat.method_22909();
        }
    }
}
