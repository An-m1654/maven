package com.samsthenerd.inline.mixin.core;

import net.minecraft.class_289;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_289.class)
public interface MixinSetTessBuffer {

    @Accessor("INSTANCE")
    @Mutable
    public static void setInstance(class_289 tes){
        throw new AssertionError();
    }
}
