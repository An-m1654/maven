package com.samsthenerd.inline.api.client.renderers;

import com.samsthenerd.inline.Inline;
import com.samsthenerd.inline.api.InlineData;
import com.samsthenerd.inline.api.client.GlowHandling;
import com.samsthenerd.inline.api.client.InlineRenderer;
import com.samsthenerd.inline.api.data.ItemInlineData;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public class InlineErrorRenderer implements InlineRenderer{

    public static final InlineErrorRenderer INSTANCE = new InlineErrorRenderer();
    public static final ItemInlineData ERROR_DATA = new ItemInlineData(new class_1799(class_1802.field_8077));

    @Override
    public class_2960 getId(){
        return Inline.id( "error");
    }

    @Override
    public int render(InlineData data, class_332 context, int index, class_2583 style, int codepoint, TextRenderingContext trContext){
        return InlineItemRenderer.INSTANCE.render(ERROR_DATA, context, index, style, codepoint, trContext);
    }

    @Override
    public int charWidth(InlineData data, class_2583 style, int codepoint){
        return InlineItemRenderer.INSTANCE.charWidth(ERROR_DATA, style, codepoint);
    }

    @Override
    public GlowHandling getGlowPreference(InlineData data) { return InlineItemRenderer.INSTANCE.getGlowPreference(ERROR_DATA); }
}
