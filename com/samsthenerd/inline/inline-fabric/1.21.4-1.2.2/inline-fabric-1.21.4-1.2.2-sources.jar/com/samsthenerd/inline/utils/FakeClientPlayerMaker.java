package com.samsthenerd.inline.utils;

import com.samsthenerd.inline.mixin.feature.playerskins.MixinAccessPlayerModelParts;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_745;
import net.minecraft.class_8685;
import net.minecraft.class_9296;

public class FakeClientPlayerMaker {
    public static class_1297 getPlayerEntity(class_9296 profile) {
        var profFuture = profile.method_57507();
        var profileToUse = profile;
        try{
            if(profFuture.isDone()) profileToUse = profFuture.get();
        } catch (Exception ignored){}

        class_1657 player = new class_745(class_310.method_1551().field_1687, profileToUse.comp_2413()) {
            @Override
            public boolean method_5733() {
                return false;
            }

            @Override
            public class_8685 method_52814(){
                return class_310.method_1551().method_1582().method_52862(this.method_7334());
            }
        };
        player.field_7502 = player.field_7521 = (player.method_23318() - 0.5);
        player.field_7524 = player.field_7500 = player.method_23317();
        player.field_7522 = player.field_7499 = player.method_23321();
        player.method_5841().method_12778(MixinAccessPlayerModelParts.getPlayerModelParts(), (byte) 0b11111111);
        return player;
    }
}
