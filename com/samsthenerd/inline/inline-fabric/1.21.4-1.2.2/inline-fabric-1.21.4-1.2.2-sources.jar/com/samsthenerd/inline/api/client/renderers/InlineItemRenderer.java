package com.samsthenerd.inline.api.client.renderers;

import com.samsthenerd.inline.Inline;
import com.samsthenerd.inline.api.client.GlowHandling;
import com.samsthenerd.inline.api.client.InlineRenderer;
import com.samsthenerd.inline.api.data.ItemInlineData;
import com.samsthenerd.inline.mixin.core.MixinDrawContextAccessor;
import org.joml.Matrix4f;

import java.util.Random;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_133;
import net.minecraft.class_148;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_4941;
import net.minecraft.class_811;

public class InlineItemRenderer implements InlineRenderer<ItemInlineData>{

    public static final InlineItemRenderer INSTANCE = new InlineItemRenderer();

    public class_2960 getId(){
        return Inline.id( "item");
    }

    public static boolean debugEarlyReturn = true;

    public int render(ItemInlineData data, class_332 context, int index, class_2583 style, int codepoint, TextRenderingContext trContext){
        // only draw it once
        if(trContext.shadow()){
            return 8;
        }
        class_4587 matrices = context.method_51448();
        
        // context.drawItem(data.getStack(), 0, 0);
        // matrices.pop();

        class_1799 stack = data.getStack();
        class_310 client = class_310.method_1551();
        class_1937 world = client.field_1687;

        if (stack.method_7960()) {
            return 8;
        }
        class_1087 bakedModel = client.method_1554().method_4742(new class_1091(class_4941.method_25840(stack.method_7909()), "")); //! This is probably default variant. Idk how to fix
        boolean flat = !bakedModel.method_24304();
        /*
         * here we do a bunch of garbage to make lighting work as nicely as possible in-game.
         *
         * the main issue is that DiffuseLighting.disableGuiDepthLighting() messes up the game's lighting but is needed
         * to make an item look Right when rendered in a flat UI.
         *
         * First we check that it's flat and that the layer type is normal (all UI text rendering seems to use this?)
         * Then we check that the position matrix at the top is flat.
         */
        if (flat && InlineRenderer.isFlat(matrices, trContext.layerType())) {
            class_308.method_24210();
        }
        matrices.method_22903();
        matrices.method_46416(4, 4, 0);
        try {
            matrices.method_34425(new Matrix4f().scaling(1.0f, -1.0f, 1.0f));
            matrices.method_22905(8.0f, 8.0f, 8f);
//            client.getItemRenderer().renderItem(stack, ModelTransformationMode.GUI, false, matrices, context.getVertexConsumers(), trContext.light(), OverlayTexture.DEFAULT_UV, bakedModel);
            client.method_1480().method_23178(stack, class_811.field_4317, trContext.light(), class_4608.field_21444, matrices, ((MixinDrawContextAccessor) context).inline$getVertexConsumers(), world, new Random().nextInt());
            ((MixinDrawContextAccessor) context).inline$getVertexConsumers().method_22993();
        } catch (Throwable throwable) {
            class_128 crashReport = class_128.method_560(throwable, "Rendering item");
            class_129 crashReportSection = crashReport.method_562("Item being rendered");
            crashReportSection.method_577("Item Type", (class_133<String>)(() -> String.valueOf(stack.method_7909())));
            crashReportSection.method_577("Item Components", (class_133<String>)(() -> String.valueOf(stack.method_57353())));
            crashReportSection.method_577("Item Foil", (class_133<String>)(() -> String.valueOf(stack.method_7958())));
            throw new class_148(crashReport);
        }
        matrices.method_22909();
        return 8;
    }

    public int charWidth(ItemInlineData data, class_2583 style, int codepoint){
        return 8;
    }

    // TODO: handle animated items ehre
    @Override
    public GlowHandling getGlowPreference(ItemInlineData forData){
        // this nonsense should force it to refresh for animated sprites ?
//        BakedModel bakedModel = MinecraftClient.getInstance().getItemRenderer().getModel(forData.getStack(), MinecraftClient.getInstance().world, null, 0);
        class_1087 bakedModel = class_310.method_1551().method_1554().method_4742(new class_1091(class_4941.method_25840(forData.getStack().method_7909()), ""));
        return new GlowHandling.Full(forData.getStack().method_7909().method_7876() + Integer.toHexString(bakedModel.hashCode()));  //! This is probably default variant. Idk how to fix
    }
}
