package com.samsthenerd.inline.utils;

import net.minecraft.class_1058;

public class SpritelikeUtils {
    public static Spritelike spritelikeFromSprite(class_1058 sprite){
        return new TextureSprite(sprite.method_45852(),
            sprite.method_4594(), sprite.method_4593(), sprite.method_4577(), sprite.method_4575(),
            sprite.method_45851().method_45807(), sprite.method_45851().method_45815()
        );
    }
}
