package com.samsthenerd.inline.impl;

import com.mojang.authlib.properties.PropertyMap;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_9296;

public interface ProfileComponentUtil {
    static class_9296 from(@Nullable UUID id, @Nullable String name) {
        return new class_9296(Optional.ofNullable(name), Optional.ofNullable(id), new PropertyMap());
    }
}
