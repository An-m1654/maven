package com.samsthenerd.inline.tooltips.providers;

import com.mojang.serialization.Codec;
import com.samsthenerd.inline.Inline;
import com.samsthenerd.inline.tooltips.CustomTooltipManager.CustomTooltipProvider;
import com.samsthenerd.inline.tooltips.data.EntityDisplayTTData;
import com.samsthenerd.inline.utils.EntityCradle;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5632;

public class EntityTTProvider implements CustomTooltipProvider<EntityCradle> {
    public static final EntityTTProvider INSTANCE = new EntityTTProvider();

    @Override
    public class_2960 getId(){
        return Inline.id("entitydisplay");
    }

    @Override
    @NotNull
    public List<class_2561> getTooltipText(EntityCradle cradle){
        List<class_2561> ttText = new ArrayList<>();
        class_1297 ent = cradle.getEntity(class_310.method_1551().field_1687);
        if(ent != null) ttText.add(ent.method_5477());
        return ttText;
    }

    @Override
    @NotNull
    public Optional<class_5632> getTooltipData(EntityCradle cradle){
        return Optional.of(new EntityDisplayTTData(cradle, (w,h) -> h == 0 ? 0 : Math.min(w * 96 /h, 96) ));
    }

    @Override
    public Codec<EntityCradle> getCodec(){
        return EntityCradle.CRADLE_CODEC;
    }
}
