package com.samsthenerd.inline.mixin.feature.playerskins;

import net.minecraft.class_1657;
import net.minecraft.class_2940;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1657.class)
public interface MixinAccessPlayerModelParts {
    @Accessor("PLAYER_MODEL_PARTS")
    public static class_2940<Byte> getPlayerModelParts(){
        throw new AssertionError();
    }
}
