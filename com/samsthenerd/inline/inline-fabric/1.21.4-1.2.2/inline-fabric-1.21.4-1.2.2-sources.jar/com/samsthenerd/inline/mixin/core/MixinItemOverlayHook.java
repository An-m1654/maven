package com.samsthenerd.inline.mixin.core;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.samsthenerd.inline.impl.extrahooks.ItemOverlayManager;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_918.class)
public class MixinItemOverlayHook {
//    @WrapOperation(
//        method="renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IILnet/minecraft/client/render/model/BakedModel;)V",
//        at=@At(value="INVOKE", target="net/minecraft/client/render/item/ItemRenderer.renderBakedItemModel (Lnet/minecraft/client/render/model/BakedModel;Lnet/minecraft/item/ItemStack;IILnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;)V")
//    )
//    public void renderDetailTextureBakedModel(ItemRenderer renderer, BakedModel model, ItemStack stack, int light, int overlay, MatrixStack matrices,
//                                    VertexConsumer vertices, Operation<Void> original, ItemStack stackEnclosing, ModelTransformationMode renderMode,
//                                    boolean leftHanded, MatrixStack matricesEnclosing, VertexConsumerProvider vcp){
//        original.call(renderer, model, stack, light, overlay, matrices, vertices);
//        ItemOverlayManager.renderDetailTexture(stack, matrices, renderMode, vcp, light, overlay, leftHanded);
//    }

    @WrapOperation(
        method = "renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;IILnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/world/World;I)V",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/ItemRenderer;renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/world/World;III)V")
    )
    public void renderDetailTextureBakedModel(class_918 renderer, class_1309 entity, class_1799 stack, class_811 renderMode, boolean leftHanded, class_4587 matrices, class_4597 vcp, class_1937 world, int light, int overlay, int seed, Operation<Void> original) {
        original.call(renderer, entity, stack, renderMode, leftHanded, matrices, vcp, world, light, overlay, seed);
        ItemOverlayManager.renderDetailTexture(stack, matrices, renderMode, vcp, light, overlay, leftHanded);
    }

//    @WrapOperation(
//        method="renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IILnet/minecraft/client/render/model/BakedModel;)V",
//        at=@At(value="INVOKE", target="Lnet/minecraft/client/render/item/BuiltinModelItemRenderer;render(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;II)V")
//    )
//    public void renderDetailTextureBuiltInModel(BuiltinModelItemRenderer renderer, ItemStack stack, ModelTransformationMode renderMode,
//                                                MatrixStack matrices, VertexConsumerProvider vcp, int light, int overlay,
//                                                Operation<Void> original, ItemStack stackEnclosing, ModelTransformationMode renderModeEncl,
//                                                boolean leftHanded, MatrixStack matricesEnclosing, VertexConsumerProvider vcpEncl) {
//        original.call(renderer, stack, renderMode, matrices, vcp, light, overlay);
//        matricesEnclosing.pop();
//        matricesEnclosing.push();
//        matrices.translate(-0.5F, -0.5F, -0.5F);
//        ItemOverlayManager.renderDetailTexture(stack, matricesEnclosing, renderMode, vcp, light, overlay, leftHanded);
//    }

    @WrapOperation(
        method= "renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;IILnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/world/World;I)V",
        at=@At(value="INVOKE", target="Lnet/minecraft/client/render/item/ItemRenderer;renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/world/World;III)V")
    )
    public void renderDetailTextureBuiltInModel(class_918 renderer, class_1309 entity, class_1799 stack, class_811 renderMode, boolean leftHanded, class_4587 matrices, class_4597 vcp, class_1937 world, int light, int overlay, int seed, Operation<Void> original) {
        original.call(renderer, entity, stack, renderMode, leftHanded, matrices, vcp, world, light, overlay, seed);
        matrices.method_22909();
        matrices.method_22903();
        matrices.method_46416(-0.5F, -0.5F, -0.5F);
        ItemOverlayManager.renderDetailTexture(stack, matrices, renderMode, vcp, light, overlay, leftHanded);
    }
}
