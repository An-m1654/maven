package com.samsthenerd.inline.mixin.feature.playerskins;

import net.minecraft.class_2631;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2631.class)
public interface MixinClientHeadChecker {
//    @Accessor("sessionService")
//    public static MinecraftSessionService getSessionService(){
//        throw new AssertionError();
//    }
}
