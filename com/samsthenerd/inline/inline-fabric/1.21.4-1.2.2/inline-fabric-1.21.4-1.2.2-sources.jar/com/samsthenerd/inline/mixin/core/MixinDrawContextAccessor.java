package com.samsthenerd.inline.mixin.core;

import net.minecraft.class_332;
import net.minecraft.class_4597;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_332.class)
public interface MixinDrawContextAccessor {
    @Accessor("vertexConsumers")
    class_4597.class_4598 inline$getVertexConsumers();
}
