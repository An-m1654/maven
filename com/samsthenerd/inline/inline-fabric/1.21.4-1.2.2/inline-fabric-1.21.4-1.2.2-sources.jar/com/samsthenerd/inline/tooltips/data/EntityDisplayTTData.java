package com.samsthenerd.inline.tooltips.data;

import com.samsthenerd.inline.utils.EntityCradle;
import java.util.function.BiFunction;
import net.minecraft.class_5632;

public class EntityDisplayTTData implements class_5632 {
    public final EntityCradle cradle;
    // takes in the  width and height of the given texture and returns the width to render it at
    public BiFunction<Integer, Integer, Integer> widthProvider = (w, h) -> 128;

    public EntityDisplayTTData(EntityCradle cradle){
        this.cradle = cradle;
    }

    public EntityDisplayTTData(EntityCradle cradle, BiFunction<Integer, Integer, Integer> widthProvider){
        this.cradle = cradle;
        this.widthProvider = widthProvider;
    }
}
