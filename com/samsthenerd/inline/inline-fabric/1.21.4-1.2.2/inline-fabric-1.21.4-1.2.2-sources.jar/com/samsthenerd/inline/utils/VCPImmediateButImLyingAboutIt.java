package com.samsthenerd.inline.utils;

import it.unimi.dsi.fastutil.objects.Object2ObjectSortedMaps;
import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

/**
 * This is a stupid stupid stupid thing to let our DrawContext have an immediate even if the actual vc provider is
 * not an immediate. It exists to support compat with mods that render text to non-standard vertex consumers (like
 * glowcase for example).
 */
public class VCPImmediateButImLyingAboutIt extends class_4597.class_4598 {
    private class_4597 provider;

    /**
     * Make sure that we're not making a fake immediate when we have a real immediate we could be using.
     */
    public static class_4598 of(class_4597 provider){
        if(provider instanceof class_4598 imm){
            return imm;
        }
        return new VCPImmediateButImLyingAboutIt(provider);
    }

    private VCPImmediateButImLyingAboutIt(class_4597 provider){
//        super(Tessellator.getInstance().getBuffer(), Map.of());
        super(null, Object2ObjectSortedMaps.emptyMap()); // TODO: write an accessor for the buffer allocator?
        this.provider = provider;
    }

    @Override
    public class_4588 getBuffer(class_1921 renderLayer) {
        return provider.getBuffer(renderLayer);
    }

    @Override
    public void method_37104() {
        // nop
    }

    @Override
    public void method_22993() {
        // nop
    }

    @Override
    public void method_22994(class_1921 layer) {
        // nop
    }
}
